AlphaMap First Case — Publication Pack
研究截止：2026年11月17日
题目：NVIDIA换帅之后，CoreWeave的扩张取决于融资兑现

一、阅读顺序
1. AlphaMap_First_Case_20261117.html：完整中英文切换预览。
2. website/：独立中文和英文canonical HTML，已嵌入图表，无需外部资源。
3. distribution/：公众号中文稿、LinkedIn英文长文及短引文；HTML含排版图表，TXT便于编辑。
4. review/：16处逐句微观编辑对照、CFA基本面与CQF建模框架冷审结果。
5. assets/：四组中英文原创图表，每组均有PNG和SVG；公共数据JSON/CSV及可复算脚本。

二、共同研究主张
已有客户合同和资金支持的算力继续交付。增量投运取决于客户付款与融资能否覆盖建设和设备支出的时点。
CoreWeave的融资条件需要经过具体租约和付款义务，才能传到Core Scientific。建设款抵扣耗尽带来实收上升，同时可能触发本金摊还，因此不能把全部现金增加额分配给权益端。

三、篇幅与分发
中文正文含标题、元信息、数字、公司名、标点和引用序号，共2647个非空白字符；不含来源列表和图注。
英文长文正文约1371词。LinkedIn短引文2085字符，含拟发布的英文canonical URL。
本包完成内容准备；没有代发公众号或LinkedIn。短引文中的官网链接应在对应页面实际上线后使用。

四、拟上线地址
中文：https://lunartuliplab.com/alphamap/ai-infrastructure-cash-flow-first-case-2026-11
英文：https://lunartuliplab.com/en/alphamap/ai-infrastructure-cash-flow-first-case-2026-11

官网工程状态：
{
  "pr_url": "https://github.com/Lunartulip/web_official/pull/2",
  "pr_number": 2,
  "pr_state": "open",
  "draft": true,
  "merged": false,
  "remote_commit_sha": "5eb2263f56dc176edd540ebc65037628ef202b7b",
  "local_commit_sha": "5eb2263f56dc176edd540ebc65037628ef202b7b",
  "branch": "research/alphamap-cash-flow-first-case-20261117",
  "repository": "Lunartulip/web_official",
  "changed_files": 23,
  "tests": {
    "npm_test": "passed",
    "rendered_html_tests_passed": 36,
    "research_objects": 17,
    "claims": 119,
    "evidence_entries": 77,
    "authority_validator": "passed",
    "notes_validator": "passed",
    "final_build": "passed after final cash-flow wording and typography changes",
    "lint": "no errors; one existing unused-disable warning in app/opengraph-image.tsx"
  },
  "checks": {
    "old_research_objects_unchanged": 16,
    "built_case_html_matches_final_output_bytes": true,
    "bilingual_canonical_hreflang_x_default": "passed",
    "discovery": "present in AlphaMap RSS, sitemap and llms; excluded from Deep Dive feed",
    "public_metadata_boundary": "passed; no claims, evidence, financialBridge, falsifiers, dataGaps or valuationScenarios"
  },
  "github_ci": {
    "status": "completed",
    "conclusion": "success",
    "run_id": 44028578408,
    "url": "https://github.com/Lunartulip/web_official/actions/runs/44028578408"
  },
  "production_deployed": false,
  "production_status": "Draft PR only; main is unchanged and no production deployment was performed.",
  "deployment_blocker": "The repository workflow runs verification only; production requires an authorized Singapore-server pull, build and service restart, which is not available in this session.",
  "branch_publication_method": "Authenticated GitHub connection; HTTPS git push lacked a local credential. Remote tree matches the validated local tree.",
  "canonical_targets": {
    "zh": "https://lunartuliplab.com/alphamap/ai-infrastructure-cash-flow-first-case-2026-11",
    "en": "https://lunartuliplab.com/en/alphamap/ai-infrastructure-cash-flow-first-case-2026-11"
  },
  "full_diff_path": "/workspace/scratch/6aa42040b254/tmp/alphamap_first_case_full.diff",
  "pr_body_path": "/workspace/scratch/6aa42040b254/tmp/alphamap_first_case_pr_body.md",
  "qa_path": "/workspace/scratch/6aa42040b254/tmp/site_integration_qa.json",
  "mergeable": true
}

站点生产环境通过独立服务器拉取仓库、构建并重启服务部署；当前工作环境没有该服务器访问能力。
PR或仓库提交不代表生产网页已经上线。本包也没有以其他域名替代官网发布。

五、复算
使用Python 3运行：
  python3 assets/reproduce_calculations.py
无需安装第三方依赖。脚本读取同目录first_case_public_model.json，输出覆盖率、计费比例、抵扣示例及2027—2031年条件债务支付表。
每个数据点含观察期间、单位、事实/预期/推算属性和原始来源。
2029年11月首次还本为10-Q编表所用的条件假设；实际由租约、抵扣与时间条件决定。2031年列含到期本金。

六、证据与审阅边界
公开研究使用8份一手披露与本案独立计算。正文将管理层预期、已披露事实和研究判断分别归属。
本次SemiAnalysis句法对照使用2026年11月12日的英文原文。11月13日模型更新取得的是中文二次解读及用户附图，没有据此伪造其英文表达。
本包不包含SemiAnalysis全文邮件或原图，也不包含AlphaMap内部数据导出。
CFA和CQF代表独立审阅框架，不代表外部持证人士认证。
已完成来源、计算、静态结构及离线排版检查；未完成真实浏览器交互验收。
正文未宣称回测超额收益、已校准概率或生产图自动更新。

LunarTulip Research · AlphaMap Case 01 · Version 1.0
