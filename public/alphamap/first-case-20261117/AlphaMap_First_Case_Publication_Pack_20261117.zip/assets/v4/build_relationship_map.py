from pathlib import Path
import json,subprocess,html,re
O=Path(__file__).resolve().parent
graph=json.loads((O/"public_relationships.json").read_text())
edges=graph["edges"];NODES=graph["nodes"]
colors={'supply':'#52748a','service':'#315f4e','support':'#ad7b38','ownership':'#8a8e84'}
for lang in ['zh','en']:
 z=lang=='zh';rows=[['Microsoft','OpenAI','Anthropic','Undisclosed Neocloud'],['CoreWeave','Nebius','IREN','Financing SPV'],['NVIDIA','Broadcom','Google','AMD','Akela'],['SK hynix','Micron','Applied Digital','Core Scientific','Fluidstack'],['TSMC','TeraWulf']]
 names={n:n for n in NODES};names['Undisclosed Neocloud']='未具名Neocloud' if z else 'Undisclosed Neocloud';names['Financing SPV']='融资 SPV' if z else 'Financing SPV'
 nodes='\n'.join('"'+n+'" [label="'+names[n]+'",fillcolor="'+('#e3ecdf' if n in ['Microsoft','OpenAI','Anthropic'] else '#fffdfa')+'"];' for n in NODES)
 ranks='\n'.join('{rank=same;'+''.join('"'+n+'";' for n in row)+'}' for row in rows)
 lines=[]
 for e in edges:
  lab=e['relationship_zh' if z else 'relationship_en'];style='solid' if e['provenance']=='AlphaMap existing relationship' else 'dashed'
  lines.append('"'+e['source']+'" -> "'+e['target']+'" [label="'+lab+'", color="'+colors[e['type']]+'",fontcolor="'+colors[e['type']]+'",style="'+style+'",constraint=false];')
 # Invisible backbone fixes semantic rows without inventing displayed relationships.
 backbone='\n'.join('"'+rows[i][0]+'" -> "'+rows[i+1][0]+'" [style=invis,weight=100,constraint=true];' for i in range(len(rows)-1))
 dot='digraph G {graph [rankdir=TB,bgcolor="#f6f3eb",pad="0.5",nodesep="0.65",ranksep="1.15",splines=polyline,outputorder=edgesfirst]; node [shape=box,style="rounded,filled",color="#aab4a8",fontcolor="#20332d",fontname="Noto Sans CJK SC",fontsize=17,margin=".17,.12",penwidth=1.2];edge [fontname="Noto Sans CJK SC",fontsize=12,arrowsize=.7,penwidth=1.5];'+nodes+ranks+backbone+'\n'.join(lines)+'}'
 p=O/f'02_network.{lang}.dot';p.write_text(dot)
 subprocess.run(['dot','-Tsvg',str(p),'-o',str(O/f'02_network_body.{lang}.svg')],check=True)
 raw=(O/f'02_network_body.{lang}.svg').read_text()
 vb=re.search(r'viewBox="([^"]+)"',raw).group(1).split();w,h=float(vb[2]),float(vb[3]);content=raw[raw.index('<g id="graph0"'):raw.rindex('</svg>')]
 title='共同客户、不同支持方与尚未起租的扩张' if z else 'Shared customers, distinct support and future leases'
 sub='实线：AlphaMap既有关系   虚线：本轮公开补证' if z else 'Solid: existing AlphaMap relationship   Dashed: public-source supplement'
 legend=[('service','算力 / 托管服务' if z else 'Compute / hosting'),('supply','设备 / 内存 / 技术' if z else 'Equipment / memory / technology'),('support','条件资金支持' if z else 'Conditional financial support')]
 top=145;bottom=95
 svg=f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {w} {h+top+bottom}" role="img" aria-label="{title}"><rect width="100%" height="100%" fill="#f6f3eb"/><g font-family="Noto Sans CJK SC,Arial,sans-serif" fill="#20332d"><text x="38" y="30" font-size="14" fill="#64716a" font-weight="700">LUNARTULIP RESEARCH / 01</text><text x="38" y="73" font-size="27" font-weight="700">{title}</text><text x="38" y="107" font-size="15" fill="#64716a">{sub}</text></g><g transform="translate(0,{top})">{content}</g>'
 for j,(typ,label) in enumerate(legend):
  x=38+j*w/3
  svg+=f'<line x1="{x}" x2="{x+29}" y1="{h+top+30}" y2="{h+top+30}" stroke="{colors[typ]}" stroke-width="3"/><text x="{x+38}" y="{h+top+35}" font-family="Noto Sans CJK SC,Arial" font-size="15" fill="#20332d">{label}</text>'
 foot='箭头为关系方向；线宽不代表风险权重。已融资、可提款、到货与回款分别核对。' if z else 'Arrows show relationship direction, not risk weights. Funding, drawability, delivery and collections differ.'
 svg+=f'<text x="38" y="{h+top+72}" font-family="Noto Sans CJK SC,Arial" font-size="13" fill="#64716a">{foot}</text></svg>'
 (O/f'02_network.{lang}.svg').write_text(svg)
 from weasyprint import HTML
 import fitz
 width=1600;height=width*(h+top+bottom)/w
 doc=f'<html><head><style>@page{{size:{width}px {height}px;margin:0}}html,body{{margin:0;padding:0}}svg{{width:{width}px;height:{height}px;display:block}}</style></head><body>'+svg+'</body></html>'
 pdf=HTML(string=doc).write_pdf()
 f=fitz.open(stream=pdf,filetype='pdf')
 f[0].get_pixmap(matrix=fitz.Matrix(4/3,4/3),alpha=False).save(O/f'02_network.{lang}.png')
print('network',len(NODES),'nodes',len(edges),'edges')
