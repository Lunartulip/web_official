#!/usr/bin/env python3
"""Render original bilingual AlphaMap charts from the frozen v4.1 results.

No model is rerun or modified. The integrated model supplies all modeled
outcomes; the frozen supply input supplies its initial low/base/high plans,
and the frozen BOM supplies only the two configuration-change components.

Usage:
    python output/alphamap_first_case_v4_assets/build_v4_quant_charts.py
    python build_v4_quant_charts.py --data-dir /path/to/tmp --output-dir /path/to/assets

The public package resolves model/reference/ and model/tmp/ beside this script.
Requirements: matplotlib, numpy, fonttools, and Noto Sans CJK SC. Use
--font-dir /path/to/fonts if the Noto font files are not installed system-wide.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import tempfile

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.colors import LinearSegmentedColormap, Normalize, to_rgb
from matplotlib.lines import Line2D
from matplotlib.patches import FancyBboxPatch, Patch, Rectangle
from matplotlib.cm import ScalarMappable
from fontTools.ttLib import TTCollection
import numpy as np


BG = "#f6f3eb"
INK = "#20332d"
GREEN = "#315f4e"
AMBER = "#a76e32"
MUTED = "#617169"
GRID = "#d8dacf"
PALE_GREEN = "#dce5d9"
PALE_AMBER = "#eee0cb"
CARD = "#fffdf7"
EXPECTED_MODEL_HASH = "a92275cb9c0255421be58e52af034eb368d6fd5260052a788d00f0513608488e"


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def install_fonts(font_dir=None):
    """Select the SC face explicitly; Matplotlib otherwise chooses TTC face 0."""
    cache = Path(tempfile.gettempdir()) / "alphamap_v4_chart_fonts"
    cache.mkdir(exist_ok=True)
    candidates = [Path(p) for p in font_manager.findSystemFonts()
                  if "NotoSansCJK" in Path(p).name]
    if font_dir is not None:
        candidates = list(font_dir.rglob("NotoSansCJK*")) + candidates
    for style in ("Regular", "Bold"):
        dest = cache / f"NotoSansCJKSC-{style}.otf"
        if not dest.exists():
            sources = [p for p in candidates if style.lower() in p.name.lower()]
            installed = False
            for source in sources:
                if source.suffix.lower() == ".ttc":
                    collection = TTCollection(source)
                    for face in collection.fonts:
                        names = {n.toUnicode() for n in face["name"].names if n.nameID == 1}
                        if "Noto Sans CJK SC" in names:
                            face.save(dest)
                            installed = True
                            break
                elif source.suffix.lower() in (".otf", ".ttf"):
                    if font_manager.FontProperties(fname=source).get_name() == "Noto Sans CJK SC":
                        dest.write_bytes(source.read_bytes())
                        installed = True
                if installed:
                    break
            if not installed:
                raise RuntimeError("Install Noto Sans CJK SC Regular/Bold, or pass --font-dir containing the Noto TTC/OTF files.")
        font_manager.fontManager.addfont(str(dest))
    plt.rcParams.update({
        "font.family": "Noto Sans CJK SC",
        "font.size": 18,
        "text.color": INK,
        "axes.labelcolor": INK,
        "xtick.color": INK,
        "ytick.color": INK,
        "axes.facecolor": BG,
        "figure.facecolor": BG,
        "savefig.facecolor": BG,
        "axes.unicode_minus": False,
        "svg.fonttype": "path",
        "svg.hashsalt": "alphamap-first-case-v4.1",
        "pdf.fonttype": 42,
        "lines.solid_capstyle": "round",
    })


def txt(fig, x, y, text, size=18, color=INK, weight="normal", ha="left", va="top", **kw):
    return fig.text(x, y, text, fontsize=size, color=color, fontweight=weight,
                    ha=ha, va=va, linespacing=1.35, **kw)


def rect(fig, x, y, w, h, color=CARD, edge=None, rounding=0.012):
    patch = FancyBboxPatch((x, y), w, h,
                          boxstyle=f"round,pad=0.006,rounding_size={rounding}",
                          facecolor=color, edgecolor=edge or color, linewidth=1.2,
                          transform=fig.transFigure, zorder=-1)
    fig.add_artist(patch)
    return patch


def rule(fig, y, left=.07, right=.94, color=GRID, lw=1):
    fig.add_artist(Line2D([left, right], [y, y], transform=fig.transFigure,
                          color=color, linewidth=lw))


def header(fig, number, title, subtitle, *, title_size=26, subtitle_y=.871):
    display_number = {"01":"04","03":"03","04":"06","05":"07","06":"08"}.get(number, number)
    txt(fig, .07, .985, f"LUNARTULIP RESEARCH  /  {display_number}", size=11.5, weight="bold", color=MUTED)
    txt(fig, .07, .952, title, size=title_size, weight="bold")
    txt(fig, .07, subtitle_y, subtitle, size=17, color=MUTED)


def footer(fig, lang, lines, y=.092, step=.024, size=13.7):
    origin = ("来源：LunarTulip Research 独立测算 · 2026-11-17" if lang == "zh"
              else "Source: LunarTulip Research estimates · 2026-11-17")
    for i, line in enumerate([origin] + lines):
        txt(fig, .07, y - step*i, line, size=size, color=MUTED)


def clean_axis(ax):
    for name in ("top", "right", "left"):
        ax.spines[name].set_visible(False)
    ax.spines["bottom"].set_color(GRID)
    ax.tick_params(length=0, pad=10, labelsize=18)
    ax.set_axisbelow(True)


def row_by_year(rows, year):
    return next(r for r in rows if r["year"] == year)


def contrast_text(background):
    def luminance(color):
        rgb = np.asarray(to_rgb(color))
        linear = np.where(rgb <= .04045, rgb/12.92, ((rgb+.055)/1.055)**2.4)
        return float(np.dot(linear, [.2126, .7152, .0722]))
    lum = luminance(background)
    contrasts = {color: (max(lum, luminance(color))+.05)/(min(lum, luminance(color))+.05)
                 for color in [BG, INK]}
    return max(contrasts, key=contrasts.get)


def make_balance(model, supply, bom, lang):
    ref = row_by_year(model["same_device_configuration_bridge"], 2028)
    policies = {r["procurement_lookahead_quarters"]: r
                for r in model["procurement_policy_comparison_2028"]}
    initial = model["base_2028_supply_reconciliation"]["fixed_plan_Top3_qualified_capacity_EB"]
    vals = [ref["current_configuration_EB"], initial,
            policies[1]["embedded_HBM_EB"], policies[4]["embedded_HBM_EB"]]
    fig = plt.figure(figsize=(8.6, 11.9))
    if lang == "zh":
        title = "2028：先分清四种量"
        subtitle = "单位都是标称 HBM EB，问题与范围各不相同。"
        labels = ["意向设备：按配置所需", "Top3：初始合格能力",
                  "提前 1 季采购：设备嵌入", "提前 4 季采购：设备嵌入"]
        notes = ["3,010.8 万颗意向设备\n尚未施加采购与设施约束",
                 "三家供应商的初始代际生产计划\n工程能力估计，未匹配具体采购",
                 f"其中 Top3 匹配 {policies[1]['embedded_top3_pool_HBM_EB']:.2f} EB\n另有池外内存 {policies[1]['outside_pool_memory_EB']:.2f} EB",
                 f"其中 Top3 匹配 {policies[4]['embedded_top3_pool_HBM_EB']:.2f} EB\n另有池外内存 {policies[4]['outside_pool_memory_EB']:.2f} EB"]
        header(fig, "01", title, subtitle, subtitle_y=.892)
    else:
        title = "2028: four quantities,\nfour different scopes"
        subtitle = "Nominal HBM, EB. Each answers a different question."
        labels = ["Intended devices: HBM required", "Top3 initial qualified capacity",
                  "1q lookahead: HBM embedded", "4q lookahead: HBM embedded"]
        notes = ["30.108m intended accelerator devices\nBefore procurement / facility constraints",
                 "Initial production plan by generation\nEngineering capacity, before matching",
                 f"Top3 matched: {policies[1]['embedded_top3_pool_HBM_EB']:.2f} EB\nOutside-pool memory: {policies[1]['outside_pool_memory_EB']:.2f} EB",
                 f"Top3 matched: {policies[4]['embedded_top3_pool_HBM_EB']:.2f} EB\nOutside-pool memory: {policies[4]['outside_pool_memory_EB']:.2f} EB"]
        header(fig, "01", title, subtitle, subtitle_y=.861)
    colors = [INK, GREEN, AMBER, GREEN]
    for i, (value, label, note, color) in enumerate(zip(vals, labels, notes, colors)):
        y = .662 - .159*i
        rect(fig, .07, y, .87, .139)
        fig.add_artist(Rectangle((.07, y+.017), .005, .106,
                                  transform=fig.transFigure, facecolor=color, edgecolor="none"))
        txt(fig, .095, y+.116, label, size=18.5 if lang == "en" else 19.5, weight="bold")
        txt(fig, .095, y+.073, note, size=15.2, color=MUTED)
        txt(fig, .915, y+.091, f"{value:.2f}", size=34, color=color, weight="bold", ha="right")
        txt(fig, .915, y+.031, "EB", size=15.5, color=color, ha="right")
    txt(fig, .07, .139,
        "四项不能直接相减为已确认的市场缺口。" if lang == "zh" else
        "These are not four sides of one market-balance equation.",
        size=16.5, weight="bold", color=GREEN)
    footer(fig, lang,
           ["采购情景：设施 IT 增速 25%；物理准备期 1 季；中功率。",
            "高端云端加速器参考样本；采购情景未赋予概率。"] if lang == "zh" else
           ["Procurement: 25% facility IT growth; 1q physical lag; mid power.",
            "High-end cloud reference cohort. No scenario probabilities."],
           y=.091, step=.025, size=13.4)
    return fig


def make_supply(model, supply, bom, lang):
    years = [2026, 2027, 2028]
    capacity = {s: [next(r["supply_nominal_EB"] for r in supply["annual"]
                         if r["year"] == y and r["scenario"] == s) for y in years]
                for s in ["low", "base", "high"]}
    procurement = {q: [row_by_year(model["cases"][f"procurement_lookahead_{q}q"]["annual"], y)
                        ["embedded_top3_pool_HBM_EB"] for y in years] for q in [1, 4]}
    fig = plt.figure(figsize=(8.6, 12.6))
    title = "能力与匹配采购，各有边界" if lang == "zh" else "Capacity and matched procurement"
    subtitle = "2026–2028 · Top3 标称 HBM（EB）" if lang == "zh" else "2026–2028 · Top3 nominal HBM, EB"
    header(fig, "03", title, subtitle, title_size=25 if lang == "zh" else 23.5,
           subtitle_y=.899)
    legend_labels = (["初始能力：低—高", "初始能力：中值", "提前 1 季：匹配采购", "提前 4 季：匹配采购"]
                     if lang == "zh" else ["Initial capacity: low–high", "Initial capacity: base",
                                           "1q: matched procurement", "4q: matched procurement"])
    handles = [Patch(facecolor=PALE_GREEN, edgecolor="none"),
               Line2D([0], [0], color=GREEN, linewidth=3.5, marker="o", markersize=8),
               Line2D([0], [0], color=AMBER, linewidth=3, marker="o", linestyle="--", markersize=7),
               Line2D([0], [0], color=INK, linewidth=3, marker="D", markersize=7)]
    fig.legend(handles, legend_labels, loc="upper left", bbox_to_anchor=(.075, .858),
               ncol=2, frameon=False, fontsize=15.4, handlelength=2.0,
               columnspacing=1.0, labelspacing=.9, borderaxespad=0)
    ax = fig.add_axes([.12, .463, .81, .302])
    ax.fill_between(years, capacity["low"], capacity["high"], color=PALE_GREEN, zorder=1)
    ax.plot(years, capacity["base"], color=GREEN, linewidth=3.5, marker="o", markersize=8, zorder=4)
    ax.plot(years, procurement[1], color=AMBER, linewidth=3, marker="o", markersize=7,
            linestyle="--", zorder=5)
    ax.plot(years, procurement[4], color=INK, linewidth=3, marker="D", markersize=7, zorder=6)
    ax.set_xlim(2025.85, 2028.15)
    ax.set_ylim(0, 11.2)
    ax.set_xticks(years)
    ax.set_yticks([0, 2, 4, 6, 8, 10])
    ax.grid(axis="y", color=GRID, linewidth=.8)
    clean_axis(ax)
    txt(fig, .12, .785, "EB", size=16, color=MUTED)

    colx = [.105, .428, .684, .872]
    headings = ["年份", "能力：低—高\n（中值）", "1 季采购", "4 季采购"] if lang == "zh" else [
        "Year", "Capacity: low–high\n(base)", "1q matched", "4q matched"]
    for x, text in zip(colx, headings):
        txt(fig, x, .409, text, size=15.7, weight="bold", ha="center")
    rule(fig, .356)
    for i, year in enumerate(years):
        y = .327 - .071*i
        values = [str(year), f"{capacity['low'][i]:.2f}–{capacity['high'][i]:.2f}\n({capacity['base'][i]:.2f})",
                  f"{procurement[1][i]:.2f}", f"{procurement[4][i]:.2f}"]
        for j, (x, text) in enumerate(zip(colx, values)):
            txt(fig, x, y, text, size=18.2 if j == 1 else 19.5, ha="center", va="center",
                color=GREEN if j == 1 else AMBER if j == 2 else INK,
                weight="bold" if j > 1 else "normal")
    rule(fig, .143)
    footer(fig, lang,
           ["能力为初始代际计划；匹配采购允许在同一投片预算内重配。",
            "1/4 季均用中值供应与 25% 设施增速；不是已实现出货。",
            "仅 Top3 匹配池；不含池外内存。范围非概率区间。"] if lang == "zh" else
           ["Capacity uses initial recipes; matching can reallocate the same wafers.",
            "1q / 4q use base supply and 25% facility growth, not observed sales.",
            "Top3 matched pool only. Ranges are not probability intervals."],
           y=.111, step=.024, size=12.9 if lang == "en" else 13.5)
    return fig


def make_inventory(model, supply, bom, lang):
    p = {r["procurement_lookahead_quarters"]: r for r in model["procurement_policy_comparison_2028"]}
    flow_delta = p[4]["embedded_HBM_EB"] - p[1]["embedded_HBM_EB"]
    stock_delta = p[4]["pipeline_HBM_EB"] - p[1]["pipeline_HBM_EB"]
    assert abs(p[1]["installed_AI_IT_GW"]-p[4]["installed_AI_IT_GW"]) < 1e-10
    fig = plt.figure(figsize=(8.6, 12.0))
    title = "装机相同，多采购的设备留在库存" if lang == "zh" else "More procurement,\nthe same installed AI power"
    subtitle = "2028 年末 · 系统 IT 额定功率（GW）" if lang == "zh" else "End-2028 · System IT rating, GW"
    header(fig, "04", title, subtitle, title_size=23 if lang == "zh" else 25,
           subtitle_y=.892 if lang == "zh" else .857)
    legend_labels = ["已装 AI IT", "未装设备的 IT 额定功率"] if lang == "zh" else [
        "Installed AI IT", "Uninstalled equipment IT rating"]
    fig.legend([Patch(facecolor=GREEN), Patch(facecolor=AMBER)], legend_labels,
               loc="upper left", bbox_to_anchor=(.075, .811), ncol=1, frameon=False,
               fontsize=16.5, labelspacing=.55, borderaxespad=0)
    ax = fig.add_axes([.16, .525, .77, .235])
    for q, y in [(1, 1), (4, 0)]:
        installed = p[q]["installed_AI_IT_GW"]
        pending = p[q]["pipeline_IT_GW"]
        ax.barh(y, installed, height=.39, color=GREEN)
        ax.barh(y, pending, left=installed, height=.39, color=AMBER)
        ax.text(installed*.50, y, f"{installed:.3f}", ha="center", va="center",
                fontsize=22, color=BG, fontweight="bold")
        if q == 1:
            ax.annotate(f"{pending:.3f}", xy=(installed+pending/2, y+.195),
                        xytext=(installed+pending/2+5, y+.53), ha="center", va="center",
                        fontsize=20, color=AMBER, fontweight="bold",
                        arrowprops=dict(arrowstyle="-", color=AMBER, linewidth=1.5))
        else:
            ax.text(installed+pending/2, y, f"{pending:.3f}", ha="center", va="center",
                    fontsize=20, color=BG, fontweight="bold")
    ax.set_yticks([1, 0], ["提前 1 季", "提前 4 季"] if lang == "zh" else ["1q ahead", "4q ahead"])
    ax.set_xlim(0, 153)
    ax.set_ylim(-.5, 1.72)
    ax.set_xticks([0, 50, 100, 150])
    ax.grid(axis="x", color=GRID, linewidth=.8)
    clean_axis(ax)
    ax.tick_params(axis="y", labelsize=16)
    ax.set_xlabel("设备的系统 IT 额定功率（GW）" if lang == "zh" else "Equipment system IT rating (GW)",
                  fontsize=16, labelpad=13)

    card_y, card_h = .301, .144
    rect(fig, .07, card_y, .414, card_h, PALE_GREEN)
    rect(fig, .526, card_y, .414, card_h, PALE_AMBER)
    card_titles = (["2028 年度嵌入\n流量差", "2028 年末未装 HBM\n库存差"] if lang == "zh" else
                   ["2028 embedded\nflow difference", "End-2028 uninstalled\nHBM stock difference"])
    for x, heading, delta, color in zip([.09, .546], card_titles, [flow_delta, stock_delta], [GREEN, AMBER]):
        txt(fig, x, card_y+.121, heading, size=17.5, weight="bold")
        txt(fig, x, card_y+.049, f"+{delta:.3f} EB", size=28, weight="bold", color=color)
    txt(fig, .5, .267, "年度流量差 ≠ 期末库存差" if lang == "zh" else "Annual flow difference ≠ ending stock difference",
        size=18 if lang == "zh" else 16.7, ha="center", weight="bold")
    explanation = ("库存差还包含往年采购与投运的累积影响。\n未装设备的额定功率，不是正在消耗的电力。" if lang == "zh" else
                   "Ending inventory also reflects earlier procurement and installation.\nUninstalled equipment ratings are not live electricity consumption.")
    txt(fig, .5, .226, explanation, size=14.9, ha="center", color=MUTED)
    txt(fig, .5, .157,
        f"期末未装 HBM：1 季 {p[1]['pipeline_HBM_EB']:.3f} EB；4 季 {p[4]['pipeline_HBM_EB']:.3f} EB" if lang == "zh" else
        f"Uninstalled HBM: 1q {p[1]['pipeline_HBM_EB']:.3f} EB; 4q {p[4]['pipeline_HBM_EB']:.3f} EB",
        size=17, ha="center", weight="bold")
    footer(fig, lang,
           ["同一期初库存、25% 设施 IT 增速、1 季物理准备期、中功率。",
            "高端云端加速器参考样本；两种采购政策均未赋予概率。"] if lang == "zh" else
           ["Same opening stock, 25% facility growth, 1q physical lag, mid power.",
            "High-end cloud reference cohort. Neither policy has a probability."],
           y=.093, step=.025, size=13.2)
    return fig


def make_sensitivity(model, supply, bom, lang):
    grid = model["interactive_grid"]
    assert len(grid) == 27
    values = [r["embedded_HBM_EB"] for r in grid]
    norm = Normalize(vmin=min(values), vmax=max(values))
    cmap = LinearSegmentedColormap.from_list("alphamap_eb", ["#eee8d8", "#aebfaf", GREEN])
    fig = plt.figure(figsize=(8.6, 14.7))
    title = "2028：三项假设，27 个结果" if lang == "zh" else "2028: 27 conditional outcomes"
    subtitle = "每格为设备嵌入 HBM（EB）；列为采购提前期。" if lang == "zh" else "Device-embedded HBM (EB). Columns: procurement lookahead."
    header(fig, "05", title, subtitle, title_size=25 if lang == "zh" else 24,
           subtitle_y=.907)
    panel_titles = ["低功率边界", "中功率参考", "高功率边界"] if lang == "zh" else [
        "Low power bound", "Mid power reference", "High power bound"]
    for power_index, (bottom, heading) in enumerate(zip([.635, .395, .155], panel_titles)):
        matrix = np.array([[next(r["embedded_HBM_EB"] for r in grid
                                 if r["power_index"] == power_index
                                 and abs(r["facility_growth"]-growth) < 1e-10
                                 and r["procurement_lookahead_quarters"] == lookahead)
                            for lookahead in [1, 2, 4]] for growth in [.20, .25, .30]])
        txt(fig, .10, bottom+.209, heading, size=20, weight="bold", va="bottom")
        ax = fig.add_axes([.255, bottom, .68, .17])
        ax.imshow(matrix, cmap=cmap, norm=norm, aspect="auto")
        ax.set_xticks(range(3), ["1 季", "2 季", "4 季"] if lang == "zh" else ["1q", "2q", "4q"])
        ax.set_yticks(range(3), ["20%", "25%", "30%"])
        ax.tick_params(length=0, labelsize=19.5, pad=11, top=True, labeltop=True,
                       bottom=False, labelbottom=False)
        ax.set_xticks(np.arange(-.5, 3, 1), minor=True)
        ax.set_yticks(np.arange(-.5, 3, 1), minor=True)
        ax.grid(which="minor", color=BG, linewidth=4)
        ax.tick_params(which="minor", length=0)
        for spine in ax.spines.values():
            spine.set_visible(False)
        for r in range(3):
            for c in range(3):
                val = matrix[r, c]
                ax.text(c, r, f"{val:.2f}", ha="center", va="center", fontsize=25,
                        color=contrast_text(cmap(norm(val))[:3]), fontweight="bold")
        if power_index == 1:
            ax.add_patch(Rectangle((-.48, .52), .96, .96, fill=False, edgecolor=AMBER,
                                   linewidth=3.2))
    txt(fig, .06, .518, "设施 IT 库存年增速" if lang == "zh" else "Annual facility IT stock growth",
        size=17.5, rotation=90, ha="center", va="center")
    cax = fig.add_axes([.255, .102, .68, .014])
    cb = fig.colorbar(ScalarMappable(norm=norm, cmap=cmap), cax=cax, orientation="horizontal")
    cb.set_ticks([3, 4, 5, 6, 7, 8])
    cb.ax.tick_params(length=0, labelsize=14, pad=5)
    cb.outline.set_visible(False)
    txt(fig, .10, .112, "HBM\nEB", size=14.5, color=MUTED, va="center")
    footer(fig, lang,
           ["同一期初库存；物理准备期 1 季；HBM / 逻辑面积假设不变。",
            "总量含池外内存。琥珀框为参考格；颜色不表示概率。"] if lang == "zh" else
           ["Fixed opening stock, 1q physical lag, unchanged HBM / logic assumptions.",
            "Includes outside-pool memory. Amber = reference cell; no probabilities."],
           y=.056, step=.0175, size=12.8)
    return fig


def make_configuration(model, supply, bom, lang):
    bridge = row_by_year(model["same_device_configuration_bridge"], 2028)
    components = row_by_year(bom["same_device_configuration_counterfactual"]["by_year"], 2028)
    start = bridge["same_devices_unreduced_EB"]
    end = bridge["current_configuration_EB"]
    ultra, amd = components["ultra_saving_EB"], components["mi450_saving_EB"]
    assert abs(start-ultra-amd-end) < 1e-10
    pct = bridge["configuration_saving_fraction"]*100
    fig = plt.figure(figsize=(8.6, 12.4))
    title = f"同样的设备，HBM 需要量少 {pct:.1f}%" if lang == "zh" else f"Same devices, {pct:.1f}% less HBM"
    subtitle = "2028 意向设备组合 · 数量、逻辑面积、额定功率不变" if lang == "zh" else "2028 intended mix · Count, logic area and rated power held fixed"
    header(fig, "06", title, subtitle, title_size=24 if lang == "zh" else 25,
           subtitle_y=.899)
    txt(fig, .5, .828, f"{start:.3f} − {ultra:.3f} − {amd:.3f} = {end:.3f} EB",
        size=23, color=GREEN, weight="bold", ha="center")
    ax = fig.add_axes([.12, .402, .81, .365])
    x = np.array([0, 1.35, 2.70, 4.05])
    width = .68
    ax.bar(x[0], start, width=width, color=INK)
    ax.bar(x[1], ultra, bottom=start-ultra, width=width, color=AMBER,
           edgecolor=AMBER, linewidth=1.2)
    ax.bar(x[2], amd, bottom=end, width=width, color="#c29561",
           edgecolor=AMBER, linewidth=1.2)
    ax.bar(x[3], end, width=width, color=GREEN)
    for a, b, y in [(x[0], x[1], start), (x[1], x[2], start-ultra), (x[2], x[3], end)]:
        ax.plot([a+width/2, b-width/2], [y, y], color=MUTED, linestyle=(0, (3, 3)), linewidth=1.2)
    for xx, label in zip(x, [f"{start:.3f}", f"−{ultra:.3f}", f"−{amd:.3f}", f"{end:.3f}"]):
        ax.text(xx, 12.0, label, fontsize=18.5, ha="center", fontweight="bold",
                color=AMBER if label.startswith("−") else INK)
    names = ["同设备\n未减配", "Ultra 候选\n低层数采用", "MI450X\n产品选择", "当前配置\n所需"] if lang == "zh" else [
        "Same devices\nunreduced", "Ultra candidate\nlayer choice", "MI450X\nproduct choice", "Current\nconfiguration"]
    ax.set_xticks(x, names)
    ax.set_ylim(0, 13.1)
    ax.set_xlim(-.62, 4.67)
    ax.set_yticks([0, 3, 6, 9, 12])
    ax.grid(axis="y", color=GRID, linewidth=.8)
    clean_axis(ax)
    ax.tick_params(axis="x", labelsize=15.8, pad=14)
    txt(fig, .12, .787, "HBM EB", size=15.5, color=MUTED)
    units = components["total_devices_m"]
    txt(fig, .5, .323,
        f"设备数量固定：{units*100:,.1f} 万颗" if lang == "zh" else f"Device count held at {units:.3f} million",
        size=19, ha="center", weight="bold")
    rule(fig, .286)
    if lang == "zh":
        txt(fig, .08, .263, "Ultra 候选：16 堆栈、24Gb 裸片的工程分支", size=16.5, weight="bold")
        txt(fig, .08, .231,
            f"{components['ultra_eligible_devices_m']:.3f} 百万颗 × 50% × (576−384) GB → {ultra:.3f} EB", size=16)
        txt(fig, .08, .187, "MI450X：288 GB 与 432 GB 的产品选择", size=16.5, weight="bold")
        txt(fig, .08, .155,
            f"{components['mi450_selected_devices_m']:.3f} 百万颗 × (432−288) GB → {amd:.3f} EB", size=16)
    else:
        txt(fig, .08, .263, "Ultra candidate: 16-stack, 24Gb engineering branch", size=16.5, weight="bold")
        txt(fig, .08, .231,
            f"{components['ultra_eligible_devices_m']:.3f}m devices × 50% × (576−384) GB → {ultra:.3f} EB", size=15.8)
        txt(fig, .08, .187, "MI450X: product choice, 288 GB versus 432 GB", size=16.5, weight="bold")
        txt(fig, .08, .155,
            f"{components['mi450_selected_devices_m']:.3f}m devices × (432−288) GB → {amd:.3f} EB", size=15.8)
    footer(fig, lang,
           ["Ultra 堆栈数与 50% 采用率为情景，未确认最终规格；非全体减配。",
            "MI450X 为容量选择，不据此认定降层。无概率；不是采购预测。"] if lang == "zh" else
           ["Ultra stack count / 50% adoption are assumptions, not final specifications.",
            "MI450X is a capacity choice, not proven de-stacking. No probabilities."],
           y=.090, step=.025, size=12.9)
    return fig


def metadata(model, supply, bom):
    bridge = row_by_year(model["same_device_configuration_bridge"], 2028)
    config = row_by_year(bom["same_device_configuration_counterfactual"]["by_year"], 2028)
    pol = {r["procurement_lookahead_quarters"]: r for r in model["procurement_policy_comparison_2028"]}
    result = {}

    def add(name, values, zh, en):
        result[name] = {"key_values": values, "zh": dict(zip(["title", "alt", "caption"], zh)),
                        "en": dict(zip(["title", "alt", "caption"], en))}
        for lang in ["zh", "en"]:
            result[name][lang]["files"] = {fmt: f"{name}.{lang}.{fmt}" for fmt in ["svg", "png"]}

    add("01_balance", {
        "year": 2028, "unit": "nominal HBM EB",
        "intended_devices_configuration_requirement_EB": bridge["current_configuration_EB"],
        "initial_Top3_qualified_plan_capacity_EB": model["base_2028_supply_reconciliation"]["fixed_plan_Top3_qualified_capacity_EB"],
        "procurement_1q_total_embedded_EB": pol[1]["embedded_HBM_EB"],
        "procurement_1q_Top3_matched_EB": pol[1]["embedded_top3_pool_HBM_EB"],
        "procurement_4q_total_embedded_EB": pol[4]["embedded_HBM_EB"],
        "procurement_4q_Top3_matched_EB": pol[4]["embedded_top3_pool_HBM_EB"],
        "scope_warning": "Different scopes; not a same-scope supply/demand gap."},
        ("2028：先分清四种量",
         "四张独立口径卡：意向设备配置所需 11.10 EB，Top3 初始合格能力 7.83 EB，提前 1 季和 4 季采购时设备嵌入分别 4.96 和 7.31 EB。",
         "四项单位相同、口径不同。11.10 EB 来自意向设备与配置，7.83 EB 是 Top3 初始代际计划的工程能力；4.96/7.31 EB 为采购政策的条件结果，含池外内存，对应 Top3 匹配值为 4.91/7.24 EB。不能直接相减为已确认市场缺口。"),
        ("2028: four quantities, four different scopes",
         "Four scope-separated cards: intended-device HBM requirement 11.10 EB; initial Top3 qualified capacity 7.83 EB; device-embedded HBM under 1q and 4q procurement policies 4.96 and 7.31 EB.",
         "The unit is common but the scope differs. Intended device configuration requires 11.10 EB; the initial Top3 generation plan offers an estimated 7.83 EB. Conditional 1q/4q procurement embeds 4.96/7.31 EB including outside-pool memory, with 4.91/7.24 EB Top3-matched. These are not directly subtractable measures of an established market gap."))

    supply_values = []
    for year in [2026, 2027, 2028]:
        supply_values.append({"year": year,
            **{f"initial_Top3_{case}_capacity_EB": next(r["supply_nominal_EB"] for r in supply["annual"]
                                                       if r["year"] == year and r["scenario"] == case)
               for case in ["low", "base", "high"]},
            **{f"procurement_{q}q_Top3_matched_EB": row_by_year(model["cases"][f"procurement_lookahead_{q}q"]["annual"], year)["embedded_top3_pool_HBM_EB"]
               for q in [1, 4]}})
    add("03_supply", {"unit": "nominal HBM EB", "annual": supply_values,
                      "scope": "Initial fixed-generation Top3 qualified engineering capacity; base-supply Top3-matched procurement with allowed wafer reallocation."},
        ("能力与匹配采购，各有边界",
         "2026 至 2028 年，Top3 初始能力中值为 4.07、5.81、7.83 EB，低高边界分别为 3.56–4.57、4.90–6.61、5.89–10.28 EB；1 季匹配采购为 3.40、4.07、4.91 EB，4 季为 3.49、6.02、7.24 EB。",
         "阴影为初始代际计划的低高工程边界，线为能力中值与两种采购政策的 Top3 匹配量。匹配时允许在相同投片预算内重配代际，因此 2027 年 4 季采购的 6.02 EB 可高于初始计划中值 5.81 EB。它们不是实际出货、订单或概率区间；池外内存未计入。"),
        ("Capacity and matched procurement",
         "For 2026–2028, initial Top3 base capacity is 4.07, 5.81 and 7.83 EB; low–high bounds are 3.56–4.57, 4.90–6.61 and 5.89–10.28 EB. Matched 1q procurement is 3.40, 4.07 and 4.91 EB; 4q procurement is 3.49, 6.02 and 7.24 EB.",
         "The band is the initial-generation plan's engineering range. Lines show base capacity and Top3-matched procurement under two policies. Matching may reallocate generation recipes within the same wafer budget, explaining why 2027 4q procurement can exceed the initial base plan. These are not realized shipments, observed orders or probability intervals. Outside-pool memory is excluded."))

    flow_delta = pol[4]["embedded_HBM_EB"] - pol[1]["embedded_HBM_EB"]
    stock_delta = pol[4]["pipeline_HBM_EB"] - pol[1]["pipeline_HBM_EB"]
    add("04_inventory", {"year": 2028, "policy_comparison": [pol[1], pol[4]],
                          "annual_total_embedded_flow_difference_EB": flow_delta,
                          "year_end_uninstalled_HBM_stock_difference_EB": stock_delta},
        ("装机相同，多采购的设备留在库存",
         "两种采购政策 2028 年末已装 AI IT 均为 99.667 GW；提前 1 季和 4 季采购的未装设备对应 10.138 和 43.829 GW。年度嵌入 HBM 流量差为 2.354 EB，期末未装 HBM 库存差为 4.433 EB。",
         "固定同一期初库存、25% 设施增长、1 季物理准备期与中功率后，延长采购提前期增加设备库存，并不增加同期已装 AI IT。未装设备对应的额定功率不是正在用电的负荷。2028 年流量差与年末库存差不同，后者还累积了往年的采购和投运。采购政策没有被赋予概率。"),
        ("More procurement, the same installed AI power",
         "Both policies end 2028 at 99.667 GW installed AI IT. Uninstalled equipment corresponds to 10.138 GW under 1q procurement and 43.829 GW under 4q. Annual embedded HBM differs by 2.354 EB, while ending uninstalled HBM inventory differs by 4.433 EB.",
         "With the same opening inventory, 25% facility growth, a 1q physical lag and mid power, longer procurement lookahead creates inventory without increasing installed AI IT. Uninstalled nameplate ratings are not live electricity demand. The annual flow difference differs from the ending-stock difference, which also reflects earlier procurement and commissioning. Neither policy is assigned a probability."))

    add("05_sensitivity", {"year": 2028, "unit": "total device-embedded nominal HBM EB",
                            "rows_facility_growth": [.20, .25, .30],
                            "columns_procurement_lookahead_quarters": [1, 2, 4],
                            "panels_power_index": [0, 1, 2], "cells": model["interactive_grid"],
                            "no_interpolation": True, "no_probabilities": True},
        ("2028：三项假设，27 个结果",
         "三个功率边界面板各含 3×3 热图：行是设施 IT 库存年增速 20%、25%、30%，列是提前采购 1、2、4 季。每格显示冻结模型预计算的总设备嵌入 HBM EB，范围 2.70 至 8.02；中功率、25%、1 季的参考格为 4.96。",
         "27 格逐项读取冻结模型，没有线性插值。功率索引变化时 HBM 与逻辑面积假设保持不变，物理准备期为 1 季，期初库存固定。总设备嵌入含池外内存；8.02 EB 的设备上限包含重配后约 7.94 EB Top3 与约 0.08 EB 池外内存，并非 8.02 EB Top3 产量。颜色表示数值大小，不表示概率。"),
        ("2028: 27 conditional outcomes",
         "Three 3-by-3 heatmaps for low, mid and high device power. Rows are facility IT stock growth of 20%, 25% and 30%; columns are procurement lookahead of 1q, 2q and 4q. Frozen-model total embedded HBM ranges from 2.70 to 8.02 EB. The mid-power, 25%-growth, 1q reference cell is 4.96 EB.",
         "All 27 cells are precomputed model outcomes with no interpolation. HBM and logic-area assumptions remain fixed when the power index changes; the physical lag is 1q and opening inventory is fixed. Total embedded HBM includes outside-pool memory. The 8.02 EB hardware ceiling comprises about 7.94 EB reallocated Top3 capability plus 0.08 EB outside-pool memory, not 8.02 EB Top3 output. Color represents magnitude, not probability."))

    add("06_configuration", {"year": 2028, "unit": "nominal HBM EB",
                              "same_devices_unreduced_EB": bridge["same_devices_unreduced_EB"],
                              "ultra_candidate_layer_choice_saving_EB": config["ultra_saving_EB"],
                              "mi450_product_choice_saving_EB": config["mi450_saving_EB"],
                              "current_configuration_requirement_EB": bridge["current_configuration_EB"],
                              "saving_fraction": bridge["configuration_saving_fraction"],
                              "devices_m": config["total_devices_m"],
                              "ultra_candidate_devices_m": config["ultra_eligible_devices_m"],
                              "ultra_adoption_assumption": .5,
                              "mi450_selected_devices_m": config["mi450_selected_devices_m"],
                              "component_formula": "million_devices * adoption * delta_nominal_GB / 1000 = nominal EB",
                              "zero_based_y_axis": True},
        ("同样的设备，HBM 需要量少 2.8%",
         "零基线瀑布图：固定 3,010.8 万颗意向设备，未减配时需 11.418 EB；Ultra 候选低层数情景减少 0.275 EB，MI450X 产品选择减少 0.043 EB，得到 11.100 EB，减少 2.8%。",
         "只改变有依据的候选族群配置，不对全部 GPU/ASIC 统一打折。Ultra 采用 16 堆栈、24Gb 裸片、50% 低层数采用的工程分支，最终产品未定；MI450X 使用已公布 288 GB 与 432 GB 的容量选择，不据此认定降层。固定设备数、逻辑面积和额定功率，结果是同设备配置桥，不是采购预测。"),
        ("Same devices, 2.8% less HBM",
         "Zero-baseline waterfall for 30.108 million intended devices: 11.418 EB without eligible configuration reductions, minus 0.275 EB from the Ultra-candidate layer scenario and 0.043 EB from MI450X product choice, equals 11.100 EB, a 2.8% reduction.",
         "Only eligible families change configuration; there is no blanket GPU/ASIC discount. The Ultra candidate uses an engineering branch with 16 stacks, 24Gb dies and 50% lower-layer adoption; final product specifications remain unsettled. MI450X uses the announced 288 GB versus 432 GB capacity choice, not proof of de-stacking. Device count, logic area and rated power are held fixed. This is a same-device configuration bridge, not a procurement forecast."))
    return result


def save_figure(fig, out, name, lang, meta):
    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()
    w, h = fig.canvas.get_width_height()
    outside = []
    # This catches accidental clipping of titles, labels, captions and annotations.
    for text in fig.findobj(match=matplotlib.text.Text):
        if not text.get_visible() or not text.get_text().strip():
            continue
        bbox = text.get_window_extent(renderer)
        if bbox.x0 < -1 or bbox.y0 < -1 or bbox.x1 > w+1 or bbox.y1 > h+1:
            outside.append(text.get_text())
    if outside:
        raise RuntimeError(f"Text outside canvas in {name}.{lang}: {outside}")
    stem = out / f"{name}.{lang}"
    fig.savefig(stem.with_suffix(f".{lang}.svg"), format="svg",
                metadata={"Title": meta["title"], "Description": meta["alt"],
                          "Creator": "AlphaMap original research charts", "Date": None})
    fig.savefig(stem.with_suffix(f".{lang}.png"), format="png", dpi=180,
                metadata={"Title": meta["title"], "Description": meta["alt"],
                          "Software": "AlphaMap / Matplotlib"})
    plt.close(fig)
    return {"text_inside_canvas": True, "width_inches": w/fig.dpi,
            "height_inches": h/fig.dpi, "png_dpi": 180}


def main():
    script = Path(__file__).resolve()
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-dir", type=Path, default=None,
                        help="Optional directory containing all three frozen JSON inputs.")
    parser.add_argument("--output-dir", type=Path, default=script.parent)
    parser.add_argument("--font-dir", type=Path, default=None,
                        help="Optional directory containing Noto Sans CJK SC TTC/OTF files.")
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    paths = {}
    for name in ["v4_integrated_model.json", "v4_hbm_supply.json", "v4_bom_power_area.json"]:
        if args.data_dir is not None:
            candidates = [args.data_dir/name]
        else:
            candidates = []
            if name == "v4_integrated_model.json":
                candidates.append(script.parent/"model"/"reference"/name)
            candidates.extend([script.parent/"model"/"tmp"/name,
                               script.parents[2]/"tmp"/name])
        found = next((p for p in candidates if p.is_file()), None)
        if found is None:
            raise FileNotFoundError(f"Missing frozen input {name}. Supply --data-dir or retain the adjacent model/ directory.")
        paths[name] = found
    hashes = {k: sha256(v) for k, v in paths.items()}
    if hashes["v4_integrated_model.json"] != EXPECTED_MODEL_HASH:
        raise RuntimeError("Integrated JSON does not match the frozen v4.1 input hash.")
    model, supply, bom = [json.loads(paths[k].read_text()) for k in paths]
    for name in ["v4_hbm_supply.json", "v4_bom_power_area.json"]:
        if hashes[name] != model["input_hashes"][name]:
            raise RuntimeError(f"Input differs from integrated-model freeze: {name}")
    install_fonts(args.font_dir)
    figures = metadata(model, supply, bom)
    makers = {"01_balance": make_balance, "03_supply": make_supply,
              "04_inventory": make_inventory, "05_sensitivity": make_sensitivity,
              "06_configuration": make_configuration}
    checks = {}
    for name, maker in makers.items():
        checks[name] = {}
        for lang in ["zh", "en"]:
            fig = maker(model, supply, bom, lang)
            checks[name][lang] = save_figure(fig, args.output_dir, name, lang, figures[name][lang])
            print(f"Rendered {name}.{lang}.svg + .png", flush=True)
    result = {"version": "v4.1-frozen-model-original-charts", "as_of": model["as_of"],
              "source_model_version": model["version"], "source_files_sha256": hashes,
              "model_code_sha256": model["model_code_sha256"],
              "builder_sha256": sha256(script), "font": "Noto Sans CJK SC",
              "palette": {"background": BG, "ink": INK, "green": GREEN, "amber": AMBER},
              "units": {"HBM": "Nominal supply-chain EB; not a one-sided GiB-to-SI conversion.",
                        "power": "GW of system IT nameplate; annual flows and ending stocks distinguished."},
              "probabilities_assigned": False, "model_modified": False,
              "data_join_notes": ["All modeled outcomes come from frozen integrated v4.1 JSON.",
                  "Initial supply engineering ranges come from the exact frozen input verified against model hash.",
                  "Configuration component deltas come from frozen BOM; the integrated totals are used because future recipes changed in v4.1.",
                  "No SemiAnalysis values are model or chart inputs.",
                  "Existing 02_network assets are not read or modified."],
              "figures": figures, "layout_checks": checks}
    for name in figures:
        for lang in ["zh", "en"]:
            figures[name][lang]["sha256"] = {fmt: sha256(args.output_dir/f"{name}.{lang}.{fmt}")
                                              for fmt in ["svg", "png"]}
    (args.output_dir/"figure_metadata.json").write_text(json.dumps(result, ensure_ascii=False, indent=2)+"\n")
    # The source inputs must remain byte-identical throughout rendering.
    assert hashes == {k: sha256(v) for k, v in paths.items()}
    print("All 10 bilingual figures rendered; frozen inputs unchanged.")


if __name__ == "__main__":
    main()
