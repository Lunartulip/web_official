#!/usr/bin/env python3
"""Recalculate CORZ exposure denominators and render bilingual standalone charts.

Usage: python build_corz_exposure.py [--output-dir PATH] [--font-dir PATH]
Input: corz_exposure_analysis.json beside this script (or --input PATH).
Outputs: updated derived values in that JSON, CSV, SVG/PNG, and figure metadata.
Dependencies: matplotlib, numpy and fonttools from requirements-charts.txt.
The existing frozen global model is neither read for values nor modified.
"""
from __future__ import annotations
import argparse
import csv
import hashlib
import json
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle

from build_v4_quant_charts import install_fonts, txt, rect, rule
from build_v4_quant_charts import BG, INK, GREEN, AMBER, MUTED, GRID, PALE_GREEN, CARD


def sha256(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def calculate(data):
    inputs = data['inputs']
    caps = inputs['contracted_capacity']
    c = {x['counterparty']: x['capacity_MW'] for x in caps['categories']}
    billing = inputs['billing_progress']
    for row in caps['categories']:
        if 'sites' in row:
            assert sum(row['sites'].values()) == row['capacity_MW']
    total = sum(c.values())
    rounded = caps['reported_coreweave_and_amd_neocloud_combined_rounded_MW']
    assert c['AMD direct'] + c['Neocloud counterparty'] == 529
    assert rounded == c['CoreWeave'] + caps['reported_amd_neocloud_combined_rounded_MW']
    assert abs(total-rounded) <= 1
    assert 0 <= billing['billable_MW'] <= billing['contracted_MW']
    assert inputs['current_revenue']['colocation_revenue_share'] == 1
    data['derivations'] = {
        'sum_of_disaggregated_contract_capacity_MW': {
            'value': total, 'formula': '590 + 377 + 152',
            'unit': 'MW', 'source_ids': [6, 49],
        },
        'reported_rounded_contract_capacity_MW': {
            'value': rounded, 'formula': '590 + 530',
            'unit': 'MW (approximately)', 'source_ids': [6],
        },
        'coreweave_share_of_reported_rounded_contract_capacity': {
            'value': c['CoreWeave']/rounded, 'formula': '590 / (590 + 530)',
            'unit': 'fraction of reported contracted IT MW',
            'display': 'approximately 53%', 'source_ids': [6],
        },
        'coreweave_share_of_disaggregated_contract_capacity': {
            'value': c['CoreWeave']/total, 'formula': '590 / (590 + 377 + 152)',
            'unit': 'fraction of disaggregated contracted IT MW', 'source_ids': [6, 49],
        },
        'coreweave_billable_share': {
            'value': billing['billable_MW']/billing['contracted_MW'],
            'formula': '485 / 590', 'unit': 'fraction of CoreWeave contracted IT MW',
            'display': 'approximately 82%', 'source_ids': [6],
        },
        'coreweave_not_yet_billable_MW': {
            'value': billing['contracted_MW']-billing['billable_MW'],
            'formula': '590 - 485', 'unit': 'MW (approximately)', 'source_ids': [6],
        },
    }
    return data


def export_csv(data, path):
    inp=data['inputs']; caps=inp['contracted_capacity']; bill=inp['billing_progress']
    rows=[dict(metric='CoreWeave share of current colocation revenue', value=inp['current_revenue']['colocation_revenue_share'], unit='fraction', denominator='CORZ current colocation revenue', as_of=inp['current_revenue']['as_of'], status='reported', formula='', source_ids='7', scope_note='Not group revenue or future contracted capacity')]
    for row in caps['categories']:
        rows.append(dict(metric=f"Contracted customer IT capacity: {row['counterparty']}", value=row['capacity_MW'], unit='MW', denominator='Executed customer contracts; not gross utility capacity', as_of=caps['as_of'], status='reported', formula='', source_ids=';'.join(map(str,row['source_ids'])), scope_note=row['instrument']))
    rows.append(dict(metric='CoreWeave billable customer IT capacity', value=bill['billable_MW'], unit='MW', denominator='CoreWeave contracted IT capacity', as_of=bill['as_of'], status='reported', formula='', source_ids='6', scope_note='Not rent collections; aggregate as disclosed'))
    for key,v in data['derivations'].items():
        rows.append(dict(metric=key, value=v['value'], unit=v['unit'], denominator=('CoreWeave contracted IT MW' if key.startswith('coreweave_billable') or key.startswith('coreweave_not_yet') else 'Two disclosed contract groups; no reservation rights'), as_of=caps['as_of'], status='derived', formula=v['formula'], source_ids=';'.join(map(str,v['source_ids'])), scope_note='Approximate disclosed inputs; capacity percentages are not revenue or profit weights'))
    rows.append(dict(metric='Excluded AMD reservation right', value=caps['reservation_capacity_right_excluded_MW'], unit='MW', denominator='Excluded from all contracted-capacity calculations', as_of='2026-07-27', status='reported_reservation_only', formula='', source_ids='49', scope_note='A right through 2028-12-28, not an executed lease for all reserved capacity'))
    with path.open('w',encoding='utf-8',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    return rows


def bar(fig,x,y,width,value,max_value,color):
    fig.add_artist(Rectangle((x,y),width,.016,transform=fig.transFigure,facecolor=GRID,edgecolor='none'))
    fig.add_artist(Rectangle((x,y),width*value/max_value,.016,transform=fig.transFigure,facecolor=color,edgecolor='none'))


def render(data,lang,out):
    z=lang=='zh'; fig=plt.figure(figsize=(10.2,11.6))
    inputs=data['inputs']; calc=data['derivations']
    capacities={row['counterparty']:row['capacity_MW'] for row in inputs['contracted_capacity']['categories']}
    bill=inputs['billing_progress']
    revenue_share=inputs['current_revenue']['colocation_revenue_share']
    contracted_share=calc['coreweave_share_of_reported_rounded_contract_capacity']['value']
    billing_share=calc['coreweave_billable_share']['value']
    not_billable=calc['coreweave_not_yet_billable_MW']['value']
    total=calc['reported_rounded_contract_capacity_MW']['value']
    txt(fig,.06,.977,'LUNARTULIP RESEARCH  /  02',size=12,weight='bold',color=MUTED)
    title=('CORZ：新租约仍待转成托管收入' if z else 'CORZ: new leases have yet to become\ncolocation revenue')
    txt(fig,.06,.94,title,size=26 if z else 24,weight='bold')
    txt(fig,.06,.868,('收入、签约容量与计费进度，各自采用对应分母。' if z else 'Revenue, contracted capacity and billing use distinct denominators.'),size=15.5,color=MUTED)

    rect(fig,.06,.405,.422,.413,color=CARD)
    rect(fig,.515,.405,.425,.413,color=CARD)
    txt(fig,.082,.796,('当前托管收入' if z else 'Current colocation revenue'),size=17.2,weight='bold')
    txt(fig,.082,.762,('截至2026-09-30' if z else 'As of September 30, 2026'),size=12.8,color=MUTED)
    ax=fig.add_axes([.105,.505,.33,.232]); ax.set_aspect('equal')
    pie_values=[revenue_share] if revenue_share==1 else [revenue_share,1-revenue_share]
    ax.pie(pie_values,colors=[GREEN,GRID],startangle=90,wedgeprops=dict(width=.18,edgecolor=CARD))
    ax.text(0,.09,f'{100*revenue_share:.0f}%',ha='center',va='center',fontsize=38,color=INK,fontweight='bold')
    ax.text(0,-.25,'CoreWeave',ha='center',va='center',fontsize=16.5,color=GREEN)
    ax.axis('off')
    txt(fig,.082,.481,('分母：CORZ托管业务收入' if z else 'Denominator: CORZ colocation revenue'),size=13.2,color=MUTED)
    txt(fig,.082,.448,('AMD及另一客户租约尚未起租、未确认收入。' if z else 'AMD / Neocloud leases had not started;\nno related lease revenue recognized.'),size=12.1,color=MUTED)

    txt(fig,.537,.796,('已签约客户IT容量' if z else 'Contracted customer IT capacity'),size=17.2,weight='bold')
    txt(fig,.537,.762,(f'截至2026-11-05 · 约{total:,} MW' if z else f'November 5, 2026 · approximately {total:,} MW'),size=12.8,color=MUTED)
    values=[('CoreWeave',capacities['CoreWeave'],GREEN),('AMD直租' if z else 'AMD direct leases',capacities['AMD direct'],AMBER),('另一客户¹' if z else 'Neocloud counterparty¹',capacities['Neocloud counterparty'],'#87977d')]
    for y,(label,val,color) in zip([.706,.615,.524],values):
        txt(fig,.537,y,label,size=16,color=INK)
        txt(fig,.918,y,f'{val} MW',size=16,ha='right',weight='bold',color=color)
        bar(fig,.537,y-.041,.381,val,max(capacities.values()),color)
    txt(fig,.537,.444,(f'CoreWeave占两组签约容量约{100*contracted_share:.0f}%' if z else f'CoreWeave: ~{100*contracted_share:.0f}% of the two\ncontract groups’ IT capacity'),size=13.7 if z else 12.8,weight='bold',color=GREEN)

    rect(fig,.06,.255,.88,.124,color=CARD)
    txt(fig,.082,.357,(f'CoreWeave的{bill["contracted_MW"]}MW：已计费进度' if z else f'CoreWeave: billing progress across {bill["contracted_MW"]} MW'),size=16.5,weight='bold')
    txt(fig,.918,.355,f'{100*billing_share:.0f}%',size=29,weight='bold',ha='right',color=GREEN)
    txt(fig,.082,.318,(f'{bill["billable_MW"]} MW已计费；约{not_billable} MW尚待起账' if z else f'{bill["billable_MW"]} MW billable; approximately {not_billable} MW not yet billable'),size=13.4,color=MUTED)
    bar(fig,.082,.278,.66,bill['billable_MW'],bill['contracted_MW'],GREEN)
    txt(fig,.918,.283,('截至11月5日' if z else 'November 5'),size=11.7,ha='right',color=MUTED,va='center')

    if z:
        notes=[
            '新增约530MW：管理层预计2027年初开始交付、2028年底全部交付，起租取决于建设与合同条件。',
            '¹ 152MW由另一客户承租；AMD提供针对这些租约的附条件信用支持，并非530MW的无条件担保。',
            '377 + 152 = 529MW，管理层取整为约530MW。签约分母为590 + 530；未计入1,925MW预约权。',
            '53%为两组签约容量占比；82%为CoreWeave合同容量的计费比例。两者均不是收入、利润或回款权重。',
            '所有MW均为披露约数。资料：[6]Q3业绩材料第4、6、9、13页；[7]Q3 10-Q；[49]Q2 10-Q注15。',
            'LunarTulip Research计算 · 信息截至2026-11-17 · Q2 10-Q实际发布于2026-07-28。',
        ]
    else:
        notes=[
            'Management targets initial delivery of ~530 MW in early 2027 and full delivery by end-2028.',
            'Lease commencement depends on completed capacity and contractual conditions.',
            '¹ The Neocloud leases cover 152 MW with lease-specific, conditional AMD credit support.',
            'This is not an unconditional AMD guarantee of all 530 MW.',
            '377 + 152 = 529 MW, rounded by management to ~530 MW. The 1,925 MW reservation is excluded.',
            "53% uses the 590 + 530 MW contract denominator; 82% is CoreWeave's 485 / 590 MW billing ratio.",
            'Neither percentage is a revenue, profit or cash-collection weight. All MW figures are approximate.',
            'Sources: [6] Q3 deck pp. 4, 6, 9, 13; [7] Q3 10-Q; [49] Q2 10-Q Note 15 (filed July 28, 2026).',
            'Calculations: LunarTulip Research · Information as of November 17, 2026.',
        ]
    y=.219;step=.027 if z else .0215
    for i,line in enumerate(notes):txt(fig,.06,y-i*step,line,size=12 if z else 11.6,color=MUTED)
    fig.canvas.draw()
    renderer=fig.canvas.get_renderer()
    for text in fig.texts:
        extent=text.get_window_extent(renderer)
        assert extent.x0>=0 and extent.x1<=fig.bbox.width+1 and extent.y0>=0 and extent.y1<=fig.bbox.height+1, (lang,text.get_text(),extent)
    svg=out/f'07_corz_exposure.{lang}.svg'; png=out/f'07_corz_exposure.{lang}.png'
    fig.savefig(svg,metadata={'Date':None});fig.savefig(png,dpi=180,metadata={'Software':'LunarTulip Research'})
    plt.close(fig)
    alt=('分开呈现三个口径：截至2026年9月底，CORZ托管收入100%来自CoreWeave；截至11月5日，签约客户IT容量为CoreWeave590MW、AMD直租377MW和另一客户152MW，合计约1120MW；CoreWeave的590MW中485MW已计费，约82%。' if z else 'Three separate denominators: at September 2026, 100% of CORZ colocation revenue came from CoreWeave. At November 5, contracted customer IT capacity was CoreWeave 590 MW, AMD direct 377 MW and a Neocloud 152 MW, approximately 1,120 MW combined. Within CoreWeave’s 590 MW, 485 MW was billable, approximately 82%.')
    caption=('CoreWeave占两组签约客户IT容量约53%，不能作为当前收入或利润权重。AMD直租377MW与附特定AMD信用支持的另一客户152MW分开计量；新增约530MW截至9月底尚未起租，管理层预计2027年初开始、2028年底全部交付。1,925MW预约权未计入签约分母。' if z else 'CoreWeave accounts for roughly 53% of the two disclosed contract groups’ IT capacity, not current revenue or earnings. AMD’s 377 MW direct leases are separate from the Neocloud’s 152 MW with lease-specific AMD credit support. None of the new ~530 MW had commenced at September-end; management targets delivery from early 2027 through end-2028. The 1,925 MW reservation right is excluded.')
    return {'number':'02','title':title.replace('\n',' '),'alt':alt,'caption':caption,'source_ids':[6,7,49],'files':{'svg':svg.name,'png':png.name},'sha256':{'svg':sha256(svg),'png':sha256(png)},'text_inside_canvas':True,'width_inches':10.2,'height_inches':11.6,'png_dpi':180}


def main():
    ap=argparse.ArgumentParser();base=Path(__file__).resolve().parent
    ap.add_argument('--input',type=Path,default=base/'corz_exposure_analysis.json')
    ap.add_argument('--output-dir',type=Path,default=base)
    ap.add_argument('--font-dir',type=Path)
    args=ap.parse_args();args.output_dir.mkdir(parents=True,exist_ok=True)
    install_fonts(args.font_dir)
    plt.rcParams['svg.hashsalt']='lunartulip-corz-exposure-20261117'
    data=calculate(json.loads(args.input.read_text()))
    target=args.output_dir/'corz_exposure_analysis.json'
    target.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
    rows=export_csv(data,args.output_dir/'corz_exposure_analysis.csv')
    metadata={'analysis_id':data['analysis_id'],'as_of':data['as_of'],'source_ids':data['source_ids'],'model_4_1_modified':False,'csv_rows':len(rows),'input_sha256':sha256(target),'builder_sha256':sha256(Path(__file__)),'figures':{lang:render(data,lang,args.output_dir) for lang in ['zh','en']}}
    (args.output_dir/'corz_exposure_figure_metadata.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'data':str(target),'csv_rows':len(rows),'derived':data['derivations'],'figures':metadata['figures']},ensure_ascii=False,indent=2))

if __name__=='__main__':main()
