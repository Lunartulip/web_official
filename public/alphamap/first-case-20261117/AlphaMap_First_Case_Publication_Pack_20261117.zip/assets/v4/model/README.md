# AlphaMap First Case — reproducible model

Publication 1.2.0 · model 4.1 · cutoff 2026-11-17.

## Run

Use Python 3.11 or later. Install `requirements.txt`, then run `python run.py` from any directory. The model reads the three frozen demand, BOM and memory-supply JSON inputs under `tmp/`. It writes new calculations under `tmp/` and compares all decisive case/year outputs with `reference/`. Tested with SciPy 1.17.0. No network call, private database, login or API key is required.

The builder scripts for input modules are supplied for provenance. The primary reproducibility command uses the frozen input JSON rather than rebuilding upstream research assumptions. The reference model and hashes identify the delivered calculation; floating-point solver differences are checked with an explicit tolerance.

## What is independently estimated

The model joins a high-end cloud device path, product-family configurations, qualified HBM wafer capacity, generation matching, global facility IT scenarios, quarterly procurement and physical device cohorts. One-, two- and four-quarter procurement policies share the same opening inventory and one-quarter physical lag. No SemiAnalysis level or revision rate is an input.

## Boundaries that affect interpretation

These are conditional physical and financing scenarios, not statistically calibrated probabilities. Capacity, desired purchases, device-embedded HBM, supplier shipments and revenue are different measures. A zero net change in raw-HBM/work-in-process inventories is required for the embedded flow to proxy the covered cohort's supplier absorption. Other customers and unmatched memory remain separate.

Opening inventory composition, future device power/logic area, SKU mix, facility readiness and 2029–2030 continuation paths contain analytical assumptions. Processor foundry, CoWoS, substrates and boards are not separately solved global throughput constraints. No point forecast of the entire accelerator market, actual cancellations or stock-return alpha is certified.

The two SemiAnalysis source identities are kept distinct: supplied Nov13-vs-Nov2 charts and the separately identified Nov17 report summary. The latter's original, old baseline and metric perimeter remain unverified.

## Files

`../annual_results.csv`: scenario/year output, including fixed-mix infeasibility diagnostics explicitly flagged.
`../device_BOM_panel.csv`: modeled family/variant, annual desired quantities, nominal HBM, logic area and rated power.
`../HBM_supply_supplier_generation.csv`: supplier, generation, wafers, recovery and output.
`../interactive_grid.csv`: 27 actually computed combinations; no interpolation.
`../sources.json`: original-source register.
`../public_relationships.json`: curated research relationships, not a production AlphaMap database dump.

Copyright in linked source reports remains with their publishers. This package contains original calculations and chart assets, not copies of paywalled reports. AI reviews use CFA/CQF analytical frameworks; they are not professional certification or an external human audit.
