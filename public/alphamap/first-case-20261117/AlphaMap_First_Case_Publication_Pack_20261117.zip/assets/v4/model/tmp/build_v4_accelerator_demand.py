from pathlib import Path
import json
P=Path('/workspace/scratch/6aa42040b254/tmp')
a={'total_2027_m':25.951,'total_growth_2027':.645,'asic_2027_m':15.262,'asic_growth_2027':1.109,'nvidia_2027_m':9.096,'nvidia_growth_2027':.182,'google_2027_m':8.009,'google_growth_2027':1.34}
total26=a['total_2027_m']/(1+a['total_growth_2027'])
asic26=a['asic_2027_m']/(1+a['asic_growth_2027'])
gpu26=total26-asic26
nv26=a['nvidia_2027_m']/(1+a['nvidia_growth_2027'])
google26=a['google_2027_m']/(1+a['google_growth_2027'])
base={'nvidia_gpu':nv26,'other_gpu':gpu26-nv26,'google_tpu':google26,'other_asic':asic26-google26}
growth={
'nvidia_gpu':{'low':[.05,0,-.05,-.10],'base':[.20,.10,.05,0],'high':[.35,.25,.20,.15]},
'other_gpu':{'low':[.30,.10,0,0],'base':[.70,.40,.25,.20],'high':[1.10,.70,.45,.35]},
'google_tpu':{'low':[.40,.10,0,0],'base':[.85,.40,.25,.20],'high':[1.30,.70,.50,.40]},
'other_asic':{'low':[.35,.10,0,0],'base':[.70,.40,.25,.20],'high':[1.00,.60,.45,.35]}}
anchor_bounds={'nvidia_gpu':[.85,1.15],'other_gpu':[.75,1.25],'google_tpu':[.8,1.2],'other_asic':[.75,1.25]}
scenarios={}
for sc in ['low','base','high']:
 cur={k:v*(anchor_bounds[k][0] if sc=='low' else anchor_bounds[k][1] if sc=='high' else 1) for k,v in base.items()}
 rows=[]
 for y in range(2026,2031):
  if y>2026:cur={k:v*(1+growth[k][sc][y-2027]) for k,v in cur.items()}
  row={'year':y,**cur,'gpu_total':cur['nvidia_gpu']+cur['other_gpu'],'asic_total':cur['google_tpu']+cur['other_asic'],'high_end_cloud_core_total':sum(cur.values())}
  row['asic_share']=row['asic_total']/row['high_end_cloud_core_total']
  rows.append(row)
 scenarios[sc]=rows
sources=[
 {'id':'DT_OCT19','date':'2026-10-19','title':'Shipments of high-end cloud AI accelerators, 2027','url':'https://www.digitimes.com/reports/item.php?id=20261013RS400&q=hbm4','web_ref':'turn156search0','type':'original_research_publisher_estimate','access':'Public abstract retrieved in original-publisher indexed result; full paid model not accessed. Direct open returned temporary 403.','use':'Only backcast 2026 reference quantities anchor the independent forward model. Publisher 2027 targets are retained for comparison, not used as forward growth inputs.'},
 {'id':'TF_JUL03','date':'2026-07-03','title':'AI Server Industry Analysis 2Q26','url':'https://www.trendforce.com/research/download/RP260703GL3','web_ref':'turn142view2','type':'original_research_publisher_estimate','use':'AI-server cross-check: nearly 2.8m in 2026, 30.5% growth. No automatic conversion from servers to chips.'},
 {'id':'TF_OCT14','date':'2026-10-14','title':'CSP CapEx Projected to Exceed US$1.5 Trillion in 2027','url':'https://www.trendforce.com/presscenter/news/20261014-13269.html','web_ref':'turn142view0','type':'original_research_publisher_estimate','use':'Independent external cross-check only: server quantities vs prices, nine-CSP capex scope and prepayments.'},
 {'id':'TF_APR08','date':'2026-04-08','title':'Rubin Faces Delay Risks; Blackwell over 70% of 2026 high-end GPUs','url':'https://www.trendforce.com/presscenter/news/20260408-13003.html','web_ref':'turn151view3','type':'original_research_publisher_estimate','use':'2026 Nvidia high-end generation mix estimate 7% Hopper/71% Blackwell/22% Rubin; mid/low-end scope warning. Not observed SKU shipments.'},
 {'id':'NV_Q2FY27','date':'2026-08-26','title':'Q2 FY27 CFO Commentary','url':'https://www.sec.gov/Archives/edgar/data/1045810/000104581026000073/q2fy27cfocommentary.htm','web_ref':'turn172view0','type':'company_observation_and_guidance','use':'Revenue cross-check: DC89.023bn, hyperscale48.710bn, ACIE40.313bn. Compute & Networking88.299bn is a different reportable segment, not standalone DC compute.'},
 {'id':'NV_BLACKWELL_UNIT','date':None,'retrieved_as_of':'2026-11-17','title':'NVIDIA Blackwell architecture','url':'https://www.nvidia.com/en-us/data-center/technologies/blackwell-architecture/','web_ref':'turn168search6','type':'official_product_definition','use':'Two reticle-limited compute dies form one logical GPU. One GPU unit is not one compute die.'},
 {'id':'GOOGLE_NOV09','date':'2026-11-09','title':'TPU 8tx and TPU 8i Max','url':'https://cloud.google.com/blog/topics/ai-infrastructure/tpu-8tx-and-tpu-8i-max','web_ref':'turn166view0','type':'official_product_definition_and_business_observation','use':'8tx uses 8t silicon; 8i Max combines two 8i chips on one package. Nearly100 TPU customers; annual shipped units not disclosed.'},
 {'id':'AMD_Q3','date':'2026-11-03','title':'AMD Q3 2026 results','url':'https://ir.amd.com/news-events/press-releases/detail/1303/amd-reports-third-quarter-2026-financial-results','web_ref':'turn160search1','type':'company_observation_and_guidance','use':'Data Center8.5bn+97%, first MI450/Helios deployments. CPU+GPU revenue is not GPU revenue or units.'},
 {'id':'AMZN_Q1','date':'2026-04-29','title':'Amazon Q1 2026 results','url':'https://ir.aboutamazon.com/news-release/news-release-details/2026/Amazon-com-Announces-First-Quarter-Results/default.aspx','web_ref':'turn160search14','type':'company_observation_and_plan','use':'2.1m+ AI chips landed over past12months, over half Trainium; 1m+ NVIDIA GPU deployment starting2026. Rolling deliveries and plans are not CY2026 shipments and cannot be added to industry totals.'},
 {'id':'MSFT_MAIA','date':'2026-10-12','title':'Azure Maia multi-gigawatt deployments','url':'https://blogs.microsoft.com/blog/2026/10/12/microsoft-to-expand-azure-maia-system-to-multi-gigawatt-deployments/','web_ref':'turn206search2','type':'company_product_and_plan','use':'Custom ASIC expansion supports a rising mix; no disclosed annual volume used.'},
 {'id':'META_MTIA','date':'2026-03-11','title':'Four MTIA Chips in Two Years','url':'https://ai.meta.com/blog/meta-mtia-scale-ai-chips-for-billions','web_ref':'turn206search7','type':'company_product_and_plan','use':'2026/27 ASIC product cadence; annual volumes unknown, no unsupported unit additive.'}
]
growth_rationale={
'nvidia_gpu':'2027 base20% physical units, then10/5/0%: pre-event reported revenue/capacity backlog is strong, but higher memory/system content, price, efficiency and ASIC substitution prevent translating revenue growth directly into units. This is an analyst assumption, not company guidance or a calibrated probability.',
'other_gpu':'Small base and confirmed MI450/Helios launch justify a faster initial70% unit ramp, tapering40/25/20%; broad alternative range tests adoption/qualification limits. CPU revenue is not converted into GPU counts.',
'google_tpu':'External TPU access and nearly100 customers plus own workloads justify an85% base unit expansion in2027, decaying40/25/20% as platform adoption matures. This is not copied from the publisher134% 2027 forecast.',
'other_asic':'AWS, Microsoft and Meta product launches support70% unit expansion in2027, tapering40/25/20%; the bucket also contains unseparated vendors/architectures. No CSP capex dollars are added as incremental physical demand.'}
d={
 'version':'v4.1_frozen_quantity_panel_with_primary_buyer_bridges','as_of':'2026-11-17','research_component_status':'conditional_demand_forecast_quantified; supply_realization_and_scope_residual_to_integrate',
 'semi_analysis_values_used_as_inputs':False,
 'forecast_type':'Analyst desired-purchase/device-demand scenarios anchored to independently published 2026 estimates; not observed shipment outcomes, statistically calibrated probabilities or independently proved supply-demand equilibrium.',
 'unit':'million nominal high-end cloud accelerator device/chip units; use per-SKU definitions, not server/rack/compute-die counts',
 'definition':{'gpu':'One logical accelerator GPU. Blackwell has two compute dies per one GPU.','asic':'One accelerator-chip unit under publisher convention; original detailed counting dictionary unavailable. Treat TPU8i Max package as two TPU8i silicon units when starting from chip count. Do not double units and per-unit HBM together.','excluded_or_unverified':'Low-end/GDDR AI GPUs, edge/workstation accelerators, non-cloud enterprise scope, exact China/vendor completeness and packaging-count convention not completely disclosed in the public abstract.','memory_convention':'This file supplies device counts, not memory bytes. Use nominal supply-chain GB/EB consistently in BOM integration; keep physical SI bytes and usable capacity separate.'},
 'reference_2026':{'status':'derived_from_original_research_estimates_not_observed','source_id':'DT_OCT19','published_forward_numbers_for_backcast_only':a,'formula':'Q2026=publisher_Q2027/(1+publisher_growth); GPU=total-ASIC; residual cohorts by subtraction','cohorts_m':base,'gpu_total_m':gpu26,'asic_total_m':asic26,'total_m':total26,'rounding':'Underlying ratios are rounded publisher inputs; show ~0.1m in prose, not false thousand-unit accuracy.'},
 'growth_assumptions':{'years':[2027,2028,2029,2030],'rates':growth,'rationale':growth_rationale,'2026_anchor_multipliers_low_high':anchor_bounds,'range_definition':'Deliberately broad analyst joint downside/upside paths, including base-count uncertainty. They are sensitivity envelopes, not confidence intervals or quantiles.'},
 'scenarios_m':scenarios,
 'own_base_case_logic':'Demand continues to expand while the incremental mix shifts toward ASICs. GPU unit growth decelerates even without the leadership event as performance/content per device and custom designs improve. Physical units do not imply vendor revenue, profits or stock returns one-for-one.',
 'baseline_timing':'Reconstructed no-leadership-event counterfactual using information available by2026-11-17; not an archived forecast claimed to exist on2026-11-11. Numeric anchors here are pre-event; Nov16 industry revision is not a forward-model input.',
 'coverage_residual':{'core_scope':'High-end cloud accelerator estimate universe of the original research publisher; detailed population unavailable in the public abstract.','base_additive_units_m':0,'zero_means':'No unverified additive that may double-count the publisher universe; not proof that all datacenter/China/enterprise units are covered.','sensitivity_additive_fraction_of_core':[0,.10,.20],'sensitivity_status':'Analyst coverage stress, not measured residual; map actual vendor/segment additions before treating as demand.','non_HBM_residual':'Keep low-end/GDDR and SRAM-heavy products in a separate non-HBM branch; do not multiply all extra AI units by the high-end average HBM.'},
 'initial_nvidia_sku_mix':{'2026':{'hopper':.07,'blackwell_family':.71,'rubin_family':.22},'2027':{'hopper':.02,'blackwell_family':.18,'rubin_family':.80},'2028':{'blackwell_family':.03,'rubin_family':.47,'successor_not_specified':.50},'2029':{'rubin_family':.15,'successor_not_specified':.85},'2030':{'rubin_family':.05,'successor_not_specified':.95},'status':'2026 uses dated TF forecast as approximate mix;2027+ are analyst transition assumptions, not observed SKU orders. Successor BOM must be bounded, not fabricated.'},
 'leadership_event':{'current_evidenced_quantity_delta_m':0,'meaning':'No verified incremental contract cancellation or physical unit withdrawal in the reviewed material; zero is current evidence-based adjustment, not proof of no future impact.','mechanism':'Only an activated, unreplaced funding or delivery constraint on a mapped project changes its schedule. Existing supplier/customer/credit-support edges do not mechanically transmit a CEO change to all GPU or ASIC demand.','conditional_funding_equivalent':{'funding_shortfall_usdbn':[1,9],'deployed_equipment_cost_per_gpu_usd_assumption':[50000,100000],'formula':'unreplaced_binding_shortfall/within-scope equipment cost per GPU','units_m_bounds_by_shortfall':{'1':[.01,.02],'9':[.09,.18]},'status':'Illustrative capacity-equivalent bound, not observed gap, cancellation, probability or annual global haircut; full9bn customer advances are not assumed lost. Sources of cash and payment timing must be aligned.'}},
 'realization_interface':{'required_from_supply_model':'For each compatibleSKU/memory generation, realized units <= demand units and <= allocable HBM bits / nominalGB_per_device; also enforce packaging/power constraints.','equation':'Global completed shipments require cohort allocation and supplier-to-device production lags; do not match same-year HBM output to device demand without inventory/lead adjustment.','residual_terms':['HBM lead/lag','supplier/device inventory change','non-modeled HBM users','China/non-cloud overlap','non-HBM AI units']},
 'sources':sources,
 'reproduce_command':'python /workspace/scratch/6aa42040b254/tmp/build_v4_accelerator_demand.py'
}

# The 2026 anchor and all forward scenario quantities above remain frozen. The
# following primary-source bridges test those quantities; they are not additive
# orders on top of them and do not retrospectively calibrate them to another
# research house's forward forecast.
new_sources=[
 {'id':'NV_Q2FY27_CALL','date':'2026-08-26','title':'NVIDIA Q2 FY27 earnings call, company-hosted transcript','url':'https://investor.nvidia.com/files/content_files/TRANSCRIPT_-NVIDIA-Corp-NVDA-US-Q2-2027-Earnings-Call-26-August-2026-5_00-PM-ET.pdf','web_ref':'turn235view0','type':'company_plan_and_guidance','facts':'AWS additional2m GPUs from Q3FY27 through Q2FY29. FY28 revenue growth about70%, supply constrained. Platform opportunity Blackwell25bn/GW and Rubin40bn/GW includes CPUs/networking; not GPU ASP.'},
 {'id':'ANTH_GOOGLE_MAY06','date':'2026-05-06','title':'Anthropic compute update','url':'https://www.anthropic.com/news/higher-limits-spacex','web_ref':'turn235view1','type':'company_contract_capacity_plan','facts':'Google/Broadcom5GW agreement starts coming online in2027; no annual phase schedule disclosed.'},
 {'id':'ANTH_AWS_APR20','date':'2026-04-20','updated':'2026-04-21','title':'Anthropic and Amazon expand compute collaboration','url':'https://www.anthropic.com/news/anthropic-amazon-compute','web_ref':'turn235view2','type':'company_contract_capacity_plan','facts':'Up to5GW new capacity, nearly1GW by end2026. Over1m Trainium2 already in use is installed stock. Over100bn spend over10years includes Graviton and Trainium; not annual hardware purchases.'},
 {'id':'AMD_OPENAI_OCT25','date':'2025-10-06','title':'AMD/OpenAI multi-year6GW partnership','url':'https://newsroom.amd.com/news/amd-and-openai-announce-strategic-partnership-to-d/','web_ref':'turn236view0','type':'company_multi_year_agreement','facts':'6GW multi-generation program; initial1GW starts2H2026. No complete annual delivery schedule.'},
 {'id':'AMD_META_FEB26','date':'2026-02-24','title':'AMD/Meta expanded partnership','url':'https://newsroom.amd.com/news/amd-and-meta-announce-expanded-strategic-partnersh/','web_ref':'turn236view1','type':'company_multi_year_agreement','facts':'Up to6GW; shipments for first1GW start2H2026. No complete annual delivery schedule.'},
 {'id':'OPENAI_AVGO_OCT25','date':'2025-10-13','title':'OpenAI/Broadcom10GW collaboration','url':'https://openai.com/index/openai-and-broadcom-announce-strategic-collaboration/','web_ref':'turn245view0','type':'company_program_and_term_sheet','facts':'10GW accelerator/network systems targeted to start2H2026 and complete by end2029; rack deployment term sheet, not disclosed annual purchase schedule.'},
 {'id':'META_AVGO_APR26','date':'2026-04-14','title':'Meta/Broadcom custom silicon partnership','url':'https://about.fb.com/news/2026/04/meta-partners-with-broadcom-to-co-develop-custom-ai-silicon/','web_ref':'turn245view1','type':'company_capacity_commitment','facts':'Initial commitment exceeds1GW, first phase of multi-GW rollout; no annual quantities in this release.'},
 {'id':'AVGO_ANTH_8K','date':'2026-04-06','title':'Broadcom8-K','url':'https://investors.broadcom.com/static-files/c906d370-921b-4bc2-bb7b-57877dfcf1ae','web_ref':'turn237search9','type':'company_regulatory_filing','facts':'Approximately3.5GW viaBroadcom beginning2027 is part of Anthropic multi-GW program; dependent on continued commercial success. Do not add3.5GW to5GW.'},
 {'id':'AVGO_ANTH_FIN_OCT26','date':'2026-10-26','title':'63bn financing structure for Anthropic XPU compute','url':'https://investors.broadcom.com/news-releases/news-release-details/bank-america-blackstone-citi-and-morgan-stanley-announce','web_ref':'turn239view2','type':'company_financing_announcement','facts':'63bn SPV transaction with committed financing; XPU/networking equipment leased to Anthropic; deliveries expected from2027. Broadcom residual support equals first-lien amount, not entire63bn. Commitment is not cash draw, delivery or additional demand.'},
 {'id':'TOALPHA_OCT16','date':'2026-10-16','title':'The Great Unbundling of AI ASICs','url':'https://toalpha.tw/reports/toalpha-ai-asic-unbundling-20261016-en.pdf','web_ref':'turn236view3','type':'original_research_publisher_estimate','use':'After-freeze independent comparison only: TPU2027/28 8.5m/10.5m; Trainium2027 2.9m. No values used as our forward inputs. COT revenue excludes buyer-procured wafers/HBM; design-service revenue cannot identify accelerator units.'},
 {'id':'DT_CHINA_APR26','date':'2026-04-20','title':'China high-end cloud AI accelerator market report','url':'https://www.digitimes.com/reports/item.php?id=20260420RS400&q=led','web_ref':'turn206search16','type':'original_research_publisher_estimate','facts':'Public abstract estimates domesticChina2026high-endcloud accelerator2.12m; overlap with October global universe unresolved. Not automatically additive.'}
]
d['sources'].extend(new_sources)
for s in d['sources']:
 if s['id']=='AMZN_Q1':
  s['web_ref']='turn236view2'
  s['use']='OpenAI approximately2GW Trainium starts ramping2027. More than2.1m AI chips landed in trailing12months, over halfTrainium; not CY shipments. Older1m+NVIDIA plan may overlap August2mplan, so never add both.'
 if s['id']=='MSFT_MAIA':
  s['web_ref']='turn235view3'
  s['use']='Multi-GW Maia deployments start2027; officialMaia300rack96accelerators/167kW. No numeric annual capacity guidance; illustrative2GW program below is an analyst scenario.'

def gw_program(pid,cohort,source_ids,online_gw,kw,kw_low,kw_high,company_fact,assumption,cap_gw=None):
 lead=.10
 years=range(min(online_gw)-1,max(online_gw)+1)
 rows=[]
 for y in years:
  shipped_gw=(1-lead)*online_gw.get(y,0)+lead*online_gw.get(y+1,0)
  rows.append({'year':y,'online_gw':online_gw.get(y,0),'hardware_equivalent_gw':shipped_gw,'devices_m':shipped_gw/kw,'devices_m_power_bounds':[shipped_gw/kw_high,shipped_gw/kw_low]})
 assert abs(sum(r['hardware_equivalent_gw'] for r in rows)-sum(online_gw.values()))<1e-9
 if cap_gw is not None:assert sum(online_gw.values())<=cap_gw+1e-9
 return {'id':pid,'cohort':cohort,'source_ids':source_ids,'company_fact':company_fact,'model_assumption':assumption,'status':'primary_program_with_analyst_phasing_and_power_conversion; not firm_yearly_orders','power_boundary':'Assume announcementGW refers to deployed rack/IT power, not pure chip TDP. If facilitypower, multiply units by1/PUE; if chip-onlypower, replace denominator. Boundary not standardized in company release.','effective_kw_per_accelerator':{'base':kw,'low':kw_low,'high':kw_high,'status':'engineering assumption except officialMaia rackratio'},'hardware_prebuy_next_year_fraction':lead,'formula':'hardwareGW_y=0.9*onlineGW_y+0.1*onlineGW_(y+1); devices_m=hardwareGW/effectivekWperdevice','online_total_gw':sum(online_gw.values()),'annual':rows}

programs=[
 {'id':'AWS_NVIDIA_2M','cohort':'nvidia_gpu','source_ids':['NV_Q2FY27_CALL'],'company_fact':'Additional2mGPUs fromQ3FY27 toQ2FY29.','model_assumption':'Uniform24-month deliveries Aug2026-Jul2028; useCY2026five,CY2027twelve,CY2028sevenmonths. Calendar mapping and uniform phasing are analyst assumptions.','status':'primary_unit_program_with_analyst_phasing','annual':[{'year':2026,'devices_m':2*5/24},{'year':2027,'devices_m':2*12/24},{'year':2028,'devices_m':2*7/24}], 'dedup':'OlderAmazonApril1m+GPUannouncement is not added separately.'},
 gw_program('AMD_OPENAI_META_12GW','other_gpu',['AMD_OPENAI_OCT25','AMD_META_FEB26'],{2026:.4,2027:1.6,2028:2.4,2029:3.0,2030:3.0,2031:1.6},2.4,2.0,2.8,'Two distinct up-to6GW multi-year programs; first1GW at each begins2H2026.','Per customer online0.2/0.8/1.2/1.5/1.5/0.8GW across2026-31. This is conditional completion of both programs, not all12GW in2027.',12),
 gw_program('GOOGLE_ANTHROPIC_5GW','google_tpu',['ANTH_GOOGLE_MAY06','AVGO_ANTH_8K'],{2027:2.75,2028:1.75,2029:.5},2.0,1.8,2.4,'5GW begins coming online2027. 3.5GW viaBroadcom is a subset.','55/35/10% of this program online2027/28/29. Do not use unverified additional2028program claims;2026hardware is prebuy, notoperatingcapacity.',5),
 gw_program('AWS_ANTHROPIC_5GW','other_asic',['ANTH_AWS_APR20'],{2026:.95,2027:1.05,2028:1.25,2029:1.0,2030:.75},1.6,1.3,2.0,'Up to5GW newTrainium capacity; nearly1GWbyend2026.','0.95GWin2026 approximates nearly1GW; remaining4.05GW staged2027-30. Power ratio approximates mixedTrainium/rackcontent. Fulloptionexercise is conditional.',5),
 gw_program('AWS_OPENAI_2GW','other_asic',['AMZN_Q1'],{2027:.75,2028:.85,2029:.4},1.6,1.3,2.0,'Approximately2GW Trainium beginsramping2027.','Stage37.5/42.5/20%in2027/28/29. Sharedphysicalprojects not disclosed; this represents intended workload commitments, not independently verified disjoint purchasedsites.',2),
 gw_program('MAIA_ILLUSTRATIVE_2GW','other_asic',['MSFT_MAIA'],{2027:1.0,2028:1.0},167/96,167/96,167/96,'Multi-GWdeploymentstarting2027;96devicesper167kWrack.','Analystillustration2GWtotal over2027/28, notMicrosoft2GWguidance. Fullrackratio used; externalnetwork/storage power can lower units.',2),
 gw_program('OPENAI_BROADCOM_10GW','other_asic',['OPENAI_AVGO_OCT25'],{2026:.1,2027:1.2,2028:3.6,2029:5.1},2.0,1.6,2.5,'10GW program,target2H2026-end2029; deploymenttermsheet.','Backloaded0.1/1.2/3.6/5.1GW modelphases; noannualdeliveryclaim.2kW/devicegenericfutureASIC assumption. Financing,shells,powerandproductqualification remainconditions.',10),
 gw_program('META_BROADCOM_FIRST_GW','other_asic',['META_AVGO_APR26'],{2027:.4,2028:.6},2.0,1.6,2.5,'Initialcommitmentexceeds1GW;multi-GWrollout.','Only1GW firstphase modelled,0.4/0.6GWin2027/28. PowerconversiongenericfutureASIC. Remainingmulti-GWprogramnotquantifiedhere.',1)
]
named_by_cohort={k:{y:0.0 for y in range(2026,2031)} for k in base}
for p in programs:
 for r in p['annual']:
  if r['year'] in named_by_cohort[p['cohort']]:named_by_cohort[p['cohort']][r['year']]+=r['devices_m']
bridges={}
for k in base:
 previous=None
 rows=[]
 for r in scenarios['base']:
  y=r['year'];named=named_by_cohort[k][y];remaining=r[k]-named
  assert remaining>=0
  rows.append({'year':y,'frozen_cohort_target_m':r[k],'named_program_conditional_device_flow_m':named,'other_customer_and_replacement_pool_m':remaining,'required_remaining_pool_growth':None if previous is None else remaining/previous-1,'named_flow_share_of_target':named/r[k]})
  previous=remaining
 bridges[k]=rows
d['buyer_program_bridge']={'purpose':'Quantitative falsification/coverage bridge for frozen demand path, not independent validation of every target and not new quantities added on top.','all_programs_are_conditional':'NamedGW announcements still require phasing,powerdefinition,qualification,financingandphysicaldelivery. Someareoptions/termsheets. Flow is new annualpurchases, not installedstock.','source_graph':'Primarycompanyprograms are public-evidence supplementation, not all alreadypresentinAlphaMapsourcegraph. Preserveprovenance and mapentities/projectIDs beforepersisting.','programs':programs,'cohort_bridge':bridges,'mandatory_readout':'Explicitly show residualpoolgrowth. GoogleTPUrequires~52%/61% residualgrowth2027/28 evenunderthis5GWprojectscenario; namedcontractdoesnotvalidate85%/40%wholecohortgrowth. Otherprogramflowslikewiseconditional,notobservedorders.','dedup_controls':['Do notaddprogramflowstomarketcohorttotals.','Google3.5GWviaBroadcomispartof5GW.','AWSApril1m+NVIDIAandAugust2mnotseparatelyadded.','AMDtwo6GWarenot12GWone-yearshipments.','OpenAIAWS/AMD/Broadcomuse distincthardwarefamiliesbutmaycompeteforsamefunding;notindependentdemandprobabilities.','FutureBroadcom20GWplatformcapacityor63bnfinancingisnotanadditionalGPU/ASICorder.']}

# Keep scenario comparison separate from inputs.
d['after_freeze_external_cross_checks']={
 'toalpha_google_tpu':[{'year':y,'our_base_m':scenarios['base'][y-2026]['google_tpu'],'external_estimate_m':ext,'our_vs_external':scenarios['base'][y-2026]['google_tpu']/ext-1,'source_id':'TOALPHA_OCT16'} for y,ext in [(2027,8.5),(2028,10.5)]],
 'toalpha_trainium_2027_m':{'value':2.9,'source_id':'TOALPHA_OCT16','our_named_AWS_program_flow_m':sum(next(r['devices_m'] for r in p['annual'] if r['year']==2027) for p in programs if p['id'] in ['AWS_ANTHROPIC_5GW','AWS_OPENAI_2GW']),'meaning':'Ourprogrambridgecoversnamednewworkloads only;remainingAWSownuse,othercustomersandreplacementnotseparatedfromotherASICpool. Noequivalenceclaim.'},
 'trendforce_server_definition_check':{'server_2025_m_derived':2.8/1.305,'server_2026_m_updated_proxy':2.8/1.305*1.322,'server_2027_m_proxy':2.8/1.305*1.322*1.36,'core_devices_per_reported_server_2026':total26/(2.8/1.305*1.322),'core_devices_per_reported_server_2027':scenarios['base'][1]['high_end_cloud_core_total']/(2.8/1.305*1.322*1.36),'source_ids':['TF_JUL03','TF_OCT14'],'meaning':'Cross-vintageandpossiblydifferentpopulationproxy; not8GPUserverconversionorquantityvalidation.'},
 'independence_limit':'Independent ofSemiAnalysis, not independent of allpublicindustryestimates. The2026baseisDigiTimesinferredestimate; forwardgrowth/phasingareourassumptions. Correlatedresearchsourcesare not independent measurements.'}

d['financial_consistency_checks']={
 'nvidia_Q2FY27':{'reported_DC_revenue_usdbn':89.023,'GPU_attribution_fraction_assumption':[.75,.90],'recognized_attributed_revenue_per_GPU_usd_assumption':[35000,50000],'implied_quarterly_gpu_equivalent_m_bounds':[89.023*.75/50,89.023*.90/35],'implied_fraction_of_2026_NV_units_bounds':[89.023*.75/50/nv26,89.023*.90/35/nv26],'meaning':'Assumption-only consistencyenvelope; noobservedASP or actualquarterunits. Segment includes networking/CPU/systemcontent; fiscalquarter differsCY. Notusedtocalibratebase.','source_id':'NV_Q2FY27'},
 'nvidia_FY28_growth_vs_CY27_units':{'company_revenue_growth_guide':.70,'assumed_GPU_attribution_share_ratio':[.85,1.0],'our_CY2027_unit_growth':.20,'required_attributed_revenue_per_device_growth_range':[1.7*.85/1.2-1,1.7/1.2-1],'formula':'revenueperdevice_ratio=revenue_ratio*GPUattributionshare_ratio/unit_ratio','meaning':'FY28approximatelyalignsCY2027, notexact.20%unitgrowthrequires20-42%attributedrevenue/deviceupliftunderstatedshareassumptions; productmixandmoreplatformcontentcancontribute. NotforecaststandaloneGPUASP.','source_id':'NV_Q2FY27_CALL'},
 'capex_rule':'CSPtotalcashcapex,leasedassets,prepaymentsandnonAIinfrastructurearenotwholeacceleratorbudgets. Do notdivideunadjustedcapexbyassumedGPUASP. COTdesignpartnerrevenueisnotcompleteASICrevenue.',
 'anthropic_63bn_financing':{'announced_transaction_usdbn':63,'date':'2026-10-26','source_id':'AVGO_ANTH_FIN_OCT26','capacity_bound':'NoGWorunit conversion; samepreviouslyannouncedprogram. Financingiscommitted, notalldrawn. First-lienamountnotdisclosedhere;donotsetresidualsupport=63bn.'}}
d['coverage_residual']['china_overlap_note']='SeparateAprilDigiTimes2.12mChinaestimate mayalreadybeinOctoberglobalcore. Do notadditwithoutvendoroverlapreconciliation.'
d['realization_interface']['other_asic_compatible_top3_HBM_fraction_sensitivity']={'values':[.8,.9,1.0],'status':'unobservedanalystcompatibilityscopeassumption,notknownChina/nonHBMmarketshare','formula':'applyonlytothisoverlappingdemandpoolbeforecomparingSamsung/SKHynix/Micronallocablesupply;other20%maxneedsseparatesupply/nonHBMroute,notfreeunconstrainedproduction','reason':'OtherASICbucketmayincludeChina/domesticmemoryornonHBMproducts;cannotforceeverydeviceagainsttop3HBM.'}
d['far_term_assumptions']={'2029_2030':'Growthtapersratherthanextrapolating2027launchrate: NVIDIA5/0%,otherGPU25/20%,TPU25/20%,otherASIC25/20%.','status':'Structuralextensionassumption, notproject-by-projectforecast. Newworkloadgrowth/replacementmustoutweighefficiency/customsiliconsubstitution. No2029/30namedcontractscompletewholemarketcoverage.','display':'Showroundedrangeandbaseonly; do notclaimmostprobablepathorprobabilitycalibration.'}
d['demand_robustness_checks']=[]
for y in [2027,2028]:
 b=scenarios['base'][y-2026]
 remaining={k:bridges[k][y-2026]['other_customer_and_replacement_pool_m'] for k in base}
 stressed={k:b[k]-.2*remaining[k] for k in base}
 stressed_gpu=stressed['nvidia_gpu']+stressed['other_gpu']
 stressed_asic=stressed['google_tpu']+stressed['other_asic']
 d['demand_robustness_checks'].append({'year':y,'status':'deterministicsensitivity,notforecastprobability','base_total_m':b['high_end_cloud_core_total'],'all_demand_down20pct_total_m':b['high_end_cloud_core_total']*.8,'only_unnamed_pool_down20pct_total_m':sum(stressed.values()),'only_unnamed_pool_down20pct_by_cohort_m':stressed,'only_unnamed_pool_down20pct_asic_share':stressed_asic/(stressed_gpu+stressed_asic),'ASIC_only_uniform_drop_that_equalizes_GPU_fraction':1-b['gpu_total']/b['asic_total'],'ASIC_only_down20pct_m':b['asic_total']*.8,'GPU_unchanged_m':b['gpu_total'],'interpretation':'ASIC-over-GPUheadlineisnotunconditionallyrobust: usequantifiedthreshold,notthejointlowpathwherebothGPU/ASICdecline.'})
d['validation']={'frozen_base_panel_unchanged':True,'cohort_sums_pass':all(abs(r['gpu_total']+r['asic_total']-r['high_end_cloud_core_total'])<1e-9 for rs in scenarios.values() for r in rs),'named_program_flows_not_added_to_totals':True,'program_hardware_phasing_conserves_capacity':True,'all_remaining_pools_nonnegative':True,'events_not_uniformly_haircut':True,'forecast_not_claimed_observed':True}
(P/'v4_accelerator_demand.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')

labels={'nvidia_gpu':'NVIDIA GPU','other_gpu':'其他 GPU','google_tpu':'Google TPU','other_asic':'其他 ASIC'}
md=['# 独立加速器需求与设备数量模型','',
'**截至 2026-11-17；v4.1。** 这是一份以独立行业基期、公司公开项目和明确参数构建的条件需求预测。没有使用 SemiAnalysis 的数量、削减幅度、价格、份额或远期增长作为输入。2026 年锚点仍是原始研究机构的估计，不是实际出货；2027—2030 年是本模型假设。需求、受约束的供给实现量、公司收入与股东收益需要分开。','',
'基准高端云加速器需求从 2026 年约 **1,580 万颗**升至 2027 年 **2,350 万颗**、2028 年 **3,010 万颗**；其中 ASIC 占比从约 46% 升至 55% 和 60%。公开项目能够解释部分增量，尚不能单独验证整个市场的增长率。Google TPU 其余客户池在 2027/28 年须增长约 **52%/61%**，这是基准最需要监控的需求假设。','',
'## 1. 数量口径与基期','',
'一颗 NVIDIA GPU 可以含两个计算裸片，不能把 die 数当 GPU 数。TPU 按供应链 chip/device 口径计数；TPU 7 的软件逻辑设备、TPU 8i Max 的双芯片封装另行转换，不能同时把数量和单颗 HBM 翻倍。服务器台数与机架数均不直接乘八换算。','',
'2026 年基期来自 DIGITIMES 2026-10-19 原始报告的公开摘要：将其 2027 年数量除以相应同比倍率，再作 GPU/ASIC 和厂商残差拆分。完整付费模型及计数词典未读取；因此本模型只称其为“高端云核心范围”，不宣称覆盖全部企业、边缘、低端或中国加速器。源数据的舍入误差要求对外保留约 0.1 百万颗的精度。[DT_OCT19]','',
'公式：`Q2026 = 公开Q2027 / (1 + 公开同比)`；`GPU = 全部 − ASIC`；其他厂商由相应总量减已识别厂商。只用反推的 2026 年估计作起点，原机构 2027 年增速不成为本模型的预测增速。','',
'## 2. 冻结的需求面板','',
'单位：百万颗，均为高端云核心范围。','',
'| 年份 | NVIDIA | 其他GPU | GPU合计 | Google TPU | 其他ASIC | ASIC合计 | 总量 | ASIC占比 |',
'|---|---:|---:|---:|---:|---:|---:|---:|---:|']
for r in scenarios['base']:
 md.append(f"| {r['year']} | {r['nvidia_gpu']:.2f} | {r['other_gpu']:.2f} | {r['gpu_total']:.2f} | {r['google_tpu']:.2f} | {r['other_asic']:.2f} | {r['asic_total']:.2f} | {r['high_end_cloud_core_total']:.2f} | {r['asic_share']:.1%} |")
md+=['','| 年份 | 联合低路径 | 基准 | 联合高路径 |','|---|---:|---:|---:|']
for i,y in enumerate(range(2026,2031)):
 md.append(f"| {y} | {scenarios['low'][i]['high_end_cloud_core_total']:.2f} | {scenarios['base'][i]['high_end_cloud_core_total']:.2f} | {scenarios['high'][i]['high_end_cloud_core_total']:.2f} |")
md+=['','这些范围同时改变基期误差和以后每年的增长率，是压力包络，不是置信区间，更不是低/中/高概率。尤其 2029—2030 年仅是结构延伸：NVIDIA 增长放慢至 5%/0%，其他 GPU 与 ASIC 为 25%/20%。需要由新需求、替换周期、供电和可交付供给重新校验，不能把远期高路径视为可实现出货。','',
'2027/28 年基准增长：NVIDIA 20%/10%；其他 GPU 70%/40%；Google TPU 85%/40%；其他 ASIC 70%/40%。这些数字保留为可证伪的条件预测，下列桥表把它们拆成具名计划及其他客户所需增长，避免用产品发布本身证明数量。','',
'## 3. 从具名项目到年度设备流量','',
'所有项目均在上述市场总量内拆分，不再相加。除 AWS 的直接 GPU 数量外，默认公告 GW 为机架/IT 电力口径，以包含相应机架内容的每颗有效 kW 换算；若原口径是全园区电力，应再除以 PUE，若是芯片功率则要更换分母。公司没有统一披露该边界，因此功率转换仍属假设。','',
'模型将 10% 的下一年上线设备提前采购：`硬件GW_y = 0.9 × 上线GW_y + 0.1 × 上线GW_(y+1)`；`百万颗 = 硬件GW / 每颗有效kW`。不能把上线 MW、采购 MW、已通电 MW 和已收入确认的 MW 混为一谈。','',
'| 项目 | 已公开边界 | 本模型分期与换算 | 2027设备流量m | 2028设备流量m |',
'|---|---|---|---:|---:|',
'| AWS新增NVIDIA | 额外2m，Q3FY27—Q2FY29 [NV_Q2FY27_CALL] | 假设2026年8月—2028年7月均匀交付 | 1.000 | 0.583 |',
'| AMD×OpenAI/Meta | 各6GW/至多6GW，多年；首1GW在2H26开始 [AMD_OPENAI_OCT25; AMD_META_FEB26] | 两项目合计2026—31上线0.4/1.6/2.4/3/3/1.6GW；2.4kW/颗，范围2.0—2.8 | 0.700 | 1.025 |',
'| Google/Broadcom×Anthropic | 5GW从2027开始上线；Broadcom3.5GW属于其中 [ANTH_GOOGLE_MAY06; AVGO_ANTH_8K] | 2027/28/29分55%/35%/10%；2.0kW/颗，范围1.8—2.4 | 1.325 | 0.813 |',
'| AWS×Anthropic | 至多5GW；2026年底接近1GW [ANTH_AWS_APR20] | 2026—30上线0.95/1.05/1.25/1/.75GW；1.6kW/颗，范围1.3—2.0 | 0.669 | 0.766 |',
'| AWS×OpenAI | 约2GW Trainium，从2027爬坡 [AMZN_Q1] | 2027/28/29上线.75/.85/.4GW；1.6kW/颗 | 0.475 | 0.503 |',
'| Maia示例 | 2027开始多GW；96颗/167kW机架 [MSFT_MAIA] | **自设**2GW两年上线各1GW；非微软2GW指引 | 0.575 | 0.517 |',
'| OpenAI×Broadcom | 10GW项目，2H26—2029年底目标；机架部署term sheet [OPENAI_AVGO_OCT25] | 2026—29上线.1/1.2/3.6/5.1GW；2.0kW/颗，范围1.6—2.5 | 0.720 | 1.875 |',
'| Meta×Broadcom首期 | 首期超过1GW，后续多GW [META_AVGO_APR26] | 只取首1GW，2027/28上线.4/.6GW；2.0kW/颗 | 0.210 | 0.270 |','',
'以上分期、提前采购、每颗功率及期权行使均为模型假设，不是已核实年度采购订单。AWS 的早期“1m+ NVIDIA”公告不与后来“新增2m”重复相加。Anthropic 当前使用的百万颗 Trainium 是安装存量，不额外计作当年新增。OpenAI 的不同芯片项目仍竞争同一个客户预算，不能赋予彼此独立的实现概率。','',
'### 基准必须满足的剩余客户增长','',
'“其他客户池”包含未逐项目识别的自用需求、外部客户和设备替换。它是剩余量，不能直接称为真实订单。','',
'| 分组 | 2027总目标m | 具名条件流量m | 其他池m | 其他池所需增长 | 2028总目标m | 具名条件流量m | 其他池m | 其他池所需增长 |',
'|---|---:|---:|---:|---:|---:|---:|---:|---:|']
for k in base:
 a1,a2=bridges[k][1:3]
 md.append(f"| {labels[k]} | {a1['frozen_cohort_target_m']:.2f} | {a1['named_program_conditional_device_flow_m']:.2f} | {a1['other_customer_and_replacement_pool_m']:.2f} | {a1['required_remaining_pool_growth']:.1%} | {a2['frozen_cohort_target_m']:.2f} | {a2['named_program_conditional_device_flow_m']:.2f} | {a2['other_customer_and_replacement_pool_m']:.2f} | {a2['required_remaining_pool_growth']:.1%} |")
md+=['','这张表允许作出不同强度的判断：NVIDIA 的2027年20%数量增长，扣除已公布AWS计划后，要求其余客户池增长约13%；AMD相关新品让其他GPU的小基数增长有可识别项目基础。Google TPU的52%/61%残差则仍然很高，单靠5GW合同不能验证其全行业路径。其他ASIC的29%/34%残差更低，但具名计划中有term sheet、自设分期和未确定功率，仍需有条件表达。','',
'## 4. 金额与设备数量的交叉约束','',
'NVIDIA管理层FY2028约70%的收入增长指引不能直接当作颗数增长。本模型把其近似对应CY2027，仅作口径敏感性：如果GPU相关收入占比之比为0.85—1.0、数量增加20%，则每颗所归属收入需要提高约20%—42%。其中可以包含代际配置、内存、CPU与网络内容，不能全部解释为GPU涨价。[NV_Q2FY27_CALL]','',
'Q2FY27数据中心收入890.23亿美元可作数量一致性检查：若其中75%—90%归属于设备、每颗所归属收入为3.5万—5万美元，则隐含季度设备等价约134万—229万颗。这是参数包络，不是公开ASP或实际季度出货。财报的Compute & Networking报告分部与数据中心收入边界不同，不能相减得到网络收入。[NV_Q2FY27]','',
'2026-10-26公布的Anthropic 630亿美元SPV融资已有committed financing，计划2027开始交付；支持购买的是XPU和网络设备，Broadcom残值支持对应第一顺位融资金额。它不能全部当作已提款现金、残值担保总额、当年收入，或在5GW计划之外再加一次需求。这也是客户融资来源不只依赖NVIDIA的直接证据。[AVGO_ANTH_FIN_OCT26]','',
'云厂商资本开支包含建筑、供电、CPU、存储、网络、预付款及租赁安排。ASIC设计服务可能不包含客户自行采购的晶圆/HBM。因此本模型没有用总CapEx或设计公司收入除以一个假定价格来制造设备数。','',
'## 5. 敏感性与可以下的判断','',
'| 年份 | 基准总量m | 全需求下降20%m | 仅其他客户池下降20%m | 后一情景ASIC占比 | ASIC单边下降多少即与GPU持平 |',
'|---|---:|---:|---:|---:|---:|']
for r in d['demand_robustness_checks']:
 md.append(f"| {r['year']} | {r['base_total_m']:.2f} | {r['all_demand_down20pct_total_m']:.2f} | {r['only_unnamed_pool_down20pct_total_m']:.2f} | {r['only_unnamed_pool_down20pct_asic_share']:.1%} | {r['ASIC_only_uniform_drop_that_equalizes_GPU_fraction']:.1%} |")
md+=['','2028年对未逐项识别的客户池统一下调20%，总量从3,011万降至约2,536万颗；对全需求统一下调20%，则为约2,409万颗。供给模块应分别用这些分组数量和BOM重算HBM、面积、功率，不应只对合计内存需求套同一折扣。','',
'“ASIC在2027年超过GPU”只有约16.8%的单边ASIC需求缓冲：若GPU保持基准、ASIC整体下降20%，结论会翻转。2028年该缓冲约32.2%。这支持ASIC份额抬升的条件主张，不能证明2027年份额拐点必然出现，更不能仅据此推导NVIDIA收入或股价下跌。','',
'**领导层事件的当前已证实数量调整为零。** 已审阅证据没有给出可归因于该事件的新增取消颗数；这不是断言未来没有影响。只对已识别项目中被激活、无法替换的融资或交付约束调整时间表。以5万—10万美元设备投入/颗作假设，10亿美元真实未补缺口相当于1万—2万颗设备；该算式没有把任何预期客户预付款全部视为损失。','',
'## 6. 与供给模型衔接的边界','',
'按SKU/内存代际分配可用HBM，再考虑先进封装、电力、库存和供应商到整机的生产时滞；年度HBM出货不等于同年加速器安装。数量不完整的中国/企业范围应列残差，但不能直接加上另一份中国2.12m估计，因为它可能已在全球核心范围中。[DT_CHINA_APR26]','',
'其他ASIC可能包含非三大HBM供应商供货或非HBM设备。对该组设置80%/90%/100%的Top3 HBM兼容范围，仅是口径敏感性，不能写成已知份额；未占用Top3供给的部分也必须另找其物理供给约束，不能自动视为无限可交付。主表HBM使用供应链标称GB/EB，物理SI字节与可用容量另列。','',
'当前结果回答了“在明确条件下需要多少高端云设备”，仍不单独回答“全球供需是否出清”“哪家公司估值有超额回报”。供应实现量与预算变化完成后，才能形成同口径的行业结论。','',
'## 7. 冻结后的外部校验','',
'ToAlpha原始2026-10-16报告的2027/28 TPU估计为8.5m/10.5m；本模型低约25.5%/15.6%。这是独立研究观点的校验，未用它来回填增长率。其设计服务收入讨论也提醒，COT模式下收入/颗的差异不等于整个ASIC价格变化。[TOALPHA_OCT16]','',
'TrendForce的服务器数量只能用于定义检查：把7月基期与10月增长率串接，2026/27核心设备数对应约5.6/6.1颗/“服务器”。由于预测版本及样本口径可能不同，这个比率不能证明8卡服务器换算成立，也不构成需求数量的独立测量。[TF_JUL03; TF_OCT14]','',
'## 8. 数据、验证与来源','',
'机器可读数据：`tmp/v4_accelerator_demand.json`；复算脚本：`tmp/build_v4_accelerator_demand.py`。已检查分组加总、项目分期守恒、剩余客户池非负、同一项目不重复加入总量，以及事件没有均匀折减全部需求。技术验算通过不等于投资命题已验证。','',
'| ID | 原发布日期/观察状态 | 原始来源与使用 |','|---|---|---|']
for s in d['sources']:
 date=s.get('date') or '截至2026-11-17读取'
 md.append(f"| {s['id']} | {date}；{s['type']} | [{s['title']}]({s['url']}) |")
(P/'v4_accelerator_demand.md').write_text('\n'.join(md)+'\n')
print(json.dumps({'version':d['version'],'buyer_bridge_2027_2028':{k:v[1:3] for k,v in bridges.items()},'validation':d['validation']},ensure_ascii=False,indent=2))
