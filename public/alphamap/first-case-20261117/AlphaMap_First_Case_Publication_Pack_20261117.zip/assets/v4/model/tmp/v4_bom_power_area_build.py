#!/usr/bin/env python3
"""Build the independently sourced BOM/area/power input module (as of 2026-11-17).
Run from any directory. Only writes sibling v4_bom_power_area.json and .md.
Engineering scenarios are deliberately separate from disclosed observations.
"""
from pathlib import Path
import json, hashlib

HERE = Path(__file__).resolve().parent
ASOF = '2026-11-17'
S = {}
def source(k, title, url, date, refs, role='manufacturer_primary', note=''):
    S[k] = dict(title=title, url=url, published_or_available_date=date, retrieved_as_of=ASOF,
                retrieval_refs=refs, evidence_role=role, note=note)

source('NV_HOPPER','NVIDIA Hopper architecture in depth','https://developer.nvidia.com/blog/nvidia-hopper-architecture-in-depth/','2022-03-22',['turn178view0','turn192view4'])
source('NV_HGX','NVIDIA HGX H100/H200/B200 reference architecture','https://docs.nvidia.com/enterprise-reference-architectures/hgx-ai-factory-h100-h200-b200/latest/components.html',None,['turn162search1'],note='Live official documentation; archived revision timestamp not recovered.')
source('NV_BW','NVIDIA Blackwell architecture','https://www.nvidia.com/en-us/data-center/technologies/blackwell-architecture/',None,['turn162search0'])
source('NV_BU','Inside NVIDIA Blackwell Ultra','https://developer.nvidia.com/blog/inside-nvidia-blackwell-ultra-the-chip-powering-the-ai-factory-era/','2025-08-22',['turn178view1'])
source('NV_BU_PDF','Blackwell Ultra datasheet, footer Oct25','https://dam-cdn.nvd.orangelogic.com/AssetLink/1k0p832eq8r5ca0u5383ie5o4tp3bst1.pdf','2025-10',['turn192view2','turn193view5'],note='Specification table PDF page 5; HGX B300 270GB/1100W versus GB300 NVL72 279GB/1400W. Architecture maxima differ.')
source('NV_DGX_B300','NVIDIA DGX B300 system specification','https://www.nvidia.com/en-us/data-center/dgx-b300/',None,['turn201view0'])
source('NV_RUBIN','Inside NVIDIA Rubin GPU architecture','https://developer.nvidia.com/blog/inside-nvidia-rubin-gpu-architecture-powering-the-era-of-agentic-ai/','2026-07-21',['turn212view2'])
source('NV_POD','NVIDIA Vera Rubin POD','https://developer.nvidia.com/blog/nvidia-vera-rubin-pod-seven-chips-five-rack-scale-systems-one-ai-supercomputer','2026-03-16',['turn191view2','turn192view3'],note='Current page includes roadmap updates; use as of cutoff, not an archived March snapshot.')
source('TI_B200','TechInsights original IEDM attendance report','https://library.techinsights.com/sectioned-blog-viewer/9c492ad4-4033-4471-85f0-ff95e970a388?activeMenu=Home','2025-02-24',['turn215search0'],'original_research_observer',note='Author reports NVIDIA presentation stated 790.5 mm2 per compute die. Search retrieval exposed full report; direct page required JS. Its contemporaneous CoWoS inference is not used.')
source('ASML','ASML NXE:3600D maximum exposure field','https://www.asml.com/en/products/euv-lithography-systems/twinscan-nxe-3600d',None,['turn199view2'],'equipment_manufacturer_primary')
source('AMD_CDNA4','AMD CDNA4 architecture whitepaper','https://www.amd.com/content/dam/amd/en/documents/instinct-tech-docs/white-papers/amd-cdna-4-architecture-whitepaper.pdf','2025',['turn170view1'])
source('AMD_350','AMD MI350X specification','https://www.amd.com/en/products/accelerators/instinct/mi350/mi350x.html','2025-06-12',['turn181search2'])
source('AMD_355','AMD MI355X specification','https://www.amd.com/en/products/accelerators/instinct/mi350/mi355x.html','2025-06-12',['turn162search2'])
source('AMD_450','AMD MI450X specification','https://www.amd.com/en/products/accelerators/instinct/mi400/mi450x.html','2026-11-12',['turn193view1','turn197view4'])
source('AMD_455','AMD MI455X specification','https://www.amd.com/en/products/accelerators/instinct/mi400/mi455x.html','2026-07-23',['turn193view0','turn198search1'])
source('AMD_CDNA5','AMD CDNA5 topology','https://www.amd.com/en/technologies/cdna.html',None,['turn211view2'])
source('AMD_400_NEWS','AMD MI400 update','https://newsroom.amd.com/news/amd-advances-instinct-mi400-series-ai-scientific-computing/','2026-11-12',['turn198search4'])
source('GOOG_7','Google TPU7x physical memory and logical-device documentation','https://docs.cloud.google.com/tpu/docs/tpu7x',None,['turn173view1','turn175view2'])
source('GOOG_8','Google TPU8t and TPU8i architecture','https://cloud.google.com/blog/products/compute/tpu-8t-and-tpu-8i-technical-deep-dive','2026-04-22',['turn216view0'])
source('GOOG_MAX','Google TPU8tx and TPU8i Max','https://cloud.google.com/blog/topics/ai-infrastructure/tpu-8tx-and-tpu-8i-max','2026-11-09',['turn210view0','turn212view0'])
source('AWS_T2','AWS Trainium2 hardware architecture','https://awsdocs-neuron.readthedocs-hosted.com/en/latest/about-neuron/arch/neuron-hardware/trn2-arch.html',None,['turn173view2'])
source('AWS_T3','AWS Trainium3 hardware architecture','https://awsdocs-neuron.readthedocs-hosted.com/en/latest/about-neuron/arch/neuron-hardware/trainium3.html',None,['turn211view3'])
source('AWS_T3_GA','AWS Trainium3 launch','https://press.aboutamazon.com/2025/12/trainium3-ultraservers-now-available-enabling-customers-to-train-and-deploy-ai-models-faster-at-lower-cost','2025-12-02',['turn178search2'])
source('AWS_T4','Amazon Q4 2025 results: Trainium4 roadmap','https://ir.aboutamazon.com/news-release/news-release-details/2026/Amazon-com-Announces-Fourth-Quarter-Results/default.aspx','2026',['turn184search6'])
source('META_300','MTIA300 ISCA2026 paper, Table I','https://aisystemcodesign.github.io/papers/MTIA300_ISCA2026.pdf','2026',['turn212view1','turn213view3'],'manufacturer_original_research',note='Author paper linked by Meta Engineering 2026-08-24. Dimensions in Table I, PDF page 4.')
source('META_FUTURE','Meta MTIA300/400/450/500 roadmap','https://ai.meta.com/blog/meta-mtia-scale-ai-chips-for-billions/','2026-03-11',['turn191view1'])
source('MAIA_200','Microsoft Maia200 launch','https://blogs.microsoft.com/blog/2026/01/26/maia-200-the-ai-accelerator-built-for-inference/','2026-01-26',['turn189search1'])
source('GAUDI_3','Intel Gaudi3 whitepaper','https://cdrdv2-public.intel.com/817486/gaudi-3-ai-accelerator-white-paper.pdf','2024',['turn190search7'])
source('HUAWEI','Huawei Ascend roadmap keynote','https://www.huawei.com/en/news/2025/9/hc-xu-keynote-speech','2025-09',['turn189search5'])
source('TSMC_PACK','TSMC North America Technology Symposium packaging roadmap','https://pr.tsmc.com/english/news/3302','2026',['turn199view3','turn200view3'])
source('IEA_2026','IEA Key Questions on Energy and AI, Annex A.1','https://www.iea.org/files/3179f7f8-01f6-4dd6-bffa-c9f7b73f1dc9/KeyQuestionsonEnergyandAI.pdf','2026-04',['turn210view3','turn211view1'],'original_research_institution',note='PDF page 108. 2025 history can initialize all-DC stock; 2030 forecast is an external comparison only.')

rows=[]
def sku(id, vendor, name, year, status, mem, memunit, physical, hbm, stacks,
        counts, area_obs, area_range, area_mid, power_obs, power_range, power_mid,
        power_boundary, sources, note='', devices=1, usable=None, area_formula=None,
        model_mem=None):
    rows.append(dict(id=id,vendor=vendor,name=name,first_relevant_year=year,
        availability_status=status,annual_shipments_not_implied_by_availability=True,
        count_unit='one vendor-defined accelerator device',devices_per_package=devices,
        dies_per_device=counts,
        memory=dict(vendor_reported_capacity=mem,vendor_reported_unit=memunit,
            physical_capacity_explicit=physical,usable_capacity=usable,hbm_generation=hbm,
            stacks_per_device=stacks,model_nominal_GB=(mem if model_mem is None else model_mem),
            model_unit_note='Nominal supply-chain capacity label; explicit GiB retained separately. Not a claim of decimal physical bytes.'),
        logic_area=dict(observed_mm2=area_obs,engineering_mm2_low_mid_high=[area_range[0],area_mid,area_range[1]],
            component_formula=area_formula,scope='sum of compute, I/O and active fabric/base dies; excludes all HBM dies, interposer, bridges, substrate and external CPU/NIC',
            range_status='engineering scenario, not a confidence interval or manufacturer disclosure' if area_obs is None else 'observed anchor; scenario range also shown'),
        power=dict(observed_W=power_obs,observed_boundary=power_boundary,
            engineering_accelerator_W_low_mid_high=[power_range[0],power_mid,power_range[1]],
            engineering_boundary='accelerator/module rated-power proxy; uncertain SoC-to-module corrections explicitly flagged',
            is_average_operating_power=False),sources=sources,notes=note))

sku('h100_sxm','NVIDIA','H100 SXM',2022,'existing',80,'GB',None,'HBM3',5,{'compute':1,'io':0,'active_base':0},814,(814,814),814,700,(700,700),700,'GPU maximum TDP',['NV_HOPPER'],'The full GH100 architecture has six HBM sites, but shipping H100 SXM uses five stacks. Do not import the sixth site into shipping BOM.')
sku('h200_sxm','NVIDIA','H200 SXM',2024,'existing',141,'GB',None,'HBM3E',None,{'compute':1,'io':0,'active_base':0},None,(814,814),814,700,(700,700),700,'GPU maximum TDP',['NV_HGX','NV_HOPPER'],'814 mm2 is a Hopper die-family carryover assumption; 141GB is product-reported capacity, not proof of physical DRAM bits.',model_mem=144)
sku('b200_hgx','NVIDIA','B200 HGX',2024,'existing',180,'GB',None,'HBM3E',8,{'compute':2,'io':0,'active_base':0},1581,(1581,1716),1581,1000,(1000,1000),1000,'GPU maximum configurable TDP',['NV_HGX','NV_BW','TI_B200'],'Area is 2 x 790.5 mm2 from an original conference-observer report, not a downloaded NVIDIA die drawing. Architecture capacity is 192GB, configured usable/reported capacity 180GB.',usable=180,model_mem=192)
sku('gb200_gpu','NVIDIA','GB200 GPU portion',2024,'existing',192,'GB',None,'HBM3E',8,{'compute':2,'io':0,'active_base':0},1581,(1581,1716),1581,1200,(1200,1200),1200,'GPU architecture maximum TDP',['NV_BU','NV_BW','TI_B200'],'One GB200 Superchip contains two GPUs and a Grace CPU; this row is one GPU only. CPU area/power is outside accelerator BOM.')
sku('b300_hgx','NVIDIA','B300 HGX',2025,'existing',270,'GB',None,'HBM3E',8,{'compute':2,'io':0,'active_base':0},None,(1544.4,1716),1650,1100,(1100,1100),1100,'GPU maximum configurable TDP',['NV_BU','NV_BU_PDF'],'Same 208B/4NP/two-reticle class does not prove identical exact die area. 288GB architecture maximum differs from 270GB HGX configuration; reference-architecture live page still gives 288GB, so configuration/version must be tracked.',usable=270,model_mem=288)
sku('gb300_gpu','NVIDIA','GB300 NVL72 GPU portion',2025,'existing',279,'GB',None,'HBM3E',8,{'compute':2,'io':0,'active_base':0},None,(1544.4,1716),1650,1400,(1400,1400),1400,'GPU maximum configurable TDP',['NV_BU','NV_BU_PDF'],'One NVL72 has 72 GPUs and 36 Grace CPUs. 37TB system memory includes CPU LPDDR and must not be counted as HBM.',usable=279,model_mem=288)
sku('rubin_gpu','NVIDIA','Rubin GPU',2026,'announced 2026 platform; shipment mix belongs to demand module',288,'GB',None,'HBM4',None,{'compute':2,'io':0,'active_base':0},None,(1544.4,1716),1650,None,(1400,2200),1800,'not publicly verified',['NV_RUBIN','ASML'],'Two reticle-limited compute dies are one GPU. 288GB and 12-Hi disclosed; actual mm2/TDP are not. Power interval is analyst thermal/module scenario. No unpublished separate active-base die is assumed; add it if documented.')
sku('rubin_ultra_scenario','NVIDIA','Rubin Ultra architecture branches',2027,'roadmap; configuration unresolved',None,None,None,'HBM4/HBM4e roadmap',None,{'compute_scenarios':[2,4],'io':None,'active_base':None},None,(1544.4,3432),3300,None,(1800,3600),2800,'not disclosed',['NV_POD','ASML'],'Base is explicitly a FOUR-large-die scenario, not a verified Ultra specification. HBM 384 nominalGB base = 16 stacks x 8-Hi x 24Gb/8; test 8/16 stacks and 8/12-Hi separately. Product numbering/NVL count is not die count.',model_mem=384)
sku('nvidia_future_family','NVIDIA','Post-2027 GPU family (unnamed)',2028,'analyst family placeholder, not a product announcement',None,None,None,'HBM4e/later scenario',None,{'compute_scenarios':[2,4],'io':None,'active_base':None},None,(1600,4000),3300,None,(2000,4500),3200,'not disclosed',['ASML','TSMC_PACK'],'Range permits additional active logic. Base memory512 nominalGB = 16 x 8-Hi x 32Gb/8, a density/stack assumption. No fixed 2028-2030 SKU is claimed.',model_mem=512)

for ident,name,pwr,ss in [('mi350x','MI350X',1000,'AMD_350'),('mi355x','MI355X',1400,'AMD_355')]:
    sku(ident,'AMD',name,2025,'launched 2025-06-12',288,'GB',None,'HBM3E',8,{'compute':8,'io':2,'active_base':0},None,(1900,2560),2180,pwr,(pwr,pwr),pwr,'Typical Board Power (TBP)',['AMD_CDNA4',ss],
        'Exact component areas not recovered from primary documentation. Working geometry: XCD 100/110/120mm2; large IOD 550/650/800mm2. Eight XCDs stacked over two IODs; sum both silicon layers.',area_formula='8*a_XCD + 2*a_IOD')
for ident,name,mem,stacks,src,date in [('mi450x','MI450X',288,8,'AMD_450','2026-11-12'),('mi455x','MI455X',432,12,'AMD_455','2026-07-23')]:
    sku(ident,'AMD',name,2026,'product launch '+date,mem,'GB',None,'HBM4',stacks,{'compute':8,'io':2,'active_base':2},None,(2180,3560),2870,None,(1400,2200),1800,'TBP not publicly verified',[src,'AMD_CDNA5','AMD_400_NEWS'],
        'MI455X topology confirmed; MI450X same-core-compute statement supports topology carryover, not measured equality. Working XCD 110/140/170mm2, fabric/cache 550/700/850mm2, IOD 100/175/250mm2. These are geometric sensitivities, not disclosed areas.',area_formula='8*a_XCD + 2*a_IO + 2*a_fabric_cache')
sku('amd_future_family','AMD','Post-MI400 GPU family (unnamed)',2027,'analyst family placeholder',None,None,None,'HBM4e/later scenario',None,{'compute':None,'io':None,'active_base':None},None,(2200,4500),3200,None,(1800,3500),2400,'not disclosed',['AMD_CDNA5'],'Future family deliberately not fixed to announced product names; model nominal capacity512 is an engineering placeholder.',model_mem=512)

sku('tpu_v5p','Google','TPU v5p',2024,'existing',96,'GiB',96,'HBM',None,{'compute':None,'io':None,'active_base':None},None,(500,858),700,None,(350,800),550,'not disclosed',['GOOG_7'],'Physical96GiB versus user-usable95GiB. Area and module power are engineering sensitivities, not Google specifications.',usable=95)
sku('tpu_v6e','Google','TPU v6e',2024,'existing',32,'GiB',32,'HBM',None,{'compute':None,'io':None,'active_base':None},None,(300,550),425,None,(250,600),400,'not disclosed',['GOOG_7'],'Do not use v5p or TPU7x memory for this efficiency SKU.')
sku('tpu7x','Google','TPU7x / Ironwood',2025,'existing by cutoff',192,'GiB',192,'HBM3E',None,{'compute':2,'io':None,'active_base':None},None,(800,1716),1200,None,(600,1200),900,'not disclosed',['GOOG_7'],'One TPU chip has two compute chiplets and two JAX logical devices. Our accelerator count is ONE, not two; each compute chiplet exposes96GiB.')
for ident,name,mem in [('tpu8t','TPU8t',216),('tpu8i','TPU8i',288),('tpu8tx','TPU8tx',216)]:
    sku(ident,'Google',name,2026,'announced April 2026; 8tx November 2026',mem,'GB',None,'HBM, generation not established here',None,{'compute':None,'io':None,'active_base':None},None,(1000,2200),1550,None,(800,1600),1200,'not disclosed',['GOOG_8','GOOG_MAX'],
        '8tx reuses8t silicon.8i has Tensor-Core dies plus CAE chiplet; exact die count/dimensions not fully established here. Range reserves auxiliary active logic and is not a measured teardown. Do not infer silicon area from advertised FLOPS.')
sku('tpu8i_max_per_device','Google','TPU8i inside TPU8i Max',2026,'announced 2026-11-09',288,'GB',None,'HBM',None,{'compute':None,'io':None,'active_base':None},None,(1000,2200),1550,None,(800,1600),1200,'not disclosed',['GOOG_MAX','GOOG_8'],'ONE underlying TPU8i device per row. TWO devices per Max package, so package area and HBM are twice this row; do not double device count again.',devices=2)
sku('google_future_family','Google','Future TPU family (unnamed)',2028,'analyst family placeholder',None,None,None,'HBM4/later scenario',None,{'compute':None,'io':None,'active_base':None},None,(1000,3000),1900,None,(1000,2400),1600,'not disclosed',['GOOG_8'],'Per underlying TPU device, not Max package. Nominal384GB is an engineering mix/capacity placeholder.',model_mem=384)

sku('trainium2','AWS','Trainium2',2024,'existing',96,'GiB',96,'HBM',None,{'compute':None,'io':None,'active_base':None},None,(600,1200),900,None,(400,800),600,'not disclosed',['AWS_T2'],'16 chips per Trn2 instance, not16 NeuronCores. Die topology, mm2 and chip power unresolved; stated ranges are explicit engineering scenarios.')
sku('trainium3','AWS','Trainium3',2025,'GA 2025-12-02',144,'GiB',144,'HBM3E',None,{'compute':None,'io':None,'active_base':None},None,(700,1500),1100,None,(500,1100),800,'not disclosed',['AWS_T3','AWS_T3_GA'],'Eight NeuronCores are not eight chips. Up to144 chips per UltraServer is a system configuration, not each chip memory.')
sku('trainium_future_family','AWS','Trainium4 and successor family',2027,'Trainium4 planned 2027; successors scenario',None,None,None,'HBM4/later scenario',None,{'compute':None,'io':None,'active_base':None},None,(1000,2400),1600,None,(800,2000),1300,'not disclosed',['AWS_T4'],'Trainium4 roadmap says2x Trainium3 capacity; 288 nominal/GiB-label base is derived from144, not verified physical bit BOM. Later years may differ.',model_mem=288)
sku('mtia200','Meta','MTIA200 / MTIA-2i',2024,'existing',0,'GB',0,'none: LPDDR5',0,{'compute':1,'io':0,'active_base':0},419.84,(419.84,419.84),419.84,85,(85,85),85,'paper TDP',['META_300'],'Separate non-HBM branch. LPDDR capacity64-128GB is not counted as HBM; typical paper power65W.')
sku('mtia300','Meta','MTIA300',2026,'in production',216,'GB',None,'HBM3E',6,{'compute':1,'io':2,'active_base':0},1280,(1280,1280),1280,912,(912,912),912,'paper accelerator TDP',['META_300'],'Compute25.6x31.4=803.84mm2; two NICs25.6x9.3=476.16mm2; total1280. Paper typical power667W is workload-specific, not a fleet utilization factor.',area_formula='25.6*31.4 + 2*25.6*9.3')
sku('mtia400_450_family','Meta','MTIA400/450',2026,'400 deployment path in2026;450 planned early2027',None,None,None,'HBM',None,{'compute':2,'io':None,'active_base':None},None,(1800,2800),2300,None,(1000,1800),1400,'not verified',['META_FUTURE'],'Published topology supports two-compute family; absolute memory and area not verified here. Nominal384GB is scenario input only.',model_mem=384)
sku('mtia500_future_family','Meta','MTIA500 and successor family',2027,'500 planned2027; successors scenario',None,None,None,'HBM',None,{'compute':4,'io':2,'active_base_or_soc':1},None,(2600,4500),3600,None,(1600,3000),2200,'not verified',['META_FUTURE'],'Four compute+two networking+one SoC die in500 roadmap. Nominal512GB is scenario input, not an official capacity.',model_mem=512)
sku('maia200','Microsoft','Maia200',2026,'deployed as of launch',216,'GB',None,'HBM3E',None,{'compute':None,'io':None,'active_base':None},None,(700,1000),850,750,(800,1000),900,'SoC TDP',['MAIA_200'],'750W is SoC TDP; model adds50-250W to bound HBM/module losses. Single-die upper858 applies only if monolithic; range1000 reserves unknown auxiliary logic, not exposure-field violation.')
sku('gaudi3','Intel','Gaudi3 OAM',2024,'existing',128,'GB',None,'HBM2E',8,{'compute':None,'io':None,'active_base':None},None,(1000,1716),1400,900,(900,900),900,'OAM power rating',['GAUDI_3'],'Keep HBM2E demand separate from HBM3E/HBM4 availability.')
sku('ascend950dt','Huawei','Ascend950DT',2026,'roadmap Q4 2026',144,'GB',None,'HiZQ2.0 proprietary HBM',None,{'compute':None,'io':None,'active_base':None},None,(700,1800),1200,None,(700,1400),1000,'not verified',['HUAWEI'],'950PR usesHiBL1.0 and is a separate variant. Do not allocate proprietary memory demand automatically to SK hynix/Samsung/Micron supply.')
sku('other_asic_future','Other','Unspecified HBM ASIC family',2027,'analyst residual family',None,None,None,'supplier/gen unresolved',None,{'compute':None,'io':None,'active_base':None},None,(700,2600),1500,None,(700,2000),1200,'not disclosed',['META_FUTURE','MAIA_200','HUAWEI'],'Residual is not new additive unit demand; maps part of demand module other_asic. Nominal256GB is a model assumption.',model_mem=256)

source('TOALPHA','ToAlpha original AI ASIC research, Exhibit1','https://toalpha.tw/reports/toalpha-ai-asic-unbundling-20261016-en.pdf','2026-10-16',['turn228view0'],'original_research_institution',note='Use selected dated BOM evidence and2026Ironwood mix anchor only; no2027+unit forecasts imported.')
source('TF_ULTRA_AUG','TrendForce Ultra HBM configuration evaluation','https://www.trendforce.com/presscenter/news/20260804-13166.html','2026-08-04',['turn232view0'],'original_research_institution')
source('TF_ULTRA_SEP','TrendForce HBM layer-count and base-die constraints','https://www.trendforce.com/presscenter/news/20260929-13255.html','2026-09-29',['turn232view1'],'original_research_institution')
by={r['id']:r for r in rows}
# Add independently reported physical topology, preserving manufacturer-vs-research distinctions.
for ident,stacks in [('tpu7x',8),('tpu8i',8),('tpu8i_max_per_device',8),('tpu8t',6),('tpu8tx',6),('trainium3',4),('maia200',6)]:
    by[ident]['memory']['stacks_per_device']=stacks
    by[ident]['memory']['hbm_generation']='HBM3E'
    by[ident]['sources'].append('TOALPHA')
    by[ident]['memory']['stack_evidence']='original researcher report; capacity separately checked with manufacturer'
for ident in ['tpu8i','tpu8i_max_per_device']:
    by[ident]['dies_per_device']={'compute':2,'io_or_CAE':1,'active_base':0}
    by[ident]['topology_evidence']='TOALPHA original research, consistent with Google CAE chiplet description'
    by[ident]['power']['original_research_estimate_W']=1300
    by[ident]['power']['engineering_accelerator_W_low_mid_high'][1]=1300
by['maia200']['dies_per_device']={'compute':1,'io':0,'active_base':0}
by['maia200']['logic_area']['engineering_mm2_low_mid_high']=[700,800,858]
by['maia200']['notes']='750W is SoC TDP; module proxy adds50-250W. Monolithic topology reported by ToAlpha; exact area undisclosed.'
by['rubin_ultra_scenario']['sources'] += ['TF_ULTRA_AUG','TF_ULTRA_SEP']
by['rubin_ultra_scenario']['memory']['model_nominal_GB']=480
by['rubin_ultra_scenario']['memory']['configuration_base_scenario']={'stacks_per_device':16,'die_density_Gb':24,'unreduced_layers':12,'reduced_layers':8,'reduced_layer_adoption':.5,'unreduced_nominal_GB':576,'reduced_nominal_GB':384,'mixed_nominal_GB':480,'status':'architecture and adoption assumptions, not final Ultra specification'}
by['rubin_ultra_scenario']['notes']='Base is a FOUR-large-compute-die,16-HBM-stack architecture scenario, not a verified Ultra specification. Half12-Hi576GB and half8-Hi384GB gives480GB fleet mean. Alternate8-stack branch halves these capacities. Only this eligible family enters layer-cut counterfactual; regularRubin does not.'

# All these shares are analyst scenarios. Only NV top-level groups use the demand module's stated mix.
M={
2026:{'nvidia_gpu':{'h200_sxm':.07,'b200_hgx':.213,'b300_hgx':.1988,'gb300_gpu':.2982,'rubin_gpu':.22},
      'other_gpu':{'mi350x':.2,'mi355x':.5,'mi450x':.1,'mi455x':.2},
      'google_tpu':{'tpu_v5p':.02,'tpu_v6e':.03,'tpu7x':.73,'tpu8t':.10,'tpu8i':.12},
      'other_asic':{'trainium2':.10,'trainium3':.50,'mtia300':.12,'mtia400_450_family':.08,'maia200':.10,'ascend950dt':.05,'gaudi3':.05}},
2027:{'nvidia_gpu':{'h200_sxm':.02,'b300_hgx':.072,'gb300_gpu':.108,'rubin_gpu':.60,'rubin_ultra_scenario':.20},
      'other_gpu':{'mi355x':.15,'mi450x':.30,'mi455x':.45,'amd_future_family':.10},
      'google_tpu':{'tpu_v6e':.05,'tpu7x':.15,'tpu8t':.35,'tpu8i':.45},
      'other_asic':{'trainium3':.55,'trainium_future_family':.05,'mtia300':.05,'mtia400_450_family':.10,'mtia500_future_family':.10,'maia200':.10,'other_asic_future':.05}},
2028:{'nvidia_gpu':{'b300_hgx':.012,'gb300_gpu':.018,'rubin_gpu':.188,'rubin_ultra_scenario':.282,'nvidia_future_family':.50},
      'other_gpu':{'mi450x':.15,'mi455x':.25,'amd_future_family':.60},
      'google_tpu':{'tpu8t':.15,'tpu8i':.25,'google_future_family':.60},
      'other_asic':{'trainium3':.10,'trainium_future_family':.50,'mtia400_450_family':.05,'mtia500_future_family':.20,'maia200':.05,'other_asic_future':.10}},
2029:{'nvidia_gpu':{'rubin_gpu':.05,'rubin_ultra_scenario':.10,'nvidia_future_family':.85},
      'other_gpu':{'mi450x':.05,'mi455x':.10,'amd_future_family':.85},
      'google_tpu':{'tpu8i':.15,'google_future_family':.85},
      'other_asic':{'trainium_future_family':.60,'mtia500_future_family':.25,'other_asic_future':.15}},
2030:{'nvidia_gpu':{'rubin_gpu':.02,'rubin_ultra_scenario':.03,'nvidia_future_family':.95},
      'other_gpu':{'mi455x':.05,'amd_future_family':.95},
      'google_tpu':{'tpu8i':.05,'google_future_family':.95},
      'other_asic':{'trainium_future_family':.60,'mtia500_future_family':.25,'other_asic_future':.15}}}
for year, groups in M.items():
    for group,mix in groups.items():
        assert abs(sum(mix.values())-1)<1e-9,(year,group)
        assert all(x in by for x in mix)
        assert all(by[x]['first_relevant_year']<=year for x in mix)

# Conditional engineering bands: capacity ranges must be reconciled to HBM supply generation/qualification.
MEM_BANDS={
'rubin_ultra_scenario':[192,480,768], 'nvidia_future_family':[256,512,1024],
'amd_future_family':[384,512,768], 'google_future_family':[216,384,768],
'trainium_future_family':[192,288,576], 'mtia400_450_family':[216,384,576],
'mtia500_future_family':[384,512,1024], 'other_asic_future':[128,256,512],
'h200_sxm':[141,144,144]}
for r in rows:
    mem=r['memory']['model_nominal_GB']
    r['memory']['engineering_nominal_GB_low_mid_high']=MEM_BANDS.get(r['id'],[mem,mem,mem])
    if r['memory']['vendor_reported_unit']=='GiB':
        r['memory']['reported_capacity_SI_bytes']=r['memory']['vendor_reported_capacity']*2**30
    else:
        r['memory']['reported_capacity_SI_bytes']=None

# Aggregate engineering profiles by demand-vendor group and year.
profiles=[]
for year,groups in M.items():
    for group,mix in groups.items():
        def w(path):
            return [sum(share*path(by[id])[i] for id,share in mix.items()) for i in range(3)]
        profiles.append(dict(year=year,demand_group=group,
            area_mm2_low_mid_high=w(lambda x:x['logic_area']['engineering_mm2_low_mid_high']),
            accelerator_W_low_mid_high=w(lambda x:x['power']['engineering_accelerator_W_low_mid_high']),
            memory_nominal_GB_low_mid_high=w(lambda x:x['memory']['engineering_nominal_GB_low_mid_high']),
            mix_status='analyst transition mix, not observed SKU bookings',
            observed_area_share=sum(v for k,v in mix.items() if by[k]['logic_area']['observed_mm2'] is not None),
            observed_power_share=sum(v for k,v in mix.items() if by[k]['power']['observed_W'] is not None)))

DEMAND_PATH=HERE/'v4_accelerator_demand.json'
integration=[]
demand_meta=None
if DEMAND_PATH.exists():
    raw=DEMAND_PATH.read_bytes();D=json.loads(raw)
    demand_meta=dict(path=str(DEMAND_PATH),sha256=hashlib.sha256(raw).hexdigest(),
                     unit=D['unit'],warning='Demand unconstrained scenarios, not realized supply or installations.')
    for d in D['scenarios_m']['base']:
        pp=[p for p in profiles if p['year']==d['year']]
        entry=dict(year=d['year'],device_shipments_m=d['high_end_cloud_core_total'])
        # 1 million devices * 1 mm2 = 1 m2; million devices * W /1000 = GW.
        entry['good_logic_silicon_m2_low_mid_high']=[sum(d[p['demand_group']]*p['area_mm2_low_mid_high'][i] for p in pp) for i in range(3)]
        entry['accelerator_rated_shipment_GW_low_mid_high']=[sum(d[p['demand_group']]*p['accelerator_W_low_mid_high'][i]/1000 for p in pp) for i in range(3)]
        entry['HBM_nominal_EB_low_mid_high']=[sum(d[p['demand_group']]*p['memory_nominal_GB_low_mid_high'][i]/1000 for p in pp) for i in range(3)]
        entry['logic_area_disclosed_or_original_research_share_of_devices']=sum(d[p['demand_group']]*p['observed_area_share'] for p in pp)/d['high_end_cloud_core_total']
        integration.append(entry)

out=dict(version='v4-independent-bom-power-area-1',as_of=ASOF,semi_analysis_values_used_as_inputs=False,
    completion_status='BOM/power/area input module complete; generation mix and undisclosed areas/power are explicit engineering scenarios; global realized supply-demand verdict belongs to integrated model',
    count_dictionary=dict(main_unit='one vendor-defined accelerator device; demand publisher chip convention',
        not_a_universal_physical_package_count=True,
        nvidia='Two Blackwell/Rubin compute dies form one GPU device.',
        google_tpu7x='Two compute chiplets and two JAX logical devices form one TPU chip.',
        google_tpu8i_max='Two underlying TPU8i devices per package. packages=devices/2; per-device memory/area are not doubled.',
        aws='NeuronCore is an internal functional core, not a chip.',
        caveat='Public demand abstract lacks a complete count dictionary; retain conversion factors and alternate package-count stress.'),
    unit_contract=dict(area='mm2 per device; aggregate good silicon m2 excludes yield losses',
        memory='Nominal GB/EB supply-chain labels for model join; explicit GiB physical-byte ledger retained. Do not convert only demand to SI GB while leaving supplier nominal EB unchanged.',
        power='W rated accelerator/module proxy; annual shipments produce a GW equipment flow, not installed site GW or TWh.',
        exclusions=['HBM DRAM and HBM base logic from logic-area measure','interposer/CoWoS footprint','external host CPUs and NICs from accelerator silicon area']),
    sources=S,sku_panel=rows,
    engineering_basis=dict(reticle_mm=[26,33],reticle_area_mm2=858,source='ASML',
        reticle_limited_working_fraction=[.90,1],reticle_limited_one_die_mm2=[772.2,858],
        lower_endpoint_is_assumption_not_physical_bound=True,
        calibration={'H100_compute_mm2':814,'MTIA300_compute_mm2':803.84,'B200_reported_compute_mm2':790.5},
        nvidia_two_die_mm2=[1544.4,1716],nvidia_four_die_mm2=[3088.8,3432],
        active_base_layers='Sum active layers even when stacked. A 2D package footprint is not total manufactured logic silicon.',
        amd_ranges='Component-level analyst geometry, below one reticle per die; manufacturer topology constrains the sum, not exact component area.',
        asic_ranges='Wide analyst design scenarios anchored to observed large accelerator geometries; not vendor measurements or statistical bounds.',
        no_fake_density_inference='Transistor count, FLOPS, process node and package footprint do not uniquely determine die area.'),
    analyst_sku_mix_by_year=M,aggregated_profiles=profiles,
    mix_provenance='NVIDIA top-level 2026/2027+ split follows demand module stated evidence/assumptions. Within-family splits and all other vendor mixes are analyst assumptions; no source is claimed to publish them.',
    demand_input=demand_meta,base_demand_conditional_integration=integration,
    system_examples=dict(dgx_b300=dict(gpus=8,system_W=14000,gpu_max_configurable_W=1100,
        system_W_per_GPU=1750,system_to_GPU_rating_ratio=14000/(8*1100),sources=['NV_DGX_B300','NV_BU_PDF'],
        caveat='This system-specific ratio includes system overhead; it is not a universal multiplier. GPU/system maxima need not occur simultaneously.'),
        gb300_nvl72=dict(gpus=72,grace_cpus=36,per_gpu_W=1400,known_GPU_only_rated_kW=100.8,source='NV_BU_PDF',
        rack_total_kW=None,caveat='100.8kW omits CPUs/network/storage/conversion losses; not rack input power.'),
        ultra_nvl576=dict(racks=8,devices_per_rack=72,devices_total=576,source='NV_POD',
        caveat='Current official page describes eight NVL72 racks. Do not assume576 packaged GPUs in one rack.')),
    bridge_formulas=dict(device_to_packages='packages_s,y = devices_s,y / devices_per_package_s',
        good_logic_area='A_y_mm2 = sum_s N_s,y * sum_j(n_s,j * a_s,j_mm2); m2=A_mm2/1e6',
        wafer_starts='For each node/die: W=sum_s required_KGD_s,j/(gross_die_per_wafer_j*fabrication_yield_j). Include package-loss replacement once, not twice. Good silicon area alone is not wafer capacity.',
        hbm_bits='bits_y=sum_s N_s,y*stacks_s*DRAM_layers_s*bits_per_DRAM_die_s. HBM base dies and stack yield need their own ledger.',
        rated_shipments='P_ship_GW=sum_s N_s,y*P_rated_W_s/1e9; N in millions gives sum(N_m*P_W/1000).',
        deployments='commissioned_y = same_year_fraction*shipments_y + lagged_inventory_deliveries_y, constrained by usable IT power and cooling; uncommissioned units remain inventory/backlog.',
        stock='installed_end_y = installed_start_y + commissioned_y - retirements_y; retain cohorts and replacement versus expansion.',
        energy='E_y_TWh=sum_cohorts installed_time_weighted_units*average_IT_W_per_device*hours_y*PUE_energy/1e12 + other_IT_energy.',
        average_power='P_average=P_idle+(P_loaded-P_idle)*duty; GPU utilization percent is not automatically this power duty.',
        energy_GW='E_TWh = average_site_GW * hours_y/1000; ordinary year8.76, leap2028 year8.784.',
        model_boundaries='When using system/rack rated W per GPU, do not add the same CPU/NIC/storage overhead again. Facility design margin and energy PUE are separate parameters.'),
    recommended_stock_flow_scenarios=dict(status='explicit assumptions to run after HBM/packaging limits; not vendor disclosures',
        commissioning_same_year_fraction=[.50,.70,.90],remaining_commissioning_lag_years=[1,1,1],
        new_accelerator_IT_overhead_multiplier=[1.25,1.45,1.65],
        new_facility_design_to_IT_capacity_ratio=[1.10,1.20,1.35],
        energy_PUE_new_AI=[1.10,1.15,1.30],
        realized_average_IT_draw_fraction_of_rating=[.50,.65,.75],
        new_accelerator_service_life_years=[4,5,6],
        initial_AI_IT_capacity_GW_engineering=[19,25,31],
        initial_AI_capacity_basis='Approximate2025 AI-focused150TWh divided by PUE1.1-1.3 and load0.5-0.7 gives18.8-31.1GW. This is a stock-allocation sensitivity, not an IEA AI-capacity observation.',
        conventional_start_IT_GW='82 minus assumed initial AI IT GW; do not add an all-DC82GW baseline to a separate full existing AI fleet.',
        existing_AI_retirement_fraction_per_year=[.15,.20,.25],
        conventional_IT_capacity_growth_per_year=[0,.02,.04],
        in_year_install_energy_weight=.5,
        capacity_constraint_action='If unconstrained chip flows overrun independent site capacity, extend commissioning lag and report inventory/cancelled capacity. Do not lower utilization arbitrarily to force agreement with IEA2030.'),
    iea_external_check=dict(source='IEA_2026',table='A.1, PDF108',
        historical_2025=dict(total_installed_GW=114,IT_installed_GW=82,total_TWh=485,IT_TWh=352,energy_PUE=1.38,reported_capacity_factor=.48,average_total_GW=485/8.76),
        external_forecast_2030=dict(total_installed_GW=226,IT_installed_GW=174,total_TWh=945,IT_TWh=732,energy_PUE=1.29,reported_capacity_factor=.48,average_total_GW=945/8.76),
        warning='All datacentres, not AI accelerators alone; use2025 observed base, compare independently generated2030 result. 950TWh is rounded headline; table says945.'),
    decisive_checks=[
        'MI455X->MI450X:432->288GB is a33.33% capacity/stack reduction at equal device count; it is not a33.33% accelerator shipment cut.',
        '12-Hi->8-Hi with fixed stacks and die density reduces memory/device byone third; fixed available DRAM bits support1.5x devices only if base dies/packaging/logic/power also permit.',
        'Units -15% and area/device +50% imply good logic area +27.5%; units -15% and W/device +40% imply shipment-rated power +19%. These are identities, not market forecasts.',
        'A whole-ASIC row cannot be uniformly zero-HBM: MTIA300,Maia200 and newer MTIA use HBM, while MTIA200 does not.',
        'HBM supplier generation and qualification perimeter matters: proprietaryHuawei memory andGaudiHBM2E must not be silently supplied by a genericHBM4 pool.',
        'TSMC5.5/14-reticle CoWoS package size is neither per-device logic area nor wafer-start capacity.'
    ],
    next_executable_work=[
        'Join aggregated_profiles to demand scenarios and HBM supply by year; use generation-qualified HBM allocation, not just total EB.',
        'Run all low/mid/high BOM corners and alternative SKU shares; report sensitivity separately from demand-volume uncertainty.',
        'For power, convert supply-realized shipments to installations with commissioning lag and cohort retirement, then apply measured/spec system boundaries and separate facility/PUE assumptions.',
        'Resolve remaining largest sensitivity with primary die drawings/ISSCC tables and delivered-system electrical specs; do not substitute SemiAnalysis values.',
        'Preserve residual coverage and count-unit uncertainty; the high-end cloud core is not proven to cover every global accelerator.'
    ])

# Material-generation partitions are explicit conditional assumptions when qualification is unknown.
def generation_mix(ident, year):
    fixed={
      'h100_sxm':'HBM3','h200_sxm':'HBM3E','b200_hgx':'HBM3E','gb200_gpu':'HBM3E',
      'b300_hgx':'HBM3E','gb300_gpu':'HBM3E','rubin_gpu':'HBM4',
      'mi350x':'HBM3E','mi355x':'HBM3E','mi450x':'HBM4','mi455x':'HBM4',
      'tpu_v5p':'HBM3_or_earlier_unverified','tpu_v6e':'HBM3_or_earlier_unverified',
      'tpu7x':'HBM3E','tpu8t':'HBM3E','tpu8i':'HBM3E','tpu8tx':'HBM3E','tpu8i_max_per_device':'HBM3E',
      'trainium2':'HBM3_or_earlier_unverified','trainium3':'HBM3E','mtia200':'no_HBM',
      'mtia300':'HBM3E','maia200':'HBM3E','gaudi3':'HBM2E','ascend950dt':'proprietary_unmatched'}
    if ident in fixed:return {fixed[ident]:1.0},'disclosed or original-research generation; vendor qualification share still unresolved'
    if ident=='rubin_ultra_scenario':
        h4={2027:.50,2028:.25,2029:.10,2030:0}.get(year,.5)
        return {'HBM4':h4,'HBM4E':1-h4},'candidate configuration mix assumption; final validation/adoption unresolved'
    if ident=='trainium_future_family':
        if year<=2028:return {'HBM4':1.0},'announced/research roadmap mapped to an analyst family; no supplier allocation claim'
        h4={2029:.50,2030:.25}[year]
        return {'HBM4':h4,'HBM4E_or_later':1-h4},'future generation-share assumption'
    if ident=='mtia400_450_family':return {'HBM3E':.50,'HBM4':.50},'analyst generation split, not verified BOM'
    if ident=='mtia500_future_family':
        return ({'HBM4':1.0} if year<=2028 else {'HBM4':.25,'HBM4E_or_later':.75}),'analyst generation split, not verified BOM'
    if ident=='google_future_family':
        return ({'HBM4':.70,'HBM4E':.30} if year==2028 else {'HBM4E_or_later':1.0}),'future family generation split assumption; named v9/v10 BOM not fixed'
    if ident=='amd_future_family' and year==2027:return {'HBM4':.50,'HBM4E':.50},'future family assumption'
    if ident=='other_asic_future':return {'HBM4':.50,'unmatched_or_later':.50},'unqualified residual; not assumed interchangeable'
    return ({'HBM4E':.75,'HBM4E_or_later':.25} if year==2028 else {'HBM4E_or_later':1.0}),'future family generation split assumption'

out['generation_join_panel']=[]
for year,groups in M.items():
    for group,mix in groups.items():
        for ident,share in mix.items():
            gm,gs=generation_mix(ident,year)
            out['generation_join_panel'].append(dict(year=year,demand_group=group,sku_id=ident,
                share_of_group=share,nominal_GB_per_device=by[ident]['memory']['model_nominal_GB'],
                hbm_generation_share=gm,generation_evidence_status=gs,
                vendor_qualification_allocation=None))
out['generation_matching_contract']={
    'aggregate_only':'TotalEB match is necessary but not sufficient. HBM3E cannot automatically fillHBM4/4E shortages, and proprietary/legacy pools are separate.',
    'unknown_qualification':'If no per-SKU supplier qualification/capacity allocation exists, report an aggregate-match conditional result. Do not label it a feasible delivered-product schedule.',
    'no_capacity_fitting':'BOM and mix were specified independently of HBM supply totals; no memory capacity was reduced to make balances clear.'}
out['same_device_configuration_counterfactual']={
    'definition':'Same devices and same logic area/power proxy. Change memory configuration only on identified eligible families; no blanketGPU/ASIC two-thirds multiplier.',
    'eligibility_sources':['AMD_450','AMD_455','AMD_400_NEWS','TF_ULTRA_AUG','TF_ULTRA_SEP'],
    'ultra_architecture_branches':[
        dict(stacks_per_device=8,DRAM_die_Gb=24,unreduced_layers=12,reduced_layers=8,unreduced_GB=288,reduced_GB=192),
        dict(stacks_per_device=16,DRAM_die_Gb=24,unreduced_layers=12,reduced_layers=8,unreduced_GB=576,reduced_GB=384)],
    'base_ultra_branch':16,'base_ultra_adoption':.5,
    'ultra_reduced_layer_adoption_sensitivity':[0,.5,1],
    'ultra_share_of_nvidia_multiplier_sensitivity':[.5,1,1.5],
    'mi450_adoption_fraction_of_mi450_plus_mi455_sensitivity':[0,.4,.6],
    'excluded':['regularRubin confirmed12-Hi288GB','all otherGPU/ASIC absent SKU-specific adoption evidence','future unnamed families absent specific configuration-change evidence'],
    'power_effect':'Not quantified: lessHBM may lower operating watts but verifiedTBP/rack saving unavailable. Counterfactual holds rating proxy fixed rather than inventing a watt benefit.',
    'area_effect':'No logic-area change assumed for an identicalcompute design; HBMDRAM-area/base-die effects belong in memory supply model.',
    'by_year':[]}
if DEMAND_PATH.exists():
    for d in D['scenarios_m']['base']:
        year=d['year'];mix=M[year]
        ultra_m=d['nvidia_gpu']*mix['nvidia_gpu'].get('rubin_ultra_scenario',0)
        amd_eligible_m=d['other_gpu']*sum(mix['other_gpu'].get(k,0) for k in ['mi450x','mi455x'])
        mi450_m=d['other_gpu']*mix['other_gpu'].get('mi450x',0)
        ultra_saving=ultra_m*192*.5/1000
        amd_saving=mi450_m*144/1000
        base_EB=next(x['HBM_nominal_EB_low_mid_high'][1] for x in integration if x['year']==year)
        c=dict(year=year,total_devices_m=d['high_end_cloud_core_total'],
            ultra_eligible_devices_m=ultra_m,ultra_share_of_nvidia=mix['nvidia_gpu'].get('rubin_ultra_scenario',0),
            mi400_eligible_devices_m=amd_eligible_m,mi450_selected_devices_m=mi450_m,
            mi450_adoption=mi450_m/amd_eligible_m if amd_eligible_m else 0,
            base_HBM_nominal_EB=base_EB,
            unreduced_same_device_HBM_nominal_EB=base_EB+ultra_saving+amd_saving,
            base_memory_saving_EB=ultra_saving+amd_saving,
            ultra_saving_EB=ultra_saving,mi450_saving_EB=amd_saving,
            saving_fraction_of_unreduced=(ultra_saving+amd_saving)/(base_EB+ultra_saving+amd_saving),
            max_saving_EB_at_base_eligible_units_full_adoption=ultra_m*192/1000+amd_eligible_m*144/1000,
            alternative_8_stack_ultra_saving_EB_at50pct_adoption=ultra_m*96*.5/1000,
            logic_area_delta_m2_assumed=0,rated_power_delta_GW_assumed=0)
        out['same_device_configuration_counterfactual']['by_year'].append(c)

out['mix_provenance'] += ' 2026Google Ironwood73% is a rounded scenario near ToAlpha dated2.5m divided by independent DT3.423m; scopes may differ, so test60-80%. 2027Google has no unannounced successor allocation; Trainium4 receives only5%ofotherASIC for its late2027 ramp.'
(HERE/'v4_bom_power_area.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')

def f(x):
    return f'{x:,.0f}' if abs(x-round(x))<1e-6 else f'{x:,.1f}'
def triple(xs): return ' / '.join(f(x) for x in xs)
md=['# 独立芯片 BOM、逻辑硅面积与功率桥接',
    '',f'**信息截点：{ASOF}。** 未使用 SemiAnalysis 数字或旧图绝对值。JSON 是可接入主模型的完整参数表；已披露事实与工程情景分开保存。面积与功率区间用于给出量级，不是假称厂商披露的规格或统计置信区间。',
    '', '## 先统一数量口径', '',
    '主模型按一枚**厂商定义的 accelerator device**计数，同时保留封装转换。NVIDIA Blackwell/Rubin 的两枚计算 die 合成一枚 GPU；TPU7x 的两枚 chiplet、两个 JAX 设备合成一枚 TPU chip；TPU8i Max 一个封装装两枚 TPU8i，因此按芯片数输入时封装数除以二，不能再把每芯片 HBM 翻倍。需求发布者的完整计数字典仍未公开。[Google TPU7x](https://docs.cloud.google.com/tpu/docs/tpu7x)；[Google 11/9](https://cloud.google.com/blog/topics/ai-infrastructure/tpu-8tx-and-tpu-8i-max)。',
    '', '## 可核对的关键规格', '',
    '| 产品/族群 | 逻辑硅面积 mm²/device | HBM 容量口径 | 功率及边界 |',
    '|---|---:|---|---|',
    '| H100 SXM | 814，官方 | 80 GB；实际5个HBM堆栈 | 700 W GPU最大TDP |',
    '| B200 | 原研究记录2×790.5=1,581；双reticle工程约1,544–1,716 | 架构192 GB；HGX配置180 GB | HGX 1,000 W；GB200 GPU族群上限1,200 W |',
    '| B300 | 双reticle工程1,544–1,716，非精确测量 | 架构288 GB；HGX270、GB300279 GB | HGX1,100 W；GB3001,400 W |',
    '| Rubin | 2个reticle计算die；工程1,544–1,716 | 288 GB HBM4，12-Hi | 官方TDP未核得；工程1.4–2.2 kW |',
    '| MI350X/MI355X | 8XCD+2IOD；工程1,900–2,560 | 288 GB HBM3E，8 stacks | 1,000/1,400 W TBP |',
    '| MI450X/MI455X | 8XCD+2IOD+2fabric/cache；工程2,180–3,560 | 288/432 GB HBM4；8/12 stacks | 官方TBP未核得；工程1.4–2.2 kW |',
    '| TPU7x | 2 compute chiplets；工程800–1,716 | **192 GiB physical** | 工程0.6–1.2 kW |',
    '| TPU8t/8i | 8i原研究为2compute+1IO；工程1,000–2,200 | 官方216/288 GB；物理字节单位待确认 | 工程0.8–1.6 kW |',
    '| Trainium2/3 | 未披露面积；工程600–1,200 / 700–1,500 | AWS明确96/144 **GiB** | 工程0.4–0.8 / 0.5–1.1 kW |',
    '| MTIA300 | **1,280**：803.84 compute+476.16网络die | 216 GB HBM3E，6 stacks | 912 W论文TDP；667 W典型工作负载 |',
    '| Maia200 | 面积工程700–858，非测量 | 216 GB HBM3E | **750 W SoC**；模块代理0.8–1.0 kW |',
    '',
    '规格源：[Hopper](https://developer.nvidia.com/blog/nvidia-hopper-architecture-in-depth/)、[Blackwell原始会议观察](https://library.techinsights.com/sectioned-blog-viewer/9c492ad4-4033-4471-85f0-ff95e970a388?activeMenu=Home)、[B300正式规格表](https://dam-cdn.nvd.orangelogic.com/AssetLink/1k0p832eq8r5ca0u5383ie5o4tp3bst1.pdf)、[Rubin](https://developer.nvidia.com/blog/inside-nvidia-rubin-gpu-architecture-powering-the-era-of-agentic-ai/)、[AMD CDNA4](https://www.amd.com/content/dam/amd/en/documents/instinct-tech-docs/white-papers/amd-cdna-4-architecture-whitepaper.pdf)、[AMD CDNA5](https://www.amd.com/en/technologies/cdna.html)、[MI450X](https://www.amd.com/en/products/accelerators/instinct/mi400/mi450x.html)、[MI455X](https://www.amd.com/en/products/accelerators/instinct/mi400/mi455x.html)、[Google8](https://cloud.google.com/blog/products/compute/tpu-8t-and-tpu-8i-technical-deep-dive)、[AWS](https://awsdocs-neuron.readthedocs-hosted.com/en/latest/about-neuron/arch/neuron-hardware/trainium3.html)、[Meta论文Table I](https://aisystemcodesign.github.io/papers/MTIA300_ISCA2026.pdf)、[Maia](https://blogs.microsoft.com/blog/2026/01/26/maia-200-the-ai-accelerator-built-for-inference/)。工程数不是这些链接公布的面积/功率。',
    '', '## 面积范围怎样使用', '',
    '[ASML](https://www.asml.com/en/products/euv-lithography-systems/twinscan-nxe-3600d)曝光场26×33=858 mm²。已明确reticle-limited的芯片，采用90%–100%曝光场作为工作区间；90%是分析假设，不是物理下界。H100的814、MTIA300计算die的803.84和Blackwell原研究记录790.5支持约800 mm²的量级。两die约1.6千mm²，四die约3.1–3.4千mm²；未公布的有源底层必须另加。',
    '',
    'AMD不能只算XCD：MI350表达式为8aXCD+2aIOD，MI400为8aXCD+2aIOD+2aFabric。JSON列出每个组件的低/中/高假设，可以独立替换。ASIC的公开面积不足，采用更宽的工程设计范围。2030仍保留未来族群，不把某一个未发布SKU伪装成确定规格。CoWoS的5.5或14 reticle是封装尺度，不是logic面积。',
    '', '## 与需求初版接合后的量级', '',
    '下表使用独立需求模块的**base数量**和本模块明确的年度工程mix。每格是BOM低/中/高；这是尚未受HBM、封装、供电限制的需求映射，不是已实现出货或装机预测。2028以后型号结构的不确定性显著扩大。',
    '', '| 年 | device需求，百万 | good logic面积，m² | 当年额定accelerator出货，GW | HBM需求，标称EB |',
    '|---|---:|---:|---:|---:|']
for r in integration:
    md.append(f"| {r['year']} | {r['device_shipments_m']:.2f} | {triple(r['good_logic_silicon_m2_low_mid_high'])} | {triple(r['accelerator_rated_shipment_GW_low_mid_high'])} | {triple(r['HBM_nominal_EB_low_mid_high'])} |")
md += ['',
    '这些情景把新增高算力ASIC逐步纳入HBM，而没有把全部其他ASIC设成零。MTIA200/LPDDR等无HBM分支、Huawei专有内存和Gaudi3 HBM2E仍须单列。现有mix只是可执行起点，不能称为DigiTimes公布的SKU分量。显式GiB保留物理字节账本；与供应商“标称EB”合并时两侧采用同一容量口径，不能只将需求侧乘1.0737。',
    '', '## 三条不能混用的功率桥', '',
    '1. **出货GW** = Σdevice数×额定W÷10⁹。它是设备能力流量。DGX B300官方8 GPU、约14 kW，等于1.75 kW系统/device；HGX B300 GPU上限为1.1 kW。14/8.8=1.59只是该系统的边界对照，不能推广成所有平台的固定倍率。[DGX](https://www.nvidia.com/en-us/data-center/dgx-b300/)',
    '2. **装机GW**从已有存量加当年投运减退役，按cohort跟踪。先将受供应约束的出货经过库存和投运延迟，再加未重复计算的CPU/网络/存储和设施设计余量。JSON提供当年投运50%/70%/90%、新设备寿命4/5/6年等明确情景。',
    '3. **用电TWh** = 时间加权装机×平均IT功率×当年小时数×能源PUE。普通年每平均GW为8.76 TWh，2028为8.784。平均运行功率有idle floor，不能直接等同于TDP×GPU利用率。',
    '',
    '[IEA原报告Table A.1](https://www.iea.org/files/3179f7f8-01f6-4dd6-bffa-c9f7b73f1dc9/KeyQuestionsonEnergyandAI.pdf)提供2025全数据中心总/IT装机114/82 GW及总/IT用电485/352 TWh；2030外部Base为226/174 GW、945/732 TWh。485和945 TWh对应55.37和107.88 GW全年平均总负荷，不是年度芯片出货。将2025的82 GW按AI/非AI拆分后演进，避免再加一遍原有AI存量；2030 IEA只用于外部检验。如果独立芯片路径超过设施容量，应显示安装延后、库存或取消，而不是调低利用率去凑外部预测。',
    '', '## 对下修检验的含义与下一步', '',
    'MI455X换成MI450X使HBM/设备从432降至288 GB，减少三分之一，device数量可以不变。同样，固定stack数和DRAM密度下12-Hi降8-Hi使每设备内存减少三分之一；固定可用DRAM bits理论上支持1.5倍device，但还要满足base die、封装、logic和电力。减少HBM不自动等于减少logic面积或出货GW。',
    '',
    '可直接执行的接合顺序是：数量×SKU mix→按代际/资格匹配HBM→受约束的可交付device→good logic面积与额定出货GW→投运/退役stock→场址与能源。先跑BOM角点和mix敏感性，再判断外部下修是否落在独立范围内。此模块完成数量换算与可复算的参数交付；它本身不宣告全球供需已闭合。',
    '', '复算：`python /workspace/scratch/6aa42040b254/tmp/v4_bom_power_area_build.py`。JSON中保留全部来源、可用年份、单位、未披露项与计算公式。']
md += ['', '## 同device数量的未降规格反事实', '',
'仅对MI450/455产品选择，以及TrendForce已报道仍在评估的Ultra层数分支计算。Ultra主情景取16 stacks、24Gb裸片，12-Hi576GB→8-Hi384GB，采用率50%给出480GB族群均值；8-stack分支减半。16stack/4compute-die是工程分支，不是已定规格。普通Rubin288GB12-Hi保持原样。2028以后未命名族群也不自动纳入降规格。', '',
'| 年 | Ultra eligible，百万 | MI450选用，百万 | 当前配置HBM EB | 同device未降规格HBM EB | 差额EB / 降幅 |',
'|---|---:|---:|---:|---:|---:|']
for c in out['same_device_configuration_counterfactual']['by_year']:
    md.append(f"| {c['year']} | {c['ultra_eligible_devices_m']:.3f} | {c['mi450_selected_devices_m']:.3f} | {c['base_HBM_nominal_EB']:.3f} | {c['unreduced_same_device_HBM_nominal_EB']:.3f} | {c['base_memory_saving_EB']:.3f} / {100*c['saving_fraction_of_unreduced']:.1f}% |")
md += ['', '同数量下，本桥不凭空给logic面积或TDP下调。实际HBM功耗可能下降，但尚无可验证的系统W差额。JSON提供采用率0/50/100%、Ultra份额0.5/1/1.5倍、8/16stack分支；不应用整个行业统一三分之一削减。来源：[TrendForce 8/4](https://www.trendforce.com/presscenter/news/20260804-13166.html)、[9/29](https://www.trendforce.com/presscenter/news/20260929-13255.html)、AMD产品规格。', '',
'代际join面板已逐SKU/年度给出HBM3E/HBM4/HBM4E候选份额；缺少供货商资格/份额时明确为aggregate-match条件。2026Google mix以ToAlpha dated Ironwood约2.5m作参考；未来年度总数仍来自独立需求模型，没有导入ToAlpha前瞻总量。[ToAlpha 10/16](https://toalpha.tw/reports/toalpha-ai-asic-unbundling-20261016-en.pdf)。']
(HERE/'v4_bom_power_area.md').write_text('\n'.join(md)+'\n')
print(json.dumps({'outputs':[str(HERE/'v4_bom_power_area.json'),str(HERE/'v4_bom_power_area.md')], 'sku_rows':len(rows),'sources':len(S),'conditional_integration':integration},ensure_ascii=False,indent=2))
