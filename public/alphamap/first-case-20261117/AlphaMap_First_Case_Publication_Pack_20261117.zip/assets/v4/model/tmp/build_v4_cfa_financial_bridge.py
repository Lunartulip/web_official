"""CFA-framework pre-integration arithmetic. All scenario assumptions remain explicit.

Does not modify the demand, supply or BOM modules and does not ingest SemiAnalysis.
Run from workspace root: python tmp/build_v4_cfa_financial_bridge.py
"""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
demand = json.loads((ROOT / 'v4_accelerator_demand.json').read_text())
bom = json.loads((ROOT / 'v4_bom_power_area.json').read_text())
supply = json.loads((ROOT / 'v4_hbm_supply.json').read_text())
base = {x['year']: x for x in demand['scenarios_m']['base']}
s28 = next(x['supply_nominal_EB'] for x in supply['annual'] if x['year'] == 2028 and x['scenario'] == 'base')
cf28 = next(x for x in bom['same_device_configuration_counterfactual']['by_year'] if x['year'] == 2028)

budget = []
for ratio in (2, 3, 4):
    ref = ratio * base[2026]['gpu_total'] + base[2026]['asic_total']
    for year in range(2026, 2031):
        raw = ratio * base[year]['gpu_total'] + base[year]['asic_total']
        prev = ratio * base[year-1]['gpu_total'] + base[year-1]['asic_total'] if year > 2026 else None
        budget.append({
            'year': year, 'GPU_to_ASIC_equipment_cost_ratio_assumption': ratio,
            'budget_index_2026_equals_100': raw / ref * 100,
            'budget_yoy_change': raw / prev - 1 if prev else None,
            'illustrative_equipment_spend_usdbn_at_ASIC_10000USD': raw * 10,
            'status': 'constant-price, equal-BOM-boundary arithmetic; neither actual prices nor a budget forecast',
        })
budget_capped = []
ratio = 3
ref = ratio * base[2026]['gpu_total'] + base[2026]['asic_total']
req28 = ratio * base[2028]['gpu_total'] + base[2028]['asic_total']
for growth in (0, .2, .4, .6, .8):
    multiplier = min(1.0, ref * (1+growth) / req28)
    budget_capped.append({
        '2028_vs_2026_available_equipment_budget_growth_assumption': growth,
        '2028_affordable_devices_m_same_base_mix': base[2028]['high_end_cloud_core_total'] * multiplier,
        '2028_scale_to_desired_purchase_base': multiplier,
        '2028_affordable_GPU_m': base[2028]['gpu_total'] * multiplier,
        '2028_affordable_ASIC_m': base[2028]['asic_total'] * multiplier,
        'status': 'budget-only ceiling at unchanged component prices/mix; not deliverable shipment forecast',
    })

same_bits = []
same_devices = []
for layers in (12, 8):
    stack_GB = layers * 24 / 8
    stacks_m = 1e9 / stack_GB / 1e6
    same_bits.append({
        'memory_die_Gb': 24, 'layers_per_stack': layers, 'HBM_nominal_EB': 1,
        'GB_per_stack': stack_GB, 'memory_core_dies_m': 1e9/(24/8)/1e6,
        'stacks_and_base_dies_m': stacks_m,
        'supported_8_stack_devices_m': stacks_m/8,
        'supported_16_stack_devices_m': stacks_m/16,
    })
    for stacks in (8, 16):
        same_devices.append({
            'devices_m': 1, 'stacks_per_device': stacks, 'layers_per_stack': layers,
            'HBM_nominal_EB': stacks*stack_GB/1000,
            'stacks_and_base_dies_m': stacks,
            'memory_core_dies_m': stacks*layers,
        })
pricing = []
for premium in (0, .10, .15, .20):
    per_device_ratio = (8/12)*(1+premium)
    pricing.append({
        '8Hi_price_per_bit_premium_assumption': premium,
        'same_bits_revenue_ratio_8Hi_to_12Hi': 1+premium,
        'same_device_count_same_stack_count_revenue_ratio': per_device_ratio,
        'required_device_growth_to_hold_HBM_revenue': 1/per_device_ratio-1,
        'HBM_net_profit_change': None,
        'status': '2028 sensitivity; 10–20% is TrendForce 2027 expectation, not a contracted 2028 forecast',
    })

ultra = []
q28 = cf28['ultra_eligible_devices_m']
for stacks in (8, 16):
    hi = stacks*12*24/8
    lo = stacks*8*24/8
    for adoption in (0, .5, 1):
        units_m = q28*adoption
        saved_EB = units_m*(hi-lo)/1000
        rev = []
        for premium in (0, .1, .2):
            revenue_loss_EB_price_equivalent = units_m*(hi-lo*(1+premium))/1000
            rev.append({
                '8Hi_premium_assumption': premium,
                'revenue_loss_usdbn_per_1_USD_per_GB_of_12Hi_base_price': revenue_loss_EB_price_equivalent,
                'revenue_loss_usdbn_at_illustrative_10_USD_per_GB': revenue_loss_EB_price_equivalent*10,
                'cohort_revenue_loss_fraction_same_units': adoption*(1-(lo/hi)*(1+premium)),
            })
        ultra.append({
            'year': 2028, 'eligible_family': 'Rubin Ultra architecture scenario',
            'eligible_devices_m': q28, 'eligible_share_of_NVIDIA_units': cf28['ultra_share_of_nvidia'],
            'stacks_per_device_assumption': stacks,
            '12Hi_nominal_GB_per_device': hi, '8Hi_nominal_GB_per_device': lo,
            '8Hi_adoption_assumption': adoption,
            'adopting_devices_m': units_m, 'HBM_saving_nominal_EB': saved_EB,
            'base_dies_delta_same_devices_m': 0,
            'DRAM_core_dies_delta_same_devices_m': -units_m*stacks*4,
            'saving_fraction_of_supply_base_2028': saved_EB/s28,
            'revenue_sensitivity': rev,
            'status': 'engineering eligibility/mix/adoption scenario, not confirmed SKU or unit orders',
        })

mi_units = cf28['mi450_selected_devices_m']
mi = {
    'year': 2028, 'MI450_selected_devices_m': mi_units,
    'counterfactual': 'The same MI450X selected devices instead use MI455X specification; no extra units',
    'MI450_nominal_GB': 288, 'MI455_nominal_GB': 432,
    'MI450_stacks': 8, 'MI455_stacks': 12,
    'HBM_saving_nominal_EB': mi_units*(432-288)/1000,
    'stack_and_base_die_reduction_m': mi_units*(12-8),
    'constant_price_revenue_loss_usdbn_per_1_USD_per_GB': mi_units*(432-288)/1000,
    '8Hi_premium_applied': False,
    'status': 'capacities and stacks are product specifications; selected units/mix are analyst assumptions; no layer count inferred',
}

maia = []
for gw in (1, 2, 4):
    devices_m = gw*1e6/167*96/1e6
    maia.append({
        'hypothetical_new_Maia_rack_IT_power_GW': gw,
        'devices_m_at_96_per_167kW_rack': devices_m,
        'fraction_of_2028_other_ASIC_desired_units': devices_m/base[2028]['other_asic'],
        'not_a_dated_company_volume_guidance': True,
    })

contracts = [
    {
        'supplier': 'Micron', 'source_date': '2026-09-30',
        'HBM_2027': 'Vast majority of calendar2027 HBM bit supply under completed agreements; significant YoY price increases.',
        'broader_contracts': {'SCAs_count': 26, 'estimated_revenue_share_through_2030_above': .35,
                             'SCA_estimated_revenue_with_pricing_framework_share': .75,
                             'customer_financial_commitments_usdbn': 32,
                             'RPO_usdbn': 150, 'cash_deposits_balance_usdbn': 12.7,
                             'Q4_cash_deposits_received_usdbn': 12.3},
        'terms': 'All SCAs take-or-pay; RPO includes priced-framework SCAs at committed volumes/minimum prices. Deposits sit in financing cash flow and return later in term if minimum purchases met.',
        'HBM_specific_take_or_pay_coverage_or_2028_revenue_floor_identified': False,
    },
    {
        'supplier': 'Samsung', 'source_date': '2026-10-29',
        'HBM_2027': '2027 HBM supply volume sold out at an agreed target price; further requests received.',
        'broader_contracts': {'signed_major_accounts': 10, 'additional_accounts_in_negotiation': 10,
                             'mid_long_term_capacity_target_under_multiyear_contracts': [.6, .7]},
        'terms': 'Multi-year rolling structure; extensions negotiated annually after initial term. Scope extends beyond HBM/data center.',
        'HBM_specific_take_or_pay_coverage_or_2028_revenue_floor_identified': False,
    },
    {
        'supplier': 'SK hynix', 'source_date': '2026-10-28',
        'HBM_2027': 'No quantified HBM-only contract coverage established by reviewed release.',
        'broader_contracts': {'LTA_customers': 14, '2027_2028_total_capacity_coverage_above': .5,
                             'typical_contract_years': 5},
        'terms': 'Market conditions reflected inside agreed pricing range; reported coverage is total production capacity, not HBM.',
        'HBM_specific_take_or_pay_coverage_or_2028_revenue_floor_identified': False,
    },
]

sources = [
    {'id':'TF_AUG04','url':'https://www.trendforce.com/presscenter/news/20260804-13166.html','web_ref':'turn229view0','date':'2026-08-04'},
    {'id':'TF_SEP29','url':'https://www.trendforce.com/presscenter/news/20260929-13255.html','web_ref':'turn229view1','date':'2026-09-29'},
    {'id':'MU_Q4','url':'https://s25.q4cdn.com/621799436/files/doc_financials/2026/q4/Q4-FY26-Prepared-Remarks.pdf','web_ref':'turn230view0','date':'2026-09-30'},
    {'id':'SS_Q3','url':'https://irsvc.teletogether.com/sec/pdf/2026Q3_script_eng.pdf','local_verified_text':'tmp/v4_samsung_script_q3.txt','date':'2026-10-29'},
    {'id':'SK_Q3','url':'https://news.skhynix.com/en/q3-2026-business-results/','web_ref':'turn230view1','date':'2026-10-28'},
    {'id':'MAIA','url':'https://blogs.microsoft.com/blog/2026/10/12/microsoft-to-expand-azure-maia-system-to-multi-gigawatt-deployments/','web_ref':'turn231view2','date':'2026-10-12'},
    {'id':'MI450','url':'https://www.amd.com/en/products/accelerators/instinct/mi400/mi450x.html','web_ref':'turn242view0','date':'2026-11-12'},
    {'id':'MI455','url':'https://www.amd.com/en/products/accelerators/instinct/mi400/mi455x.html','web_ref':'turn242view1','retrieved_as_of':'2026-11-17'},
    {'id':'MSFT_Q1','url':'https://www.microsoft.com/en-us/Investor/events/fy-2027/earnings-fy-2027-q1','web_ref':'turn233view1','date':'2026-10-28'},
    {'id':'GOOG_Q3','url':'https://abc.xyz/investor/events/event-details/2026/2026-Q3-Earnings-Call-2026-Ujou16CTw9/','web_ref':'turn233view2','date':'2026-10-28'},
    {'id':'AMZN_Q3','url':'https://ir.aboutamazon.com/news-release/news-release-details/2026/Amazon-com-Announces-Third-Quarter-Results/','web_ref':'turn234view0','date':'2026-10-29'},
    {'id':'META_Q3','url':'https://investor.atmeta.com/investor-news/press-release-details/2026/Meta-Reports-Third-Quarter-2026-Results/default.aspx','web_ref':'turn234view1','date':'2026-10-21'},
]

out = {
    'as_of': '2026-11-17',
    'role': 'CFA-framework analytical review, not an external professional credential',
    'semi_analysis_used_as_input': False,
    'module_state': 'quantified pre-integration financial bridge; global model and valuation not finalized here',
    'input_modules': ['tmp/v4_accelerator_demand.json','tmp/v4_bom_power_area.json','tmp/v4_hbm_supply.json'],
    'unit_contract': 'Nominal supply-chain EB=1e9 nominal GB; million logical accelerator devices. All unit prices are explicit sensitivities, not forecasts.',
    'growth_audit': {
        '2026_to_2028_device_growth': base[2028]['high_end_cloud_core_total']/base[2026]['high_end_cloud_core_total']-1,
        '2026_to_2028_ASIC_increment_share_of_total_increment': (base[2028]['asic_total']-base[2026]['asic_total'])/(base[2028]['high_end_cloud_core_total']-base[2026]['high_end_cloud_core_total']),
        'conclusion': 'Published budgets/project descriptions establish direction and funding scale, not the specific 20/70/85/70 percent2027 or10/40/40/40 percent2028 cohort growth. Retain these as conditional desired-purchase scenarios; financial ceilings are now quantified below.',
    },
    'budget_index_formula': 'B_t/P_ASIC = r*Q_GPU_t+Q_ASIC_t; constant real unit prices and equal hardware scope. Index=100*B_t/B_2026.',
    'budget_index': budget,
    '2028_budget_ceiling_scenarios': budget_capped,
    '2028_budget_requirement_unit_cost_sensitivity': [
        {
            '2028_uniform_real_unit_cost_change_assumption': change,
            'required_budget_growth_2028_vs2026': (req28/ref)*(1+change)-1,
            'GPU_to_ASIC_unit_cost_ratio': 3,
            'status': 'conditional price sensitivity, not a device-price forecast',
        } for change in (-.2, 0, .2)
    ],
    'buyer_mapping_fix': 'Separate owned hardware, third-party leased hardware and externally sold TPU inventory. Buyer service revenue, neocloud lease payments and hosting revenue do not add separate physical units.',
    'same_one_EB_12Hi_vs_8Hi': same_bits,
    'same_one_million_devices': same_devices,
    '8Hi_revenue_sensitivity': pricing,
    'ultra_2028_sensitivity': ultra,
    'MI450_vs_MI455_2028': mi,
    'combined_2028_configuration_bridge': {
        'unreduced_same_device_HBM_EB': cf28['unreduced_same_device_HBM_nominal_EB'],
        'base_desired_purchase_HBM_EB': cf28['base_HBM_nominal_EB'],
        'saving_EB': cf28['base_memory_saving_EB'],
        'saving_fraction_of_same_device_unreduced': cf28['saving_fraction_of_unreduced'],
        'saving_fraction_of_supply_base': cf28['base_memory_saving_EB']/s28,
        'max_saving_EB_current_eligible_units_full_adoption': cf28['max_saving_EB_at_base_eligible_units_full_adoption'],
        'status': 'Same-device architecture/adoption counterfactual; not global demand revision and not Jensen-event attribution.',
    },
    'maia_project_scale_sensitivity': maia,
    'supplier_contract_disclosures': contracts,
    'sources': sources,
    'publication_boundaries': [
        'Do not call desired-purchase device growth a budget-backed most-probable shipment forecast.',
        '8Hi same-bit support is a memory-only ceiling: qualified stack/base-die/package/power availability still binds.',
        'MI450/455 stack-count substitution has different base-die economics from Ultra layer reduction.',
        'No disclosed 2028 HBM price/margin floor or HBM-only share of broad SCAs is inferred.',
        'No price target, net-profit forecast or valuation alpha follows from the physical bridge alone.',
    ],
}
(ROOT/'v4_cfa_financial_bridge.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({
    'budget_2028_indices': [x for x in budget if x['year']==2028],
    'budget_ceilings': budget_capped,
    'configuration': out['combined_2028_configuration_bridge'],
    'ultra_base': next(x for x in ultra if x['stacks_per_device_assumption']==16 and x['8Hi_adoption_assumption']==.5),
    'MI450': mi,
    'maia':maia,
},ensure_ascii=False,indent=2))
