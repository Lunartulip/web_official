"""Independent conditional accelerator/HBM/facility model, as of2026-11-17.

No SemiAnalysis values enter panel(), memory_solve() or run(). Inputs remain frozen.
Manufacturing is a modeled procurement policy result, not observed market shipments.
Memory quantities use consistent nominal industry GB/EB labels, not SI byte claims.
"""
from pathlib import Path
from functools import lru_cache
import json, math, hashlib, copy, collections
from scipy.optimize import linprog

ROOT=Path(__file__).resolve().parents[1]
TMP=ROOT/'tmp'
D=json.loads((TMP/'v4_accelerator_demand.json').read_text())
B=json.loads((TMP/'v4_bom_power_area.json').read_text())
S=json.loads((TMP/'v4_hbm_supply.json').read_text())
GROUPS=['nvidia_gpu','other_gpu','google_tpu','other_asic']
GENS=['HBM3e_or_earlier','HBM4','HBM4e','later_generation_placeholder']
SKUS={r['id']:r for r in B['sku_panel']}
JOIN={(r['year'],r['sku_id']):r for r in B['generation_join_panel']}
FUTURE24={'nvidia_future_family':480,'amd_future_family':480,'mtia500_future_family':480,
          'google_future_family':384,'trainium_future_family':288,'other_asic_future':240}
OPENING_PIPELINE_IT_GW=5.67155650245364
# Opening state is fixed once, independently of future facility growth/ordering horizon.
# Physical composition is a declared2025-available engineering proxy, not measured stock.
OPENING_DEVICE_SHARES={'h200_sxm':.5,'b200_hgx':.5}
OPENING_SYSTEM_OVERHEAD=1.45
COST_WEIGHTS={'nvidia_gpu':3.,'other_gpu':3.,'google_tpu':1.,'other_asic':1.}


def panel(year,demand_case='base',power_index=1,memory_index=1,area_index=1,
          demand_multiplier=1.,future_memory_scale=1.,residual_pool_share=1.,
          unchanged_configuration=False,density_transition='constant24'):
    """Future capacities are physical configuration population means, not single SKUs.

    constant24: do not force future families into an assumed32Gb supply pool.
    target32_sensitivity:40/70% device share in2029/30; this is a fixed-mix stress.
    Annual gen-capacity LP must cover every fulfilled density variant.
    """
    yy=min(year,2030)
    dr=next(r for r in D['scenarios_m'][demand_case] if r['year']==yy)
    assert density_transition in ('constant24','target32_sensitivity')
    late32=({2029:.4,2030:.7}.get(yy,0.) if density_transition=='target32_sensitivity' else 0.)
    out=[]
    for group in GROUPS:
        for sid,share in B['analyst_sku_mix_by_year'][str(yy)][group].items():
            sk=SKUS[sid];gs=copy.deepcopy(JOIN[yy,sid]['hbm_generation_share'])
            q=dr[group]*share*demand_multiplier
            cap=sk['memory']['engineering_nominal_GB_low_mid_high'][memory_index]
            if sid=='h200_sxm':cap=144. # Physical-capacity proxy; do not use141GB usable as physical demand.
            if sid=='rubin_ultra_scenario':cap=[192.,480.,576.][memory_index]
            if sid in FUTURE24:
                c24=FUTURE24[sid]
                if memory_index!=1:
                    if sid=='google_future_family':c24=[288.,384.,576.][memory_index]
                    elif sid=='trainium_future_family':c24=[192.,288.,384.][memory_index]
                    else:c24*=([.8,1.,1.2][memory_index])
                c24*=future_memory_scale
                # In2026-28 these named future GPU family placeholders use a4E24Gb branch.
                if yy<=2028 and sid in ('nvidia_future_family','amd_future_family'):gs={'HBM4E':1.}
                variants=[(1-late32,24,c24),(late32,32,c24*4/3)]
            else:variants=[(1.,None,cap)]
            for vshare,density,capacity in variants:
                if vshare<=0:continue
                if unchanged_configuration:
                    if sid=='rubin_ultra_scenario':capacity=288. if memory_index==0 else 576.
                    elif sid=='mi450x':capacity=432.
                gen_cap={g:0. for g in GENS};outside=0.
                for gen,sh in gs.items():
                    mem=capacity*sh
                    if gen=='HBM3E':mapped=GENS[0]
                    elif gen=='HBM4':mapped=GENS[1]
                    elif gen in ('HBM4E','HBM4E_or_later'):mapped=GENS[2]
                    else:mapped=None
                    if density==32 and mapped is not None:mapped=GENS[3]
                    if mapped is None:outside+=mem
                    else:gen_cap[mapped]+=mem
                if group=='other_asic' and residual_pool_share<1:
                    for g in gen_cap:
                        outside+=gen_cap[g]*(1-residual_pool_share)
                        gen_cap[g]*=residual_pool_share
                assert abs(sum(gen_cap.values())+outside-capacity)<1e-7
                out.append(dict(year=year,group=group,sku=sid,
                    variant=(f'future_{density}Gb_population' if density else 'reference_configuration'),
                    DRAM_die_density_Gb=density,desired_m=q*vshare,
                    memory_GB=capacity,gen_GB=gen_cap,outside_pool_GB=outside,
                    logic_mm2=sk['logic_area']['engineering_mm2_low_mid_high'][area_index],
                    rated_W=sk['power']['engineering_accelerator_W_low_mid_high'][power_index]))
    return out


def aggregate(rows):
    return dict(devices_m=sum(r['desired_m'] for r in rows),
        logic_m2=sum(r['desired_m']*r['logic_mm2'] for r in rows),
        rated_GW=sum(r['desired_m']*r['rated_W']/1000 for r in rows),
        memory_EB=sum(r['desired_m']*r['memory_GB']/1000 for r in rows),
        pool_EB=sum(r['desired_m']*sum(r['gen_GB'].values())/1000 for r in rows),
        outside_pool_EB=sum(r['desired_m']*r['outside_pool_GB']/1000 for r in rows),
        gen_EB={g:sum(r['desired_m']*r['gen_GB'][g]/1000 for r in rows) for g in GENS})


@lru_cache(maxsize=4096)
def _memory_solve(year,gen_demand,supply_case,flexibility,qualification):
    """Million processing wafers. The existing effective recovery already includes qualification.

    qualification=1 is base. Smaller values are EXTRA allocation/mismatch stresses,
    not an additional physical yield estimate. Planned down-generation processing
    is not substitution of a finishedHBM4E package into anHBM3E socket.
    """
    yy=min(year,2030)
    rs=[r for r in S['supplier_generation_panel'] if r['year']==yy and r['scenario']==supply_case]
    nv=len(rs)+1;A=[];b=[]
    for supplier in S['supplier_order']:
        rr=[r for r in rs if r['supplier']==supplier]
        total=rr[0]['avg_matched_processing_kwpm']*12/1000
        A.append([float(r['supplier']==supplier) for r in rs]+[0.]);b.append(total)
        if flexibility=='planned_reallocation':
            for level in range(1,4):
                envelope=sum(r['allocated_processing_wafers']/1e6 for r in rr if GENS.index(r['generation'])>=level)
                A.append([float(r['supplier']==supplier and GENS.index(r['generation'])>=level) for r in rs]+[0.]);b.append(envelope)
    for i,g in enumerate(GENS):
        A.append([-r['effective_nominal_GB_per_allocated_wafer']/1000*qualification if r['generation']==g else 0. for r in rs]+[gen_demand[i]])
        b.append(0.)
    bounds=[]
    for r in rs:
        hi=r['allocated_processing_wafers']/1e6 if flexibility=='fixed_generation_plan' else None
        if r['generation']=='later_generation_placeholder' and yy<2029:hi=0.
        bounds.append((0,hi))
    bounds.append((0,1))
    opt=linprog([0.]*(nv-1)+[-1.],A_ub=A,b_ub=b,bounds=bounds,method='highs')
    assert opt.success,opt.message
    f=float(opt.x[-1])
    minimum=linprog([1.]*(nv-1)+[0.],A_ub=A,b_ub=b,bounds=bounds[:-1]+[(f,f)],method='highs')
    assert minimum.success,minimum.message
    allocations=[]
    for r,w in zip(rs,minimum.x[:-1]):
        allocations.append(dict(supplier=r['supplier'],generation=r['generation'],wafers_m=float(w),
            qualified_output_EB=float(w)*r['effective_nominal_GB_per_allocated_wafer']/1000*qualification,
            initial_plan_wafers_m=r['allocated_processing_wafers']/1e6,
            initial_plan_qualified_output_EB=r['supply_nominal_EB'],
            geometric_dies_per_wafer=r['geometric_dies_per_wafer'],
            nominal_Gb_per_memory_die=r['nominal_Gb_per_memory_die'],
            effective_qualified_recovery=r['effective_recovery'],
            effective_nominal_GB_per_allocated_wafer=r['effective_nominal_GB_per_allocated_wafer'],
            incremental_allocation_fraction=qualification,
            delta_wafers_m_vs_plan=float(w)-r['allocated_processing_wafers']/1e6))
    fixed_plan=sum(r['supply_nominal_EB'] for r in rs)
    available_wafers=sum(next(r['avg_matched_processing_kwpm'] for r in rs if r['supplier']==supplier)*12/1000 for supplier in S['supplier_order'])
    max_output=sum(a['qualified_output_EB'] for a in allocations)
    zero_gens=[g for i,g in enumerate(GENS) if gen_demand[i]>1e-10 and sum(r['supply_nominal_EB'] for r in rs if r['generation']==g)<1e-10]
    return dict(max_proportional_fulfillment=f,incremental_allocation_fraction=qualification,
        extra_allocation_fraction_is_assumption=True,physical_qualification_already_in_supplier_recovery=True,
        method=flexibility,maximum_fixed_mix_allocations=allocations,
        maximum_matched_output_EB=max_output,
        fixed_plan_qualified_capacity_EB=fixed_plan,
        fixed_plan_after_extra_allocation_fraction_EB=fixed_plan*qualification,
        reallocated_recipe_minus_fixed_plan_EB=max_output-fixed_plan*qualification,
        available_processing_wafers_m=available_wafers,
        used_processing_wafers_m=sum(a['wafers_m'] for a in allocations),
        reallocated_wafers_m_by_generation={g:sum(a['wafers_m'] for a in allocations if a['generation']==g) for g in GENS},
        fixed_plan_wafers_m_by_generation={g:sum(a['initial_plan_wafers_m'] for a in allocations if a['generation']==g) for g in GENS},
        aggregate_output_equation='sum_s,g(wafers_m_sg * dies_per_wafer_sg * nominal_Gb_per_die_sg /8 * effective_qualified_recovery_sg * extra_allocation_fraction)/1000 = nominalEB',
        comparison_scope='Initialfixedplanisqualifiedsupplycapability;reallocatedoutputisthemaximumsupportedoutputforthedesiredmixafterwaferrecipechanges,orlowerifdemandalreadyfullysatisfied. Neitherisautomaticactualproduction.',
        fixed_mix_infeasible=(f<1e-9),zero_supply_positive_demand_generations=zero_gens,
        interpretation=('Fixed desired mix infeasible; NOT a prediction of zero market shipments.' if f<1e-9 else 'Capacity ceiling for the stated fixed proportional mix, not actual supplier production.'))


def memory_solve(year,agg,supply_case='base',flexibility='planned_reallocation',qualification=1.):
    return copy.deepcopy(_memory_solve(year,tuple(agg['gen_EB'][g] for g in GENS),supply_case,flexibility,qualification))


PHYSICAL_KEYS=['devices_m','memory_EB','pool_EB','outside_pool_EB','logic_m2','rated_GW','IT_GW','cost_index_m']
def cohort_stats(rows):
    a={k:0. for k in PHYSICAL_KEYS};a['group_devices_m']={g:0. for g in GROUPS};a['gen_EB']={g:0. for g in GENS}
    for r in rows:
        u=r['units_m'];a['devices_m']+=u;a['memory_EB']+=u*r['memory_GB']/1000
        a['outside_pool_EB']+=u*r['outside_pool_GB']/1000
        a['logic_m2']+=u*r['logic_mm2'];a['rated_GW']+=u*r['rated_W']/1000
        a['IT_GW']+=u*r['system_W']/1000;a['cost_index_m']+=u*COST_WEIGHTS[r['group']]
        a['group_devices_m'][r['group']]+=u
        for g in GENS:a['gen_EB'][g]+=u*r['gen_GB'][g]/1000
    a['pool_EB']=sum(a['gen_EB'].values())
    return a


def component(r,units_m,origin_q,ready_q,overhead,opening=False):
    return dict(sku=r['sku'],variant=r.get('variant','reference_configuration'),group=r['group'],
        units_m=units_m,origin_q=origin_q,origin_year=2026+(origin_q-1)//4,
        origin_quarter=(origin_q-1)%4+1,ready_q=ready_q,opening=opening,
        memory_GB=r['memory_GB'],gen_GB=copy.deepcopy(r['gen_GB']),outside_pool_GB=r['outside_pool_GB'],
        logic_mm2=r['logic_mm2'],rated_W=r['rated_W'],system_W=r['rated_W']*overhead)


def opening_components():
    meanW=sum(share*SKUS[sid]['power']['engineering_accelerator_W_low_mid_high'][1] for sid,share in OPENING_DEVICE_SHARES.items())
    total_m=OPENING_PIPELINE_IT_GW*1000/(meanW*OPENING_SYSTEM_OVERHEAD)
    result=[]
    for sid,share in OPENING_DEVICE_SHARES.items():
        sk=SKUS[sid];cap=sk['memory']['model_nominal_GB'];gen={g:0. for g in GENS};gen[GENS[0]]=cap
        r=dict(sku=sid,group='nvidia_gpu',variant='opening_2025_engineering_proxy',memory_GB=cap,gen_GB=gen,
            outside_pool_GB=0.,logic_mm2=sk['logic_area']['engineering_mm2_low_mid_high'][1],
            rated_W=sk['power']['engineering_accelerator_W_low_mid_high'][1])
        result.append(component(r,total_m*share,0,1,OPENING_SYSTEM_OVERHEAD,True))
    return result


def fifo_release(pipeline,iq,available_IT_GW):
    """FIFO by ready/origin quarter; same-batch components deploy proportionally."""
    deployed=[];left=max(0.,available_IT_GW)
    batches=sorted(set((r['ready_q'],r['origin_q']) for r in pipeline if r['ready_q']<=iq))
    for key in batches:
        batch=[r for r in pipeline if (r['ready_q'],r['origin_q'])==key]
        it=cohort_stats(batch)['IT_GW'];fraction=min(1.,left/it) if it>1e-12 else 1.
        for row in batch:
            take=row['units_m']*fraction
            if take>1e-12:
                d=copy.deepcopy(row);d['units_m']=take;d['installed_q']=iq;deployed.append(d);row['units_m']-=take
        left=max(0.,left-it*fraction)
        if left<1e-10:break
    return [r for r in pipeline if r['units_m']>1e-12],deployed


def inventory_detail(rows):
    out=[]
    for r in rows:
        z=cohort_stats([r])
        out.append(dict(sku=r['sku'],variant=r['variant'],group=r['group'],origin_year=r['origin_year'],
            origin_quarter=r['origin_quarter'],ready_quarter_index=r['ready_q'],opening_proxy=r['opening'],
            devices_m=z['devices_m'],HBM_EB=z['memory_EB'],top3_matched_HBM_EB=z['pool_EB'],
            outside_pool_HBM_EB=z['outside_pool_EB'],logic_m2=z['logic_m2'],rated_GW=z['rated_GW'],IT_GW=z['IT_GW'],
            normalized_cost_index_m=z['cost_index_m'],gen_HBM_EB=z['gen_EB']))
    return out


def run(name='base',facility_growth=.25,demand_case='base',supply_case='base',
        power_index=1,memory_index=1,area_index=1,overhead=1.45,qualification=1.,
        flexibility='planned_reallocation',demand_multiplier=1.,future_memory_scale=1.,
        residual_pool_share=1.,facility_ai_ready=1.,lag_quarters=1,procurement_lookahead_quarters=1,
        energy_load=.60,pue=1.15,unchanged_configuration=False,facility_constraint=True,
        procurement_constraint=True,event_lost_IT_GW=0.,density_transition='constant24',
        legacy_retirement='uniform_remaining_life_5y',opening_pipeline_scale=1.):
    params=locals().copy()
    assert lag_quarters>=1 and procurement_lookahead_quarters>=1
    horizon=max(lag_quarters,procurement_lookahead_quarters)
    panels={y:panel(y,demand_case,power_index,memory_index,area_index,demand_multiplier,
        future_memory_scale,residual_pool_share,unchanged_configuration,density_transition) for y in range(2026,2031)}
    aggs={y:aggregate(v) for y,v in panels.items()}
    memories={y:memory_solve(y,aggs[y],supply_case,flexibility,qualification) for y in aggs}
    def site(t):
        conv=57*1.02**t;total=82*(1+facility_growth)**t
        lost=event_lost_IT_GW*min(max((t-3)/2,0),1)
        ai=25+facility_ai_ready*max(0.,(total-82)-(conv-57))-lost
        return total-lost,conv,max(0.,ai)
    def legacy(t):
        if legacy_retirement=='declining_20pct':return 25*.8**t
        return max(0.,25*(1-t/5))
    pipeline=opening_components()
    for r in pipeline:r['units_m']*=opening_pipeline_scale
    opening_rows=copy.deepcopy(pipeline)
    opening=cohort_stats(pipeline);installed=[];qs=[];yearend={}
    previous_inventory=copy.deepcopy(opening);previous_installed=cohort_stats([])
    cumulative_shipped=cohort_stats([]);cumulative_commissioned=cohort_stats([])
    balance_errors={k:0. for k in PHYSICAL_KEYS}
    prev_legacy=25.;prev_conv=57.;prev_new_IT=0.
    # Match both2025IEA total485TWh andIT352TWh, after an explicit150TWhAI split.
    legacy_pue=1.15;legacy_load=150/(25*8.76*legacy_pue)
    conventional_IT_TWh=352-150/legacy_pue
    conventional_pue=(485-150)/conventional_IT_TWh
    conventional_load=conventional_IT_TWh/(57*8.76)
    for iq in range(1,21):
        year=2026+(iq-1)//4;quarter=(iq-1)%4+1;t=iq/4
        agg=aggs[year];memory=memories[year];total,conv,ai_ceiling=site(t)
        retired=[r for r in installed if iq-r['installed_q']>=20]
        installed=[r for r in installed if iq-r['installed_q']<20]
        before=cohort_stats(installed);legacy_end=legacy(t)
        ready=cohort_stats([r for r in pipeline if r['ready_q']<=iq])['IT_GW']
        headroom=max(0.,ai_ceiling-legacy_end-before['IT_GW']) if facility_constraint else ready
        pipeline,deployed=fifo_release(pipeline,iq,headroom)
        installed.extend(deployed)
        dep=cohort_stats(deployed);ret=cohort_stats(retired);inst=cohort_stats(installed)
        ai_installed=legacy_end+inst['IT_GW']
        future_q=iq+horizon;next_t=future_q/4
        _,_,future_ceiling=site(next_t)
        future_existing=legacy(next_t)+cohort_stats([r for r in installed if future_q-r['installed_q']<20])['IT_GW']
        future_pipeline=cohort_stats(pipeline)['IT_GW']
        planned_space=max(0.,future_ceiling-future_existing-future_pipeline)
        desired_system=agg['rated_GW']/4*overhead
        fpower=min(1.,planned_space/desired_system) if procurement_constraint and desired_system>0 else 1.
        f=min(1.,memory['max_proportional_fulfillment'],fpower)
        purchased=[component(r,r['desired_m']/4*f,iq,iq+lag_quarters,overhead) for r in panels[year] if r['desired_m']*f>1e-12]
        ship=cohort_stats(purchased);pipeline.extend(purchased);inv=cohort_stats(pipeline)
        # Full physical inventory and installed-cohort conservation, not justGW.
        for k in PHYSICAL_KEYS:
            err=previous_inventory[k]+ship[k]-dep[k]-inv[k]
            balance_errors[k]=max(balance_errors[k],abs(err))
            assert abs(err)<(1e-6 if k=='logic_m2' else 1e-8),(name,iq,k,err)
            ierr=previous_installed[k]+dep[k]-ret[k]-inst[k]
            assert abs(ierr)<(1e-6 if k=='logic_m2' else 1e-8),(name,iq,'installed',k,ierr)
            cumulative_shipped[k]+=ship[k];cumulative_commissioned[k]+=dep[k]
        assert not facility_constraint or ai_installed<=ai_ceiling+1e-7
        previous_inventory=copy.deepcopy(inv);previous_installed=copy.deepcopy(inst)
        days=[90,91,92,92][quarter-1]+(1 if year%4==0 and quarter==1 else 0)
        hours=24*days
        legacy_energy=(prev_legacy+legacy_end)/2*legacy_load*legacy_pue*hours/1000
        new_energy=(prev_new_IT+inst['IT_GW'])/2*energy_load*pue*hours/1000
        conventional_energy=(prev_conv+conv)/2*conventional_load*conventional_pue*hours/1000
        qrow=dict(year=year,quarter=quarter,factory_fulfillment=f,
            memory_max_fulfillment=memory['max_proportional_fulfillment'],facility_max_fulfillment=fpower,
            manufactured_devices_m=ship['devices_m'],logic_m2=ship['logic_m2'],rated_shipment_GW=ship['rated_GW'],
            embedded_HBM_EB=ship['memory_EB'],embedded_top3_pool_HBM_EB=ship['pool_EB'],outside_pool_memory_EB=ship['outside_pool_EB'],
            commissioned_devices_m=dep['devices_m'],commissioned_HBM_EB=dep['memory_EB'],commissioned_top3_pool_HBM_EB=dep['pool_EB'],
            commissioned_logic_m2=dep['logic_m2'],commissioned_IT_GW=dep['IT_GW'],
            retired_new_devices_m=ret['devices_m'],retired_new_HBM_EB=ret['memory_EB'],retired_new_IT_GW=ret['IT_GW'],
            installed_AI_IT_GW=ai_installed,installed_legacy_AI_IT_GW=legacy_end,installed_new_AI_IT_GW=inst['IT_GW'],
            installed_new_devices_m=inst['devices_m'],installed_conventional_IT_GW=conv,facility_IT_ceiling_GW=total,AI_ready_IT_ceiling_GW=ai_ceiling,
            pipeline_IT_GW=inv['IT_GW'],pipeline_devices_m=inv['devices_m'],pipeline_HBM_EB=inv['memory_EB'],
            pipeline_top3_HBM_EB=inv['pool_EB'],pipeline_logic_m2=inv['logic_m2'],pipeline_cost_index_m=inv['cost_index_m'],
            AI_energy_TWh=legacy_energy+new_energy,all_DC_energy_TWh=legacy_energy+new_energy+conventional_energy,
            group_devices_m=ship['group_devices_m'],inventory_group_devices_m=inv['group_devices_m'],
            desired_but_not_procured_devices_m=max(0.,agg['devices_m']/4-ship['devices_m']))
        qs.append(qrow)
        if quarter==4:yearend[year]=inventory_detail(pipeline)
        prev_legacy=legacy_end;prev_new_IT=inst['IT_GW'];prev_conv=conv
    annual=[];start_inv=opening
    flowkeys=['manufactured_devices_m','logic_m2','rated_shipment_GW','embedded_HBM_EB','embedded_top3_pool_HBM_EB','outside_pool_memory_EB',
        'commissioned_devices_m','commissioned_HBM_EB','commissioned_top3_pool_HBM_EB','commissioned_logic_m2','commissioned_IT_GW',
        'retired_new_devices_m','retired_new_HBM_EB','retired_new_IT_GW','AI_energy_TWh','all_DC_energy_TWh','desired_but_not_procured_devices_m']
    endkeys=['installed_AI_IT_GW','installed_legacy_AI_IT_GW','installed_new_AI_IT_GW','installed_new_devices_m',
        'installed_conventional_IT_GW','facility_IT_ceiling_GW','AI_ready_IT_ceiling_GW','pipeline_IT_GW','pipeline_devices_m',
        'pipeline_HBM_EB','pipeline_top3_HBM_EB','pipeline_logic_m2','pipeline_cost_index_m']
    for y in range(2026,2031):
        rr=[q for q in qs if q['year']==y];a=aggs[y]
        item=dict(year=y,desired_devices_m=a['devices_m'],desired_HBM_EB=a['memory_EB'],desired_top3_pool_HBM_EB=a['pool_EB'],
            unconstrained_logic_m2=a['logic_m2'],unconstrained_rated_shipment_GW=a['rated_GW'])
        item.update({k:sum(q[k] for q in rr) for k in flowkeys});item.update({k:rr[-1][k] for k in endkeys})
        item['installed_all_DC_IT_GW']=item['installed_AI_IT_GW']+item['installed_conventional_IT_GW']
        item['all_DC_average_facility_GW']=item['all_DC_energy_TWh']/(8.784 if y%4==0 else 8.76)
        item['manufactured_group_devices_m']={g:sum(q['group_devices_m'][g] for q in rr) for g in GROUPS}
        item['inventory_group_devices_m']=rr[-1]['inventory_group_devices_m']
        item['inventory_by_sku_origin']=yearend[y]
        item['inventory_device_change_m']=item['pipeline_devices_m']-start_inv['devices_m']
        item['inventory_HBM_change_EB']=item['pipeline_HBM_EB']-start_inv['memory_EB']
        item['inventory_logic_change_m2']=item['pipeline_logic_m2']-start_inv['logic_m2']
        item['inventory_IT_change_GW']=item['pipeline_IT_GW']-start_inv['IT_GW']
        item['inventory_cost_index_change_m']=item['pipeline_cost_index_m']-start_inv['cost_index_m']
        assert abs(item['manufactured_devices_m']-item['commissioned_devices_m']-item['inventory_device_change_m'])<1e-8
        assert abs(item['embedded_HBM_EB']-item['commissioned_HBM_EB']-item['inventory_HBM_change_EB'])<1e-8
        start_inv=dict(devices_m=item['pipeline_devices_m'],memory_EB=item['pipeline_HBM_EB'],logic_m2=item['pipeline_logic_m2'],IT_GW=item['pipeline_IT_GW'],cost_index_m=item['pipeline_cost_index_m'])
        item['production_to_desired_ratio']=item['manufactured_devices_m']/item['desired_devices_m']
        maxf=memories[y]['max_proportional_fulfillment'];actualf=item['production_to_desired_ratio']
        scale=actualf/maxf if maxf>1e-12 else 0.
        alloc=[]
        for r in memories[y]['maximum_fixed_mix_allocations']:
            z=copy.deepcopy(r);z['wafers_m']*=scale;z['qualified_output_EB']*=scale
            z['delta_wafers_m_vs_plan']=z['wafers_m']-z['initial_plan_wafers_m'];alloc.append(z)
        item['matched_wafer_allocation_for_actual_procurement']=alloc
        item['matched_HBM_absorption_EB']=sum(z['qualified_output_EB'] for z in alloc)
        assert abs(item['matched_HBM_absorption_EB']-item['embedded_top3_pool_HBM_EB'])<1e-7
        item['HBM_supplier_shipments_proxy_EB']=item['embedded_top3_pool_HBM_EB']
        item['HBM_supplier_proxy_status']='Only matched accelerator-package absorption, assumingzero change in rawHBM/WIPinventory; excludes otherHBMcustomers and is not totalHBMmarket revenue or output.'
        item['fixed_mix_feasibility_diagnostic_only']=memories[y]['fixed_mix_infeasible']
        item['not_procured_status']='Unfilled potential flow; not assertedcancelledsignedorders. No automaticcarryforward into futureannualdemand.'
        annual.append(item)
    return dict(name=name,parameters=params,opening_2025_pipeline_IT_GW=opening['IT_GW'],opening_inventory=opening,
        opening_inventory_by_sku_origin=inventory_detail(opening_rows),annual=annual,quarters=qs,
        memory_annual_constraints={str(y):memories[y] for y in range(2026,2031)},
        max_physical_inventory_balance_errors=balance_errors,
        energy_calibration_2025=dict(AI_total_TWh=150,conventional_total_TWh=335,total_TWh=485,total_IT_TWh=352,
            legacy_AI_load=legacy_load,conventional_load=conventional_load,conventional_PUE=conventional_pue),
        procurement_interpretation='Procurementpacedtofuturefacilityheadroom.1/2/4quarterwindowsarepolicyscenarios; nonehasanassignedprobability.')


def compact_2028(r):
    a=next(x for x in r['annual'] if x['year']==2028)
    keys=['manufactured_devices_m','embedded_top3_pool_HBM_EB','embedded_HBM_EB','outside_pool_memory_EB',
          'rated_shipment_GW','logic_m2','installed_AI_IT_GW','pipeline_IT_GW','pipeline_HBM_EB','pipeline_devices_m',
          'pipeline_cost_index_m','inventory_HBM_change_EB','inventory_device_change_m','all_DC_energy_TWh']
    return {k:a[k] for k in keys}


def build():
    cases={}
    specs=[('base',{}),('procurement_lookahead_1q',{}),
      ('procurement_lookahead_2q',{'procurement_lookahead_quarters':2}),
      ('procurement_lookahead_4q',{'procurement_lookahead_quarters':4}),
      ('facility_growth_15pct',{'facility_growth':.15}),('facility_growth_20pct',{'facility_growth':.20}),
      ('facility_growth_30pct',{'facility_growth':.30}),('facility_growth_35pct',{'facility_growth':.35}),
      ('HBM_only',{'procurement_constraint':False}),
      ('fixed_generation',{'flexibility':'fixed_generation_plan'}),
      ('qualification_95pct_extra_stress',{'qualification':.95}),('qualification_85pct_extra_stress',{'qualification':.85}),
      ('HBM_supply_low',{'supply_case':'low'}),('HBM_supply_high',{'supply_case':'high'}),
      ('demand_minus20pct',{'demand_multiplier':.8}),('demand_low_path',{'demand_case':'low'}),('demand_high_path',{'demand_case':'high'}),
      ('memory_low',{'memory_index':0}),('memory_high',{'memory_index':2}),
      ('power_low',{'power_index':0}),('power_high',{'power_index':2}),
      ('area_low',{'area_index':0}),('area_high',{'area_index':2}),
      ('overhead_125',{'overhead':1.25}),('overhead_165',{'overhead':1.65}),
      ('AI_readiness_85pct',{'facility_ai_ready':.85}),('other_ASIC_pool80pct',{'residual_pool_share':.8}),
      ('unreduced_eligible_memory',{'unchanged_configuration':True}),
      ('optional_3_8GW_not_built',{'event_lost_IT_GW':3.8}),
      ('physical_lag_two_quarters',{'lag_quarters':2,'procurement_lookahead_quarters':2}),
      ('forced32_transition_sensitivity',{'density_transition':'target32_sensitivity'}),
      ('legacy_declining20pct',{'legacy_retirement':'declining_20pct'}),('opening_pipeline_zero',{'opening_pipeline_scale':0.})]
    for name,kw in specs:cases[name]=run(name,**kw)
    grid=[]
    for g in [.20,.25,.30]:
        for horizon in [1,2,4]:
            for pi in [0,1,2]:
                r=run('interactive',facility_growth=g,procurement_lookahead_quarters=horizon,power_index=pi)
                grid.append(dict(facility_growth=g,procurement_lookahead_quarters=horizon,physical_lag_quarters=1,
                    power_index=pi,memory_index=1,area_index=1,year=2028,**compact_2028(r)))
    # Threshold means a stated procurement target, with a fixed initial state and other assumptions held fixed.
    def threshold(target,metric):
        lo=.15;hi=.45
        if compact_2028(run('threshold_hi',facility_growth=hi))[metric]<target:return None
        for _ in range(21):
            mid=(lo+hi)/2
            if compact_2028(run('threshold',facility_growth=mid))[metric]>=target:hi=mid
            else:lo=mid
        return hi
    thresholds=[dict(target_2028_EB=target,metric=metric,facility_growth_CAGR=threshold(target,metric),
        fixed_parameters='qualification1; power/memory/area mid;1qprocurementlookahead;1qphysicallag;constant24Gb;fixedopeninginventory')
        for target,metric in [(5.,'embedded_HBM_EB'),(5.,'embedded_top3_pool_HBM_EB'),(7.6,'embedded_top3_pool_HBM_EB')]]
    cf=[]
    for y in range(2026,2031):
        a=aggregate(panel(y));u=aggregate(panel(y,unchanged_configuration=True))
        cf.append(dict(year=y,current_configuration_EB=a['memory_EB'],same_devices_unreduced_EB=u['memory_EB'],
            configuration_saving_EB=u['memory_EB']-a['memory_EB'],configuration_saving_fraction=1-a['memory_EB']/u['memory_EB']))
    policy=[]
    ref=compact_2028(cases['base'])
    for h in [1,2,4]:
        row=compact_2028(cases[f'procurement_lookahead_{h}q'])
        policy.append(dict(procurement_lookahead_quarters=h,physical_lag_quarters=1,**row,
            extra_inventory_devices_m_vs1q=row['pipeline_devices_m']-ref['pipeline_devices_m'],
            extra_inventory_HBM_EB_vs1q=row['pipeline_HBM_EB']-ref['pipeline_HBM_EB'],
            extra_normalized_inventory_cost_index_m_vs1q=row['pipeline_cost_index_m']-ref['pipeline_cost_index_m']))
    base=cases['base'];b28=base['annual'][2]
    out=dict(version='4.1-physical-cohort-policy-model',as_of='2026-11-17',semi_analysis_inputs_used=False,
        independent_input_freeze=True,input_hashes={f:hashlib.sha256((TMP/f).read_bytes()).hexdigest() for f in ['v4_accelerator_demand.json','v4_bom_power_area.json','v4_hbm_supply.json']},
        model_code_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        research_scope='High-endcloudacceleratorreferencecohort;Top3matchedHBMplusunmatchedresidual;globalfacilityscenario. Notprovenexhaustive.',
        interpretation='Conditionalprocurement-policyandengineeringmodel,notobservedordersorcalibratedprobabilities.1/2/4quarterpoliciesmustbepresentedtogether.',
        assumptions={
          'qualification':'Supplier recovery already includes physical yield, assembly/test and qualification. Baseextraallocationfactor1.0;.95/.85onlyadditionalmismatchstresses.',
          'future_density':'Base24Gbcontinuation. GPU/MTIA480=half16-stack8Hi384+half16-stack12Hi576;otherASIC240analogous8-stackmean. Google384andTrainium288areexplicit24Gbengineeringbranches. No480GBsingledeviceor10HiSKUclaimed.',
          'density_transition':'32Gb40/70%in2029/30onlyinforced-transition sensitivity; memory capacity4/3andlater-generationpoolmustbothbeavailable. A commonfulfillmentfactorpreservesassumedmix;thiscanthrottleunrelatedSKUsandisnotamarketallocationforecast.',
          'power_and_area':'Threeindependentindices;purepowersensitivitydoesnotaltermemoryorlogic. FrozenBOMunchanged.',
          'opening_inventory':'Fixed5.671556502GWsystemIT,identicalacrossg/horizon/lagcases. Physicalproxy50%H200/50%B200deviceswithfixed1.45overheadandbaseBOM,all2025-available. Stockcompositionnotobserved. Itispre2026hardwareandnotcountedagaininforecastproduction.',
          'facility':'IT2025=82GW;25%isacceleratedconditionalcase,20/30%alternativesand15%tail. NoIEA2030forecastused. Globalfungibility/AIreadinessareoptimisticconditions.',
          'legacy_stock':'Initial25GWAIITisassumeduniformremaininglifeoverfiveyears,5GWretiresperyear;declining20%alternativeisreported. Newcohortlife5yearsfromcommissioning.',
          'procurement':'Lookahead1/2/4quartersisindependentof1quarterphysicalreadiness. Purchasescanwaitafterready. FIFOreleasewithinmanufacturingbatchesisproportionalacrossSKUs.',
          'inventory':'Eachcohorttracksdevices,HBMbygen,logicarea,ratedpower,ITpower,originandreadydate. Annualpurchase-minus-commissioningequalsuninstalledinventorychange. Retiredinstalledcohortstrackedseparately.',
          'unfilled_demand':'Unprocuredpotentialflowisnotassumedcancelled;noautomaticbacklogcarryforwardthatwoulddoublecountnextyearforecasts.',
          'memory_flow':'Noexecutableone-quarterHBMleadforecast:2028hasnolater32capacitytofeedearly2029. BaseassumesHBMmanufactureandpackageabsorptionwithinquarterbins,zerochangeinrawHBM/WIPinventory. TrueHBMfactoryshipmentsrequiregeneration-specificWIPledger.',
          'allocation':'MaximumLPallocationsarecapacitysolutions. Actualmatchedallocationsrescaletoactualprocurement,notautomaticproductionofunusedcapacity.',
          'unmatched_memory':'OutsidepoolHBMisexplicitandassumedavailableonlyconditionally;notincludedinTop3matchedcomparison. NoallocationequatesunmatchedunitswithzeroHBM.',
          'quarter_resolution':'Desiredannualflowissmoothedoverquarters;thisisnotareconstructionofobservedquarterlyshipmentsorindividualSKUlaunchdates.',
          'wafer_reallocation':'Advanceplanning,requalificationandmatchingpackagingrequired;advancedprocesswaferenvelopescannotbeexceeded. Annualcapacityandmixaresmoothedoverquarters,notverifiedquarterlyramps.',
          'fixed_mix_zero':'Fixedgeneration0fulfillmentmeansoneassumedmixisinfeasible,notzeroworldshipments;diagnosticonly,excludedfrommainmarketinterpretation.',
          'other_constraints':'Processorwafer,acceleratorCoWoS,substrateandboardthroughputarenotseparatelysolvedglobalcaps;logicareaistheassociateddemandmapping.',
          'inventory_cost':'CostindexGPU:ASIC=3:1isnormalizedstress,notprices. Indexmillions×assumedASICunitcostgiveshypotheticaldollars;noinventorybehaviorprobabilities.',
          'terminal':'2030advanceprocurementusesfacilitygrowthcontinuationintotargetquartersin2031;thisterminalextensionisanassumption.',
          'energy':'LegacyAI150TWh/nonAI335TWhsplitmatchesboth2025total485andIT352. NewAIload.60andPUE1.15onlyaffectenergy,notinstallableITcapacity.',
          'event':'Noevidencedcancellationdeductioninbase. Optional3.8GWstressassumesthesemegawattswerealreadyinaggregateenvelope.'},
        power_crosschecks_not_inputs=[
          dict(source='NVIDIADGXRubinNVL8',url='https://www.nvidia.com/en-us/data-center/dgx-rubin-nvl8/',ref='turn259view0',GPUs=8,system_kW=24,system_kW_per_GPU=3,boundary='entiresystemrating;notGPUchipTDP'),
          dict(source='SupermicroVeraRubin',url='https://www.supermicro.com/en/accelerators/nvidia/vera-rubin',ref='turn259view1',note='Root-verified1152GPU/5MWenvelopeand227kWrackneedseparatecooling/networkboundary;notusedasITperchipinput.'),
          dict(source='IntelFoundryAugust2026whitepaper',url='https://www.thailand.intel.com/content/dam/www/central-libraries/us/en/documents/2026-08/foundry-power-delivery-white-paper.pdf',ref='turn259view2',note='Figure1powerprojectionisoriginalresearchcontext,notNVIDIAofficialTDP. Frozenpanelnotretuned.')],
        base_2028_supply_reconciliation=dict(
            fixed_plan_Top3_qualified_capacity_EB=base['memory_annual_constraints']['2028']['fixed_plan_qualified_capacity_EB'],
            reallocated_recipe_Top3_maximum_supported_EB=cases['HBM_only']['annual'][2]['embedded_top3_pool_HBM_EB'],
            reallocation_difference_EB=cases['HBM_only']['annual'][2]['embedded_top3_pool_HBM_EB']-base['memory_annual_constraints']['2028']['fixed_plan_qualified_capacity_EB'],
            hardware_only_total_embedded_EB=cases['HBM_only']['annual'][2]['embedded_HBM_EB'],
            hardware_only_outside_pool_EB=cases['HBM_only']['annual'][2]['outside_pool_memory_EB'],
            one_quarter_policy_matched_absorption_EB=b28['embedded_top3_pool_HBM_EB'],
            one_quarter_policy_total_embedded_EB=b28['embedded_HBM_EB'],
            explanation='Samewafer-monthbudget,differentgenerationrecipesandGB/wafer. Theincrementisarecalculatedcompositioneffect,notextrafabricationcapacity. OutsidepoolmemoryisnotTop3supply.'),
        cases=cases,interactive_grid=grid,procurement_policy_comparison_2028=policy,
        facility_growth_thresholds=thresholds,same_device_configuration_bridge=cf,
        base_cumulative_logic_2026_2030_m2=sum(x['logic_m2'] for x in base['annual']),
        desired_cumulative_logic_2026_2030_m2=sum(x['unconstrained_logic_m2'] for x in base['annual']),
        production_HBM2028_vs_2026_growth=b28['embedded_HBM_EB']/base['annual'][0]['embedded_HBM_EB']-1)
    (TMP/'v4_integrated_model.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
    summary={name:[{k:r[k] for k in ['year','manufactured_devices_m','embedded_HBM_EB','embedded_top3_pool_HBM_EB','logic_m2','rated_shipment_GW',
        'installed_all_DC_IT_GW','all_DC_energy_TWh','pipeline_devices_m','pipeline_HBM_EB','pipeline_IT_GW','pipeline_cost_index_m','fixed_mix_feasibility_diagnostic_only']} for r in value['annual']] for name,value in cases.items()}
    (TMP/'v4_model_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'version':out['version'],'base':summary['base'],'policy2028':policy,'grid_cells':len(grid),'thresholds':thresholds,
        'max_inventory_balance_errors':{k:max(c['max_physical_inventory_balance_errors'][k] for c in cases.values()) for k in PHYSICAL_KEYS}},ensure_ascii=False,indent=2))

if __name__=='__main__':build()
