"""Reproducible, independent HBM supply-capability model; as of 2026-11-17.

No SemiAnalysis estimate, cut, or baseline is an input. Nominal supply-chain
capacity units are preserved. This is an assumption-exposing engineering model,
not a claim that issuers disclosed the modeled capacity/yield panel.
"""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
YEARS = list(range(2026, 2031))
SUPPLIERS = ["Samsung", "SK hynix", "Micron"]
GENERATIONS = ["HBM3e_or_earlier", "HBM4", "HBM4e", "later_generation_placeholder"]

sources = [
    dict(id="TF_20250509", date="2025-05-09", kind="original_industry_research_public_abstract", url="https://www.trendforce.com/research/download/RP250509XF", claim="2026 HBM shipments forecast above 30 billion Gb (= above 3.75 nominal EB). Old forecast, not realized 2026 production or an immutable lower bound.", use="historical_cross_check_only"),
    dict(id="TF_20260602", date="2026-06-02", kind="original_industry_research", url="https://www.trendforce.com/presscenter/news/20260602-13074.html", claim="End-year top-three HBM wafer shares: 2025 18%, 2026 22%, 2027 30%; HBM bit shares 8%, 9%, 13%. Wafer endpoints are not annual averages; bit-share timing needs source clarification.", use="allocation_cross_check_only"),
    dict(id="TF_20260804", date="2026-08-04", kind="original_industry_research", url="https://www.trendforce.com/presscenter/news/20260804-13166.html", claim="2027 HBM bit shipment growth forecast 50-60%; Rubin Ultra lower-stack alternatives evaluated since early Q3 2026. This predates the November leadership event.", use="external_growth_cross_check_not_model_input"),
    dict(id="TF_20260929", date="2026-09-29", kind="original_industry_research", url="https://www.trendforce.com/presscenter/news/20260929-13255.html", claim="2027 blended HBM ASP forecast +121%; 8Hi has 10-20% per-Gb premium versus 12Hi; fewer layers can allow the same bits to support more devices.", use="mix_and_price_semantics_not_bit_supply_arithmetic"),
    dict(id="TF_20261016", date="2026-10-16", kind="original_industry_research_public_abstract", url="https://www.trendforce.com/research/download/RP261016CK3", claim="8Hi becomes mainstream from H2 2027; supply expected tight through 2028. No usable absolute output in public abstract.", use="generation_and_stack_timing"),
    dict(id="TF_20261105", date="2026-11-05", kind="original_industry_research_public_abstract", url="https://www.trendforce.com/research/download/RP261105SQ3", claim="Samsung may lead in 2027 after HBM4 expansion; supplier output and TSV tables are paywalled. Public previews lack numeric labels, so no exact figures were digitized.", use="supplier_ranking_uncertainty"),
    dict(id="LS_20261116", date="2026-11-16", kind="original_broker_engineering_estimate", url="https://msg.ls-sec.co.kr/eum/K_20261114_31922_71.pdf", page="PDF p3 / printed p3", claim="SK hynix HBM 2026E 2,117 million GB; 2027E 2,779 million GB. Quarterly TSV capacity in 2026 495/540/570/600 thousand wafers, 2027 645/690/735/780 thousand. These are analyst estimates, not issuer output disclosure.", use="SK_absolute_output_and_annual_wafer_calibration"),
    dict(id="HANA_20261112", date="2026-11-12", kind="original_broker_research_estimate", url="https://file.hanaw.com/download/research/FileServer/WEB/industry/industry/2026/11/11/Semi_Indepth_261112_F.pdf", page="PDF p27 / printed p25; PDF p5 / printed p3", claim="2027 supply 4.9 billion GB: Samsung 2.0, SK 2.3, Micron 0.6. HBM capacity 2026 190/200/60k wafers/month, 2027 260/260/80k. New DRAM fabs contemplated at 100/100/50k monthly; meaningful contribution mostly from 2028. HBM chart does not explicitly define annual average versus year-end.", use="2027_endpoint_assumption_and_pipeline_scale; independent_low_case_cross_check", caution="The filename's Semi means semiconductor, not SemiAnalysis. Do not copy its investment conclusion. Its comparison chart has a questionable axis label; use prose for the EB numbers."),
    dict(id="SAMSUNGSEC_20260602", date="2026-06-02", kind="original_broker_engineering_estimate", url="https://www.samsungpop.com/common.do?cmd=down&contentType=application%2Fpdf&fileName=2020%2F2026060216210610K_02_04.pdf&inlineYn=Y&saveKey=research.pdf", page="printed p19", claim="Illustrative HBM3e: 578 net dies, 24 Gb/die, 60% recovery, 8,323 Gb/wafer. HBM4: 503 dies, 24 Gb, 50%, 6,034 Gb/wafer. These are the broker's engineering assumptions, not measured vendor yields.", use="geometry_prior_and_effective_recovery_range", local_copy="tmp/v4_samsung_sec_jun.pdf", retrieval="Public PDF downloaded and text extracted; search-service open returned 502."),
    dict(id="KB_20260223", date="2026-02-23", kind="original_broker_estimate", url="https://rdata.kbsec.com/pdf_data/20260220140952410E.pdf", claim="Samsung 2026 HBM shipment forecast 11.2 billion Gb (=1.4 nominal EB). Old estimate; not Q3 actual and not a company volume commitment.", use="2026_Samsung_base_calibration_with_wide_range"),
    dict(id="MU_20260930", date="2026-09-30", kind="issuer_prepared_remarks", url="https://s25.q4cdn.com/621799436/files/doc_financials/2026/q4/Q4-FY26-Prepared-Remarks.pdf", claim="Micron Singapore HBM packaging initial output early 2027; ID1 wafer output mid-2027; ID2 and Japan initial output late 2028; New York 2030. New plants take several quarters to contribute materially. Industry DRAM low-20s bit growth in 2027-28; HBM faster. Most 2027 HBM bits contracted.", use="commissioning_timing_not_numeric_HBM_capacity"),
    dict(id="MU_2026_10K", date="2026-09-30", kind="issuer_annual_report", url="https://www.sec.gov/Archives/edgar/data/723125/000072312526000023/mu-20260903.htm", claim="HBM4 36GB 12-high production; 48GB 16-high samples; HBM4E on 1-gamma planned to ramp in calendar 2027.", use="generation_qualification_timing"),
    dict(id="SK_20261028", date="2026-10-28", kind="issuer_results", url="https://news.skhynix.com/en/q3-2026-business-results/", claim="M15X planned at maximum capacity by end-2026; HBM4 exceeds HBM3e in Q4 shipment volume and revenue; Yongin Phase 1 in 2027. LTAs cover over half of total 2027-28 production, not specifically HBM-only production.", use="timing_and_product_mix_direction_not_percentage_mix"),
    dict(id="SK_20260828", date="2026-08-28", kind="issuer_project_release", url="https://news.skhynix.com/en/groundbreaking-ceremony-in-indiana/", claim="Indiana cleanroom October 2028; HBM mass production H2 2029; Korean wafers are shipped there for packaging/testing. It is not incremental front-end wafer fabrication.", use="exclude_Indiana_from_2028_bit_additions; no_front_back_double_count"),
    dict(id="SAMSUNG_20261029", date="2026-10-29", kind="issuer_earnings_transcript", url="https://irsvc.teletogether.com/sec/pdf/2026Q3_script_eng.pdf", claim="HBM4 sales more than tripled QoQ and reached 60% of HBM sales, a revenue mix not bit mix. HBM4E production planned H1 2027 and volume ramp H2; 2027 HBM supply negotiated. No absolute HBM bit capacity disclosed.", use="qualification_timing_and_no_revenue_to_bit_mix_error", local_copy="tmp/v4_samsung_script_q3.pdf", retrieval="Public PDF downloaded and text extracted; search-service open failed."),
    dict(id="SAMSUNG_20260629", date="2026-06-29", kind="issuer_fair_disclosure", url="https://www.samsung.com/global/ir/reports-disclosures/public-disclosure-view.84685/", claim="Long-term domestic investment plan includes Onyang/Cheonan HBM fab; no wafer or stack throughput is specified.", use="project_existence_only"),
]

# Generation percentages below are analytical production-wafer allocation
# assumptions, NOT vendor unit, stack, revenue, or bit market shares.
mix = {
  2026: {"Samsung":[.60,.40,0,0], "SK hynix":[.70,.30,0,0], "Micron":[.75,.25,0,0]},
  2027: {"Samsung":[.15,.65,.20,0], "SK hynix":[.20,.65,.15,0], "Micron":[.30,.60,.10,0]},
  2028: {"Samsung":[.05,.35,.60,0], "SK hynix":[.05,.40,.55,0], "Micron":[.10,.45,.45,0]},
  2029: {"Samsung":[0,.10,.65,.25], "SK hynix":[0,.15,.65,.20], "Micron":[.05,.20,.60,.15]},
  2030: {"Samsung":[0,0,.45,.55], "SK hynix":[0,.05,.45,.50], "Micron":[0,.10,.50,.40]},
}
geom = {
  "low":  dict(zip(GENERATIONS, [(578,24),(503,24),(450,24),(420,32)])),
  "base": dict(zip(GENERATIONS, [(578,24),(503,24),(475,24),(440,32)])),
  "high": dict(zip(GENERATIONS, [(578,24),(503,24),(500,24),(480,32)])),
}
# Each number is year-average front-end/TSV matched wafer-processing capacity
# in thousands/month; never multiply a year-end figure directly by 12.
avg_kwpm = {
 "low": {2026:[170,183.75,52.5],2027:[225,237.5,70],2028:[265,270,85],2029:[330,330,110],2030:[390,390,140]},
 "base":{2026:[170,183.75,52.5],2027:[225,237.5,70],2028:[280,300,100],2029:[380,380,140],2030:[460,460,180]},
 "high":{2026:[170,183.75,52.5],2027:[225,237.5,70],2028:[320,345,117.5],2029:[450,455,190],2030:[590,590,280]},
}
end_kwpm = {
 "low": {2026:[190,200,60],2027:[260,260,80],2028:[300,300,100],2029:[360,360,120],2030:[420,420,160]},
 "base":{2026:[190,200,60],2027:[260,260,80],2028:[340,340,120],2029:[420,420,160],2030:[500,500,200]},
 "high":{2026:[190,200,60],2027:[260,260,80],2028:[380,380,140],2029:[520,530,240],2030:[660,650,320]},
}
quarter_end_2028 = {
 "low": {"Samsung":[260,260,260,300],"SK hynix":[260,260,280,300],"Micron":[80,80,90,100]},
 "base":{"Samsung":[260,260,300,340],"SK hynix":[280,300,320,340],"Micron":[90,100,110,120]},
 "high":{"Samsung":[290,320,350,380],"SK hynix":[320,360,380,380],"Micron":[100,120,140,140]},
}
# Effective recovery combines front-end loss, usable die/stack yield, qualified
# conversion and operating utilization. It must NOT be multiplied by a second
# utilization factor or called a vendor's die yield. Base SK calibrated to LS.
recovery = {
 "low": {2028:[.52,.60,.50],2029:[.55,.61,.53],2030:[.57,.62,.55]},
 "base":{2028:[.62,.69,.62],2029:[.66,.71,.65],2030:[.68,.72,.67]},
 "high":{2028:[.70,.75,.70],2029:[.74,.78,.73],2030:[.77,.80,.76]},
}
calibration_eb = {
 "low": {2026:[1.10,2.117*.95,.45],2027:[2.0,2.3,.6]},
 "base":{2026:[1.40,2.117,.55],2027:[None,2.779,None]},
 "high":{2026:[1.60,2.117*1.05,.75],2027:[None,2.779*1.05,None]},
}
for scenario in recovery:
    for year in [2026,2027]:
        recovery[scenario][year] = []
        for idx,supplier in enumerate(SUPPLIERS):
            gross = sum(w * geom[scenario][g][0]*geom[scenario][g][1]/8 for w,g in zip(mix[year][supplier],GENERATIONS))
            target = calibration_eb[scenario][year][idx]
            if target is not None:
                factor=target*1e9/(avg_kwpm[scenario][year][idx]*1000*12*gross)
            else:
                factor = {"base":[.55,None,.58],"high":[.65,None,.75]}[scenario][idx]
            recovery[scenario][year].append(factor)

panel=[]
annual=[]
for scenario in ["low","base","high"]:
    previous=None
    for year in YEARS:
        total=0
        for idx,supplier in enumerate(SUPPLIERS):
            wafers=avg_kwpm[scenario][year][idx]*1000*12
            for share,g in zip(mix[year][supplier],GENERATIONS):
                nd,gb=geom[scenario][g]
                gross_bytes=nd*gb/8
                eb=wafers*share*gross_bytes*recovery[scenario][year][idx]/1e9
                total+=eb
                panel.append(dict(scenario=scenario,year=year,supplier=supplier,generation=g,
                  avg_matched_processing_kwpm=avg_kwpm[scenario][year][idx],
                  end_hbm_capacity_kwpm=end_kwpm[scenario][year][idx],
                  allocated_processing_wafers=wafers*share,
                  generation_wafer_share=share,
                  geometric_dies_per_wafer=nd,nominal_Gb_per_memory_die=gb,
                  effective_recovery=recovery[scenario][year][idx],
                  effective_nominal_GB_per_allocated_wafer=gross_bytes*recovery[scenario][year][idx],
                  supply_nominal_EB=eb,
                  classification="source_anchored_engineering_estimate" if year<=2027 else "conditional_engineering_supply_capacity",
                  source_ids=(
                    (["KB_20260223"] if year==2026 and supplier=="Samsung" else [])
                    + (["LS_20261116"] if supplier=="SK hynix" and year<=2027 else [])
                    + ["HANA_20261112","SAMSUNGSEC_20260602"]
                    + ([{"Samsung":"SAMSUNG_20261029","SK hynix":"SK_20261028","Micron":"MU_20260930"}[supplier]] if year>=2028 else [])
                  ),
                  capacity_is_measured=False,
                  effective_recovery_is_calibration_or_assumption=True,
                  generation_mix_is_assumption=True,
                  measured_supplier_generation_output=False))
        annual.append(dict(scenario=scenario,year=year,supply_nominal_EB=total,
          annual_processing_wafers_m=sum(avg_kwpm[scenario][year])*12/1000,
          effective_nominal_GB_per_wafer=total*1e9/(sum(avg_kwpm[scenario][year])*1000*12),
          yoy_change=None if previous is None else total/previous-1))
        previous=total

base28=next(r for r in annual if r['scenario']=='base' and r['year']==2028)
delay_parts=[]
no_new_capacity=0
for idx,supplier in enumerate(SUPPLIERS):
    starts=end_kwpm['base'][2027][idx]
    qe=quarter_end_2028['base'][supplier]
    delayed=[starts]+qe[:-1]
    dqavg=sum((a+b)/2 for a,b in zip([starts]+delayed[:-1],delayed))/4
    eff=sum(r['supply_nominal_EB'] for r in panel if r['scenario']=='base' and r['year']==2028 and r['supplier']==supplier)*1e9/(avg_kwpm['base'][2028][idx]*1000*12)
    delay_parts.append(dict(supplier=supplier,delayed_average_kwpm=dqavg,delta_nominal_EB=(dqavg-avg_kwpm['base'][2028][idx])*1000*12*eff/1e9))
    no_new_capacity+=starts*1000*12*eff/1e9

result = dict(
    version="v4-independent-hbm-supply-20261117",
    as_of="2026-11-17",
    status="independent_numeric_model_completed_with_material_assumption_uncertainty",
    scope="Top-three qualified HBM supply capability; not all global memory, not issuer-guaranteed shipments, and not a complete supply-demand or equity conclusion.",
    independence=dict(semianalysis_input_count=0, semianalysis_baseline_cut_direction_used=False, external_forecasts_are_distinct_from_own_model=True),
    units=dict(primary="nominal_supply_chain_EB", definition="1 nominal EB = 1e9 nominal GB; quoted Gb converted to quoted GB by /8. No unilateral GiB to SI conversion is applied.",
      billion_Gb_to_nominal_EB=.125, physical_SI_bytes="Not asserted without auditing both supplier capacity nomenclature and every accelerator BOM; preserve unit labels and source-native amounts.",
      wafer="300mm DRAM-core wafer equivalent matched to TSV/assembly, not logic base-die wafer and not finished stack count"),
    formulas={
      "supply": "sum_s,g (annual_matched_processing_wafers_s * generation_wafer_share_s,g * geometric_dies_per_wafer_g * nominal_Gb_per_die_g /8 * effective_recovery_s) /1e9",
      "wafer_integral":"12 * annual_average_kwpm * 1000; for 2028 annual average is mean of four quarterly midpoint capacities, not Dec capacity times 12.",
      "full_pipeline":"Qualified core bits are limited by front-end, TSV, base-die availability, assembly/test and customer qualification. The reduced-form recovery incorporates these losses; capacity and output are not added at successive stages.",
      "stock_flow":"HBM supplier shipments = accelerator-package absorption + other-HBM-market absorption + change in HBM/WIP inventory + production loss. Accelerator shipments and installed accelerator inventory are separate flows/stocks. Compare demand only after scope/time matching.",
      "actual_shipments":"Realized shipments <= qualified supply capability; weak orders can reduce operating utilization, so this panel is not forced demand realization."
    },
    sources=sources,
    reported_anchors={
      "hynix_LS":dict(annual_EB={2026:2.117,2027:2.779},quarterly_TSV_thousand_wafers={2026:[495,540,570,600],2027:[645,690,735,780]}, source_id="LS_20261116"),
      "hana_2027_output_EB":dict(Samsung=2.0,SK_hynix=2.3,Micron=.6,total=4.9,source_id="HANA_20261112"),
      "hana_capacity_kwpm":dict(year2025=[150,160,45],year2026=[190,200,60],year2027=[260,260,80],supplier_order=SUPPLIERS, source_id="HANA_20261112", temporal_definition="not explicitly labeled in chart; model conservatively treats as year-end, an explicit assumption"),
      "hynix_model_disagreement_2027":2.779/2.3-1,
      "Samsung_2026_KB_EB":1.4,
      "old_TF_2026_forecast_lower_bound_EB":3.75,
    },
    parameter_register={
      "2026_Micron_EB":"0.55 base, 0.45-0.75 sensitivity; engineering prior from 45->60k processing-capacity path and ~700-1,200 effective nominal GB/wafer, not issuer disclosure.",
      "2026_Samsung_EB":"1.4 base from old KB forecast; 1.1-1.6 sensitivity, requires replacement by late-2026 source when available.",
      "2027_SK_EB":"2.779 LS calibrated base; low 2.3 Hana; high +5% to LS, model sensitivity not new sourced volume.",
      "2028_capacity_base":"The Hana new-DRAM-fab scale is 100/100/50k monthly. Assume 80% of this increment ultimately matched to HBM, i.e. +80/+80/+40k endpoints. Samsung increment contributes mainly H2; SK/Micron ramp across the year. This is an allocation and execution assumption, not committed HBM capacity.",
      "2028_capacity_low":"40% of the same project scale, later ramps; HBM capacity endpoints +40/+40/+20k.",
      "2028_capacity_high":"120% of project-scale HBM additions (+120/+120/+60k), requiring full project completion plus conversion of existing DRAM lines and sufficient packaging. Stress case, not announced capacity.",
      "2028_effective_recovery_base":"Samsung .62 / SK .69 / Micron .62; effective qualified bit recovery, not die-yield guidance. For comparison, LS calibrated SK base is about .58 in 2026 and .63 in 2027 under our mix and geometry.",
      "HBM4e_geometry":"450/475/500 dies per wafer, 24 nominal Gb per die, explicit low/base/high assumption. No inspected issuer release discloses these dimensions. Geometry assumptions represent die enlargement versus node gains.",
      "later_generation_placeholder":"2029-30 only: 32 nominal Gb/die with 420/440/480 dies. A scenario placeholder, not a product announcement or verified HBM5 specification. Long-horizon output depends heavily on it.",
      "generation_mix":"All generation wafer shares are assumptions informed by qualification sequence. Samsung HBM4 60% revenue mix is deliberately not equated to 60% bit or wafer mix.",
      "2029_2030":"Annual-average and endpoint capacities are explicit continuation scenarios, not project-by-project verified global capacity. Do not present as high-confidence market forecast. Indiana is back-end only; ID2/NY front-end starts do not imply full-year HBM supply.",
    },
    quarter_end_capacity_kwpm_2028=quarter_end_2028,
    annual_average_capacity_kwpm=avg_kwpm,
    endpoint_capacity_kwpm=end_kwpm,
    supplier_order=SUPPLIERS,
    annual=annual,
    supplier_generation_panel=panel,
    thresholds_2028=dict(
      base_supply_nominal_EB=base28['supply_nominal_EB'],
      base_annual_processing_wafers=base28['annual_processing_wafers_m']*1e6,
      no_2028_new_capacity_but_base_recovery_EB=no_new_capacity,
      one_quarter_delay_EB=base28['supply_nominal_EB']+sum(x['delta_nominal_EB'] for x in delay_parts),
      one_quarter_delay_components=delay_parts,
      ten_percent_effective_recovery_loss_EB=base28['supply_nominal_EB']*.9,
      end_demand_threshold_grid=[dict(target_nominal_EB=t,required_effective_nominal_GB_per_wafer=t*1e9/(base28['annual_processing_wafers_m']*1e6),recovery_relative_to_base=t/base28['supply_nominal_EB']) for t in [6,7,8,9,10]],
      comment="Threshold grid is generic 6-10 EB and does not use a SemiAnalysis target. Demand agent must provide an independently estimated compatible absorption path."
    ),
    event_attribution=dict(
      jensen_event_physical_capacity_haircut=0,
      meaning="No retrieved issuer evidence links November leadership change to canceled HBM fab/TSV investment or customer qualification. Keep baseline supply unchanged; test demand cancellation, allocation, financing and inventory separately.",
      pre_event_spec_review="Rubin Ultra 8Hi evaluation publicly documented August 4; it cannot be attributed wholly to a November event.",
      event_channel="If independent demand model cuts accelerator package output, test whether suppliers lose orders, reallocate to ASICs/other customers, or build inventory. Do not mechanically reduce all HBM bit supply by an operator financing haircut."
    ),
    caveats=[
      "These scenario extrema are not statistical confidence intervals or calibrated probabilities.",
      "2028 is an estimate of saleable capacity under stated execution/recovery, not measured output or an order book.",
      "Two newer original broker sources disagree materially on 2027 absolute bits; do not hide this by using only a favorable growth forecast.",
      "Non-top-three HBM supply not quantified. This panel is top-three scope, not an audited all-world denominator.",
      "HBM DRAM wafer, TSV wafer processing, finished stack, base die, CoWoS wafer and accelerator unit cannot be added or used interchangeably.",
      "8Hi versus 12Hi changes stacks per given core bits and base-die/assembly demand. A 33% layer reduction is not automatically a 33% fall in aggregate HBM bit production or final chip units.",
      "Demand/supply shipment dates, inventory, server-delivery lead times and other-HBM applications must be reconciled by the integrator.",
    ],
    next_information_gain=[
      "Replace Samsung 2026 and Micron 2026 calibration with supplier-specific 2026 absolute HBM bits and grade them as issuer versus broker estimates.",
      "Clarify Hana capacity chart as annual average or year-end; obtain quarter-level TSV starts and qualified output for all three firms.",
      "Obtain HBM4e actual die area/density, stack assembly yields and per-customer qualification dates; these dominate the 2028 range.",
      "Join this supply panel to independent demand BOM on nominal units; retain residual scope and inventory rows rather than tuning one side to fit the other.",
    ],
)

# Meaningful arithmetic gates, not implementation-mirroring unit tests.
for year in YEARS:
    for s in SUPPLIERS:
        assert abs(sum(mix[year][s])-1)<1e-12
for scenario in avg_kwpm:
    for i,s in enumerate(SUPPLIERS):
        qe=quarter_end_2028[scenario][s]
        start=end_kwpm[scenario][2027][i]
        integral=sum((a+b)/2 for a,b in zip([start]+qe[:-1],qe))/4
        assert abs(integral-avg_kwpm[scenario][2028][i])<1e-9, (scenario,s,integral)
assert abs(sum(r['supply_nominal_EB'] for r in panel if r['scenario']=='base' and r['year']==2026 and r['supplier']=='SK hynix')-2.117)<1e-10
assert abs(sum(r['supply_nominal_EB'] for r in panel if r['scenario']=='base' and r['year']==2027 and r['supplier']=='SK hynix')-2.779)<1e-10
assert all(0<r['effective_recovery']<=1 for r in panel)
ROOT.joinpath('v4_hbm_supply.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
print(json.dumps({'annual':annual,'thresholds_2028':result['thresholds_2028']},ensure_ascii=False,indent=2))
