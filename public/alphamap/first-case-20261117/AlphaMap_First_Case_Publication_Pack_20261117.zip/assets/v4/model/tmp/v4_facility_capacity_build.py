#!/usr/bin/env python3
"""Independent facility IT-capacity scenarios. Does not alter frozen BOM."""
import json, hashlib
from pathlib import Path
P=Path(__file__).resolve().parent
B=json.loads((P/'v4_bom_power_area.json').read_text())
N=json.loads((P/'v4_accelerator_demand.json').read_text())
S={
'IEA_HISTORY':{'url':'https://www.iea.org/files/3179f7f8-01f6-4dd6-bffa-c9f7b73f1dc9/KeyQuestionsonEnergyandAI.pdf','date':'2026-04','refs':['turn211view1'],'role':'historical global stock estimate','facts':{'IT_installed_GW':{'2023':57,'2024':68,'2025':82},'total_installed_2025_GW':114},'scope':'All data centres; IT and total explicitly separate. No IEA2030 forecast is an input.'},
'JLL_H1':{'url':'https://www.jll.com/en-us/newsroom/data-center-demand-exceeds-expectations-in-h1-2026','date':'2026-08-11','refs':['turn247search3','turn248view1'],'role':'original property-market survey','facts':{'North_America_under_construction_GW':66,'precommitted_fraction':.95,'owner_occupied_under_construction_GW':28,'H1_absorption_GW':25},'scope':'Broad North America, including owner-occupied and frontier markets. Absorption is contractual demand, not same-period energised delivery. Many current leases target2028 delivery.'},
'CBRE_H1':{'url':'https://www.cbre.com/insights/books/21435420725','date':'2026-08-27','refs':['turn248view2'],'role':'original property-market survey','facts':{'eight_primary_market_operating_GW':10.903,'operating_inventory_yoy_growth':.337,'under_construction_GW':7.4811,'H1_net_absorption_GW':1.4562,'preleased_fraction':.804,'vacancy_fraction':.014},'scope':'Eight primary North American wholesale markets only; not global and not the same universe as JLL. Operating inventory and under-construction are separate.'},
'CW_2026':{'url':'https://ir.cushmanwakefield.com/news/press-release-details/2026/Dallas-Texas-Ranked-No--1-Primary-Data-Market-in-the-World-as-AI-Demand-Power-Constraints-and-Regulation-Reshape-CRE-Strategy/default.aspx','date':'2026-05-20','refs':['turn248view3'],'role':'original global property-market survey','facts':{'markets':107,'under_construction_end2025_GW':31.7,'prior_edition_under_construction_GW':12.5,'Americas_share_of_construction':.80,'Americas_planned_end2025_GW':191.3},'scope':'107 tracked markets; planned capacity is not under-construction or commissioned. Survey boundaries differ from JLL/CBRE; do not add totals.'},
'JLL_OUTLOOK':{'url':'https://www.jll.com/content/dam/jllcom/en/global/documents/reports/research-reports/26-research-global-data-center-outlook-new.pdf','date':'2026-01-06','refs':['turn248view0'],'role':'external scenario comparison only','facts':{'global_supply_2025_GW':103,'base_growth_CAGR':.14,'upside_growth_CAGR':.20,'downside_growth_CAGR':.07,'global_supply_2030_GW':200},'scope':'Includes colocation/build-to-suit/owner-occupied/on-prem. Electrical boundary not reconciled to IEA82GW IT; no direct level splice, and no forecast used as model input.'}}
A={'initial_total_IT_GW':82,'initial_AI_IT_GW':25,'initial_non_AI_IT_GW':57,
   'initial_AI_IT_sensitivity_GW':[19,25,31],'non_AI_IT_growth':.02,'non_AI_IT_growth_sensitivity':[0,.02,.04],
   'existing_2025_AI_annual_retirement_fraction':.20,'new_equipment_life_years':5,
   'new_AI_system_IT_to_accelerator_rating':1.45,'ratio_sensitivity':[1.25,1.45,1.65],
   'AI_ready_fraction_of_net_new_unreserved_IT':1.0,'AI_ready_fraction_sensitivity':[.7,.85,1.0],
   'same_year_commissioning_fraction':.70,'inventory_target_months_sensitivity':[0,3,6],
   'status':'All values other than total2025IT82GW are analyst stock-allocation/engineering assumptions. AI-ready1.0 is an optimistic physical conversion ceiling, not an observed capability.'}
hist_cagr=(82/57)**.5-1
scenarios={}
for name,g in [('tail_15pct',.15),('historical_trend_20pct',.20),('accelerated_base_candidate_25pct',.25),('high_acceleration_30pct',.30)]:
    rr=[];prevAI=A['initial_AI_IT_GW']
    for year in range(2026,2031):
        t=year-2025
        total=82*(1+g)**t
        nonAI=57*1.02**t
        AI=25+max(0,(total-82)-(nonAI-57))*A['AI_ready_fraction_of_net_new_unreserved_IT']
        legacyRetire=25*.2*.8**(t-1)
        legacyAI=25*.8**t
        headroom=AI-prevAI+legacyRetire
        n=next(x for x in N['scenarios_m']['base'] if x['year']==year)
        bp=next(x for x in B['base_demand_conditional_integration'] if x['year']==year)
        avgW=bp['accelerator_rated_shipment_GW_low_mid_high'][1]*1000/n['high_end_cloud_core_total']
        sysW=avgW*1.45
        devices=headroom*1000/sysW
        rr.append({'year':year,'total_IT_capacity_GW':total,'non_AI_IT_reserved_GW':nonAI,'AI_system_IT_capacity_GW':AI,
                   'legacy2025_AI_IT_surviving_GW':legacyAI,'legacy2025_AI_retired_this_year_GW':legacyRetire,
                   'incremental_AI_deployment_IT_budget_if_prior_year_full_GW':headroom,
                   'base_mix_mean_accelerator_W':avgW,'base_mix_mean_system_IT_W_per_device':sysW,
                   'devices_m_at_this_flow_budget':devices,
                   'unconstrained_new_device_demand_m':n['high_end_cloud_core_total'],
                   'flow_budget_divided_by_unconstrained_new_devices':devices/n['high_end_cloud_core_total'],
                   'note':'Conditional annual flow budget assumes previous AI capacity fully occupied; carry unused headroom in the coupled model. New2026+equipment has not reached5-year retirement by2030.'})
        prevAI=AI
    scenarios[name]={'growth_CAGR':g,'growth_evidence':'Analyst extrapolation around2023-25historical19.94%; not a bottom-up project forecast.', 'annual':rr}

out={'version':'v4-independent-facility-capacity-1','as_of':'2026-11-17','semi_values_as_inputs':False,
     'frozen_BOM_sha256':hashlib.sha256((P/'v4_bom_power_area.json').read_bytes()).hexdigest(),
     'sources':S,'historical_IT_CAGR_2023_2025':hist_cagr,'assumptions':A,'scenarios':scenarios,
     'evidence_assessment':'Primary surveys demonstrate a large pipeline, high precommitment and delivery bottlenecks; they do not establish one reconciled global2026-30energisedIT-delivery series. Therefore15/20/25/30%paths remain explicit extrapolation scenarios, not verified facility supply forecasts.',
     'facility_formulas':{
       'total_IT':'C_y=82*(1+g)^(y-2025)',
       'non_AI':'R_y=(82-AI0)*(1+c)^(y-2025)',
       'AI_ready':'C_AI_y=AI0+kappa*max(0,(C_y-82)-(R_y-(82-AI0)))',
       'headroom':'H_y=max(0,C_AI_y-surviving_installed_AI_system_IT_GW_y)',
       'actual_deployment':'sum_s(deployed_s,y*system_IT_W_s)/1e9 <= H_y',
       'system_boundary':'If s includes CPU/NIC/storage overhead via1.45, do not add those again. PUE is not applied when comparing to anIT-capacity budget.'},
     'endogenous_procurement_constraints':{
       'decision_variables':['purchased_devices_s,y','commissioned_devices_s,y','end_inventory_devices_s,y'],
       'supply_cap':'purchased_s,y <= min(unconstrained_demand_s,y,qualified_HBM_and_logic_and_packaging_supply_s,y)',
       'commissioning':'commissioned_s,y <= ready_inventory_start_s,y + alpha_s,y*purchased_s,y',
       'inventory_conservation':'inventory_end_s,y = inventory_start_s,y + purchased_s,y - commissioned_s,y',
       'inventory_limit':'inventory_end_s,y <= explicitly_selected_inventory_target_s,y; use0/3/6months of next-year feasible installations as a scenario, not unlimited accumulation',
       'facility_limit':'sum_s commissioned_s,y * system_IT_W_s /1e9 <= H_y',
       'procurement_gate':'For a given feasible deployment and inventory target: purchased <= deployed + target_inventory - opening_inventory, additionally subject to commissioning readiness. Limit procurement ex ante; report backlog separately.',
       'allocation':'Use stated supplier/customer priorities or preserve unconstrained SKU shares as a transparent default; do not silently allocate all power to the lowest-W device.',
       'replacement':'Retirement frees capacity only if site cooling/rack/voltage/network supports the new equipment; kappa<1 or explicit retrofits handle this.',
       'not_demand_destruction':'Orders deferred by missing facilities can remain demand/backlog. A purchase/installation cut is not automatically a cut in eventual computational need.'},
     'why_20pct_not_certain':'Only two historical growth intervals underpin the center scenario. JLLglobaloutlookuses14%baseand20%upsidewithadifferentcapacityboundary. Treat25%asaggressivebuildoutstress; permitlowergrowthifobserveddeliveriesslip.',
     'next_integration':'Run min-of-constraints in calendar-year cohorts: unconstrained demand -> qualified hardware supply -> inventory-limited procurement -> commissioned stock -> energy. Keep facility assumptions independent of IEA2030forecast andSemiunits.'}
out['base_candidate_assessment']={'candidate_growth_CAGR':.25,'designation':'accelerated conditional base candidate, not a statistical estimate','reason':'25% exceeds2023-25global19.94%history and is below CBRE33.7%growth in eight primary markets, but that selected-market statistic cannot validate25%globalgrowth. The enlarged pipeline supports testing acceleration, not assigning it a measured probability.','cold_review':'Report20/25/30%side by side;15%tail. A25%base can be an explicit optimistic buildout case. Do not call it empirically established or select it because it reduces inventory.','comparison_of_surveys':'JLL66GW is NorthAmericaH1 2026 under construction with broad self-build/frontier coverage;CW31.7GW is107globalmarkets at2025yearend. Different dates, scopes and project classifications; do not add or infer that one invalidates the other.'}
out['quarterly_capacity_scenarios']={}
for name,g in [(k,v['growth_CAGR']) for k,v in scenarios.items()]:
    qq=[]
    for q in range(1,21):
        t=q/4;year=2026+(q-1)//4;quarter=1+(q-1)%4
        C=82*(1+g)**t;R=57*1.02**t
        qq.append({'year':year,'quarter':quarter,'total_IT_capacity_GW':C,'non_AI_IT_reserved_GW':R,
            'AI_system_IT_capacity_GW':25+max(0,(C-82)-(R-57)),
            'legacy2025_AI_surviving_GW':25*.8**t})
    out['quarterly_capacity_scenarios'][name]=qq
out['quarterly_contract']='Quarterly capacity interpolation is a smooth engineering path, not a measured delivery schedule. Apply a disclosed commissioning-lag kernel to purchase cohorts; inventory and old-equipment retirement persist betweenquarters. Usequarter-endpowerconstraints andtime-weightedwithin-quarterstockforTWh, avoiding annual70/30hardcutoffoscillation.'
(P/'v4_facility_capacity.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
md=['# 独立设施能力情景：让采购与投运受机房约束','',
'**截至2026-11-17。** 不能把设备交付自动等同于投运。本模块以IEA历史估计的2025年全球IT装机82GW为起点，独立外推15%/20%/25%/30%；没有使用IEA2030预测或Semi数值来决定路径。四条路径是明确的工程情景，不是已验证的全球交付计划。','',
'## 原始设施证据与不能混用的口径','',
'| 原研究 | 覆盖/时间 | 已核数字 | 模型用途 |','|---|---|---|---|',
'| IEA Table A.1 | 全球IT历史估计 | 2023/24/25：57/68/82GW | 起点与约19.94%历史CAGR |',
'| JLL H1 2026 | 北美广口径含自建/外围市场 | 在建66GW，95%已承诺；其中自建28GW；25GW吸收 | 说明远期需求与建设规模；不能当同期已交付 |',
'| CBRE H1 2026 | 北美8个主要批发市场 | 运营10.903GW，在建7.481GW，预租80.4% | 独立区域交付/项目状态检查，不能加到JLL |',
'| Cushman & Wakefield 2026 | 107市场，2025末 | 在建31.7GW；美洲规划191.3GW | 规划、在建、通电必须分层 |','',
'来源：[IEA](https://www.iea.org/files/3179f7f8-01f6-4dd6-bffa-c9f7b73f1dc9/KeyQuestionsonEnergyandAI.pdf)、[JLL 8/11](https://www.jll.com/en-us/newsroom/data-center-demand-exceeds-expectations-in-h1-2026)、[CBRE 8/27](https://www.cbre.com/insights/books/21435420725)、[C&W 5/20](https://ir.cushmanwakefield.com/news/press-release-details/2026/Dallas-Texas-Ranked-No--1-Primary-Data-Market-in-the-World-as-AI-Demand-Power-Constraints-and-Regulation-Reshape-CRE-Strategy/default.aspx)。','',
'JLL表示当前不少租约面向2028交付。在建和预租是项目阶段，不能直接换算2026投运GW。三家机构地域、自建覆盖、市场定义和项目状态不同，数字不能相加。[JLL原报告](https://www.jll.com/en-us/insights/market-dynamics/north-america-data-centers)。其全球展望采用14%基准、20%上行情景，但103GW起点的电力边界未与IEA82GW IT核齐，故只作外部参照。[JLL全球展望](https://www.jll.com/content/dam/jllcom/en/global/documents/reports/research-reports/26-research-global-data-center-outlook-new.pdf)。','',
'## 从历史基数推导设施情景','',
'总IT容量=82×(1+g)^(年−2025)。工程拆分起点AI25GW、非AI57GW，非AI每年增长2%；设备功率到AI系统IT用1.45倍，新设备寿命5年，原2025AI存量每年退役20%。这些均为明确假设。表中AI可用容量默认新增净IT都适合高密度AI，属于乐观转换；另跑70%/85%可用比例。','',
'| 年 | 全IT：15% / 20% / 25% / 30%，GW | AI系统IT：15% / 20% / 25% / 30%，GW |','|---|---:|---:|']
for y in range(2026,2031):
    a=[v['annual'][y-2026] for v in scenarios.values()]
    md.append(f"| {y} | "+' / '.join(f"{x['total_IT_capacity_GW']:.1f}" for x in a)+' | '+' / '.join(f"{x['AI_system_IT_capacity_GW']:.1f}" for x in a)+' |')
md+=['','## 设施约束怎样传回当年采购','',
'每年先减去仍在运转的AI设备系统IT，得到新投运headroom。采购量还要满足HBM/logic/封装供应、当年可投运比例和库存目标。用库存守恒式“期末库存=期初库存+采购−投运”，将采购上限写成“可投运+允许期末库存−期初库存”；再与硬件供应取小值。库存目标可跑0/3/6个月，而不是允许无法通电的芯片无限堆存。','',
'下表只是容量预算对当年设备量的约束量级：假设上一年AI空间已占满，按今年BOM平均系统W换算；未用空间须在正式cohort模型中结转。没有把HBM约束后出货偷偷当成已投运。','',
'| 年 | 独立未受约束需求，百万device | 对应设施新增流量预算：15% / 20% / 25% / 30%，百万device |','|---|---:|---:|']
for y in range(2026,2031):
    a=[v['annual'][y-2026] for v in scenarios.values()]
    md.append(f"| {y} | {a[0]['unconstrained_new_device_demand_m']:.2f} | "+' / '.join(f"{x['devices_m_at_this_flow_budget']:.2f}" for x in a)+' |')
md+=['',
'这些量级表明，给定BOM功率升级路径，仅靠HBM放松未必能释放全部device需求。设施不足会形成延期、采购削减或库存；三者应单独报告。不能为了贴合IEA2030全行业174GW而调低利用率，因为利用率影响电量，不会凭空增加接电和散热能力。','',
'正式耦合时保留SKU优先顺序，或明确使用同比例缩放；不能为了多装device默默全买低功率型号。GPU→系统IT已经包含CPU/网络/存储时不再重复加；与IT容量预算比较时不乘PUE。PUE只进入场址能源桥，设施设计余量另列。','',
'**完成状态：** 原始设施调研与可计算情景完成；统一边界的全球逐项目2026–30交付台账仍缺失。15/20/25/30%不是采购结论，须与已冻结的硬件BOM及合格代际供给在同一个库存/投运模型中求解。复算：`python /workspace/scratch/6aa42040b254/tmp/v4_facility_capacity_build.py`。']
md += ['', '## 对25%作为base的冷评', '',
'25%可作为明确的加速建设情景：高于2023–25全球约20%的历史速度，低于CBRE所覆盖八大主要市场的33.7%同比。但后者是选择性地区、商业批发市场的一年数据，不能验证全球25%。建议同时展示20/25/30%，15%留作受限尾部；不能因为25%使设备库存更好看就称其为统计base。', '',
'JSON另给20个季度的平滑容量节点，供季度采购/投运模型接入。平滑节点本身也是工程假设，并非逐项目交付承诺。JLL66GW与C&W31.7GW分别处在不同时间、范围和项目状态定义，严格不相加。']
(P/'v4_facility_capacity.md').write_text('\n'.join(md)+'\n')
print(json.dumps({'historical_CAGR':hist_cagr,'2030':{k:v['annual'][-1] for k,v in scenarios.items()}},ensure_ascii=False,indent=2))
