"""Run the frozen model and compare its decisive outputs with the delivered reference."""
from pathlib import Path
import subprocess, sys, json, math
p=Path(__file__).resolve().parent
subprocess.run([sys.executable,str(p/'tmp/build_v4_integrated.py')],check=True,stdout=subprocess.DEVNULL)
a=json.loads((p/'tmp/v4_integrated_model.json').read_text())
b=json.loads((p/'reference/v4_integrated_model.json').read_text())
fields=['manufactured_devices_m','embedded_HBM_EB','embedded_top3_pool_HBM_EB','logic_m2','rated_shipment_GW','installed_AI_IT_GW','pipeline_devices_m','pipeline_HBM_EB','pipeline_IT_GW','all_DC_energy_TWh']
for case in b['cases']:
    for r,s in zip(a['cases'][case]['annual'],b['cases'][case]['annual']):
        for k in fields:
            assert math.isclose(r[k],s[k],rel_tol=1e-8,abs_tol=1e-7),(case,r['year'],k,r[k],s[k])
assert len(a['interactive_grid'])==27
print('PASS: all cases, years and decisive physical outputs match the reference.')
print('Model:',a['version'])
for r in a['procurement_policy_comparison_2028']:
    print(f"{r['procurement_lookahead_quarters']}q: embedded HBM {r['embedded_HBM_EB']:.6f} EB; installed AI IT {r['installed_AI_IT_GW']:.6f} GW; inventory HBM {r['pipeline_HBM_EB']:.6f} EB")
