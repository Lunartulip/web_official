#!/usr/bin/env python3
"""Draw the research lead from frozen computed scenarios; no model recalibration."""
from pathlib import Path
import json, html, hashlib
from weasyprint import HTML
import fitz

A=Path(__file__).resolve().parent
model=A/'model/reference/v4_integrated_model.json'
if not model.exists():
    model=A.parents[1]/'tmp/v4_integrated_model.json'
assert hashlib.sha256(model.read_bytes()).hexdigest()=='a92275cb9c0255421be58e52af034eb368d6fd5260052a788d00f0513608488e'
M=json.loads(model.read_text())
rows=[next(r for r in M['interactive_grid'] if r['facility_growth']==.25 and r['procurement_lookahead_quarters']==q and r['power_index']==1) for q in (1,4)]
assert abs(rows[0]['installed_AI_IT_GW']-rows[1]['installed_AI_IT_GW'])<1e-8
gap=rows[1]['embedded_HBM_EB']-rows[0]['embedded_HBM_EB']
BG='#f6f3eb'; INK='#20332d'; GREEN='#315f4e'; AMBER='#a76e32'; MUTED='#64716a'; LINE='#d9dbd1'
meta={'model_sha256':hashlib.sha256(model.read_bytes()).hexdigest(),'source':'interactive_grid: 2028, growth .25, power 1, lookahead 1/4','annual_procurement_difference_EB':gap,'rows':rows,'files':{}}
for lang in ('zh','en'):
    z=lang=='zh';parts=[f'<svg xmlns="http://www.w3.org/2000/svg" width="1440" height="800" viewBox="0 0 1440 800" role="img" aria-label="{html.escape("相同投运规模、不同HBM采购" if z else "Same installed capacity, different HBM procurement")}"><rect width="1440" height="800" fill="{BG}"/><g font-family="Noto Sans CJK SC,DejaVu Sans,Arial,sans-serif">']
    def text(x,y,t,size=24,color=INK,weight=400,anchor='start'):
        parts.append(f'<text x="{x}" y="{y}" font-size="{size}" fill="{color}" font-weight="{weight}" text-anchor="{anchor}">{html.escape(t)}</text>')
    def rect(x,y,w,h,c,rx=0):parts.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{rx}" fill="{c}"/>')
    text(64,43,'LUNARTULIP RESEARCH  /  05',18,MUTED,700)
    text(1376,43,'2028 · '+('条件测算' if z else 'Conditional estimate'),18,MUTED,400,'end')
    text(64,112,'同样的投运规模，采购量相差约2.4 EB' if z else 'Same installed capacity. A 2.4-EB procurement gap.',42 if z else 38,INK,700)
    text(64,161,'采购窗口改变了接货时间，也改变了库存融资需求' if z else 'Earlier procurement changes delivery timing and inventory financing.',25,MUTED)
    text(64,235,'提前采购窗口' if z else 'Buy ahead',24,MUTED)
    text(335,235,'当年设备内嵌HBM · EB' if z else 'Annual embedded HBM · EB',24,MUTED)
    text(1228,212,'年末已投运' if z else 'Year-end installed',23,MUTED,400,'middle')
    text(1228,244,'AI系统IT容量' if z else 'AI-system IT',23,MUTED,400,'middle')
    for i in range(5):
        x=335+i*165
        parts.append(f'<line x1="{x}" y1="275" x2="{x}" y2="522" stroke="{LINE}" stroke-width="1"/>')
        text(x,554,str(i*2),20,MUTED,400,'middle')
    for i,(q,r) in enumerate(zip((1,4),rows)):
        y=291+i*137;c=GREEN if i==0 else AMBER
        text(64,y+47,('一季' if q==1 else '一年') if z else ('1 quarter' if q==1 else '1 year'),32,INK,700)
        w=r['embedded_HBM_EB']/8*660
        rect(335,y,w,72,c)
        text(335+w+17,y+49,f"{r['embedded_HBM_EB']:.2f}",38,c,700)
        rect(1118,y-7,220,86,'#e6ebe1',7)
        text(1228,y+48,f"{r['installed_AI_IT_GW']:.1f} GW",32,INK,700,'middle')
    rect(64,595,1312,88,'#e4eadd',8)
    text(90,650,f'+{gap:.2f} EB',42,GREEN,700)
    text(391,633,'年度采购差额' if z else 'Annual procurement difference',23,INK,700)
    text(391,666,'更多设备提前接货，资金占用增加' if z else 'More equipment taken early; more capital tied up',22,MUTED)
    text(64,727,'条件：设施IT年增25%、中值功率、相同开仓库存、一季投运延迟。' if z else 'Held constant: 25% facility-IT growth, mid power, opening inventory and one-quarter physical lag.',20,MUTED)
    text(64,765,'来源：LunarTulip Research模型4.1。覆盖设备内嵌HBM；年度流量不等于期末库存，未赋予情景概率。' if z else 'Source: LunarTulip Research model 4.1. Covered-device HBM; annual flows differ from closing stocks. No scenario probabilities.',18,MUTED)
    parts.append('</g></svg>');svg=''.join(parts)
    path=A/f'00_thesis.{lang}.svg';path.write_text(svg)
    doc=HTML(string='<html><style>@page{size:1440px 800px;margin:0}body{margin:0}svg{display:block;width:1440px;height:800px}</style>'+svg+'</html>').write_pdf()
    pdf=fitz.open(stream=doc,filetype='pdf');assert len(pdf)==1
    png=A/f'00_thesis.{lang}.png';pdf[0].get_pixmap(matrix=fitz.Matrix(4/3,4/3),alpha=False).save(png)
    meta['files'][lang]={'svg':path.name,'png':png.name,'svg_sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
(A/'research_lead_metadata.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n')
print('Research lead: frozen values rendered in two languages.')
