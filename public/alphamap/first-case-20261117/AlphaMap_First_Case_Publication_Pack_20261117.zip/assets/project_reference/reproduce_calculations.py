"""Reproduce the published case arithmetic. Python standard library only."""
import json, math
from pathlib import Path
m=json.loads(Path(__file__).with_name('public_model_and_graph.json').read_text())
f=m['funding_timing'];p=f['expected_customer_prepayments_deposits_usdbn'];d=f['default_delay_fraction_assumption'];a=f['default_alternative_funds_usdbn_assumption']
assert math.isclose(p*d,1.8) and math.isclose(max(p*d-a,0),.8)
for r in f['grid']:
 assert math.isclose(r['unreplaced_usdbn'],max(p*r['delay_fraction']-r['alternative_funds_usdbn'],0),abs_tol=1e-8)
i=m['iren_prepayment'];assert math.isclose(i['tcv_usdbn_approx']*i['prepayment_fraction_per_tranche'],i['derived_total_contractual_prepayment_usdbn_approx'])
assert i['normalized_upfront_contractual_payment']+i['normalized_later_cash_net_of_credit']==i['normalized_contract_value']
c=m['historical_crwv'];assert math.isclose(c['ocf_coverage_pct'],c['operating_cash_flow_usdbn']/c['cash_ppe_and_software_usdbn']*100)
assert math.isclose(c['historical_difference_usdbn'],17.920)
for r in m['delivery_snapshots']:assert r['realized_mw']+r['remaining_mw']==r['contract_mw']
for r in m['corz_debt_schedule']['rows']:assert math.isclose(r['cash_coupon_usdm']+r['scheduled_principal_usdm'],r['cash_debt_service_usdm'])
own=json.loads(Path(__file__).with_name('independent_supply_demand_forecast.json').read_text())
contract_mw=sum(x['contract_critical_it_mw'] for x in own['projects'])
physical_mw=sum(x['remaining_mw'] for x in own['projects'] if x['remaining_metric']=='Under construction')
assert contract_mw==1368 and physical_mw==486
assert not own['external_forecast_values_used_as_inputs']
assert not {16,17,18}.intersection(own['source_ids_used'])
h=own['hardware_scale_example']
systems=physical_mw*1000*h['example_server_allocation_fraction_assumption']*h['example_installed_fraction_assumption']/h['reference_system_power_kw_approx']
gpu_equivalents=systems*h['gpus_per_system']
memory_eb=systems*h['reported_gpu_memory_tb_per_system']/1000000
assert math.isclose(systems,h['example_systems'])
assert math.isclose(gpu_equivalents,h['example_gpu_equivalents'])
assert math.isclose(memory_eb,h['example_reported_installed_gpu_memory_eb'])
assert own['global_forecast_status']['2028_hbm_eb'] is None
assert own['global_forecast_status']['2030_global_power_gw'] is None
print(json.dumps({'contract_mw':contract_mw,'physical_under_construction_mw':physical_mw,'forecast_cutoff':own['forecast_cutoff'],'hardware_equivalent_assumption_only':{'systems':systems,'gpu_equivalents':gpu_equivalents,'reported_installed_memory_eb':memory_eb},'funding_delayed_usdbn':p*d,'funding_unreplaced_usdbn':max(p*d-a,0),'iren_contractual_advance_usdbn':1.94,'ocf_coverage_pct':c['ocf_coverage_pct'],'status':'Published arithmetic reconciles. Project completion is conditional; this does not establish global supply-demand equilibrium or validate an external forecast.'},indent=2))
