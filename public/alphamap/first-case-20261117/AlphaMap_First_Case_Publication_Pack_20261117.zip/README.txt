LunarTulip Research 01 | AlphaMap First Case | v1.4.0
Research cutoff: 2026-11-18 (Beijing). Model: 4.1.
Research object: RO-ALPHAMAP-CASE-001.

This package contains the branded 26-page Chinese industry deep dive, bilingual
website editions, the canonical text, original charts, public model inputs,
reproduction scripts, and the editorial review. The PDF includes 55 cited
sources, source-linked figures, and model/relationship appendices.

Primary claim: near-term NVIDIA delivery growth remains supported by current
guidance and signed arrangements; farther-dated Neocloud expansion and host
commencement depend on funding and payment timing, while CPO changes the
value captured by different optical components.

The HBM procurement-window scenarios are conditional physical sensitivities,
not measured effects of the CEO transition or observed trading alpha. The
global most-likely supply/demand path remains research_incomplete in the
underlying public model.

Website: https://lunartuliplab.com/deep-dive/ai-infrastructure-cash-flow-first-case-2026-11
Citation: LunarTulip Research (2026), NVIDIA换帅之后，AI产业链哪些增长预期需要重估？,
Industry Deep Dive 01, version 1.4.0, research cutoff 18 November 2026.
